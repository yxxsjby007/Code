package dsa
import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
import dsa.element.ALU.aes128_alu
class aes128_alu_Test (dut:aes128_alu) extends PeekPokeTester(dut) {
  /*val num0 = "h6BC1BEE2".U
  val num1 = "h2E409F96".U
  val num2 = "hE93D7E11".U
  val num3 = "h7393172A".U*/

  val num0 = "h0aa3ddd3".U
  val num1 = "h1c73aba3".U
  val num2 = "hdf3d7e11".U
  val num3 = "h7393172a".U
  val key = Seq(
    "h161626331".U, "h132333435".U, "h136000000".U, "h100000000".U,
    "h103010052".U, "h131323467".U, "h107323467".U, "h107323467".U,
    "h122198597".U, "h1132BB1F0".U, "h114198597".U, "h1132BB1F0".U,
    "h1D7D109EA".U, "h1C4FAB81A".U, "h1D0E33D8D".U, "h1C3C88C7D".U,
    "h137B5F6C4".U, "h1F34F4EDE".U, "h123AC7353".U, "h1E064FF2E".U,
    "h164A3C725".U, "h197EC89FB".U, "h1B440FAA8".U, "h154240586".U,
    "h172C88305".U, "h1E5240AFE".U, "h15164F056".U, "h10540F5D0".U,
    "h13B2EF36E".U, "h1DE0AF990".U, "h18F6E09C6".U, "h18A2EFC16".U,
    "h18A9EB410".U, "h154944D80".U, "h1DBFA4446".U, "h151D4B850".U,
    "h1D9F2E7C1".U, "h18D66AA41".U, "h1569CEE07".U, "h107485657".U,
    "h1BD43BC04".U, "h130251645".U, "h166B9F842".U, "h161F1AE15".U
  )
  poke(dut.io.cfg, 1.U)

  poke(dut.io.inputs(0), num0)
  poke(dut.io.inputs(1), num1)
  poke(dut.io.inputs(2), num2)
  poke(dut.io.inputs(3), num3)
  poke(dut.io.inputs(5), key(4))

  step(1)
  poke(dut.io.inputs(5), key(5))
  println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
  println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
  println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
  println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
  println("output from test : outputs4 =  " + peek(dut.io.outputs(4)).toString(16))

  step(1)
  poke(dut.io.inputs(5), key(6))
  println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
  println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
  println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
  println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
  println("output from test : outputs4 =  " + peek(dut.io.outputs(4)).toString(16))

  step(1)
  poke(dut.io.inputs(5), key(7))
  println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
  println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
  println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
  println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
  println("output from test : outputs4 =  " + peek(dut.io.outputs(4)).toString(16))

  step(1)
  println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
  println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
  println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
  println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
  println("output from test : outputs4 =  " + peek(dut.io.outputs(4)).toString(16))



  step(1)
  println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
  println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
  println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
  println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
  println("output from test : outputs4 =  " + peek(dut.io.outputs(4)).toString(16))

  step(1)
  println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
  println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
  println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
  println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
  println("output from test : outputs4 =  " + peek(dut.io.outputs(4)).toString(16))



 /* for(i <- 0 until 8){
    step(1)
    println("output from test : outputs0 =  " + peek(dut.io.outputs(0)).toString(16))
    println("output from test : outputs1 =  " + peek(dut.io.outputs(1)).toString(16))
    println("output from test : outputs2 =  " + peek(dut.io.outputs(2)).toString(16))
    println("output from test : outputs3 =  " + peek(dut.io.outputs(3)).toString(16))
    println("output from test : outputs3 =  " + peek(dut.io.outputs(4)).toString(16))
  }*/


}

//object alu128UnitTest extends App {
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new aes128_alu("aes128", 32)) {
//    c => new aes128_alu_Test(c)
//  }
//
//}
