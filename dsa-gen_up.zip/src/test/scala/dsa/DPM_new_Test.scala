//package dsa
//import dsa.element.DPM_new
//
//import chisel3._
//import chisel3.util._
//import chisel3.iotesters.PeekPokeTester
//import chisel3.iotesters.Driver
//
//class DPM_new_Test(dut:DPM_new) extends PeekPokeTester(dut) {
//
//  poke(dut.io.cfg, "b1001".U)
//  //sha256
//  poke(dut.io.inputs(0), "h31323334".U)
//  poke(dut.io.inputs(1), "h35363738".U)
//  poke(dut.io.inputs(2), "h39307177".U)
//  poke(dut.io.inputs(3), "h65727479".U)
//  poke(dut.io.inputs(4), "h80000000".U)
//  poke(dut.io.inputs(5), 0.U)
//  poke(dut.io.inputs(6), 0.U)
//  poke(dut.io.inputs(7), 0.U)
//  poke(dut.io.inputs(8), 0.U)
//  poke(dut.io.inputs(9), 0.U)
//  poke(dut.io.inputs(10), 0.U)
//  poke(dut.io.inputs(11), 0.U)
//  poke(dut.io.inputs(12), 0.U)
//  poke(dut.io.inputs(13), 0.U)
//  poke(dut.io.inputs(14), 0.U)
//  poke(dut.io.inputs(15), "h80".U)
//  step(1)
//
//  //sha1
////  poke(dut.io.inputs(0), "h61626380".U)
////  poke(dut.io.inputs(1), 0)
////  poke(dut.io.inputs(2), 0)
////  poke(dut.io.inputs(3), 0)
////  poke(dut.io.inputs(4), 0.U)
////  poke(dut.io.inputs(5), 0.U)
////  poke(dut.io.inputs(6), 0.U)
////  poke(dut.io.inputs(7), 0.U)
////  poke(dut.io.inputs(8), 0.U)
////  poke(dut.io.inputs(9), 0.U)
////  poke(dut.io.inputs(10), 0.U)
////  poke(dut.io.inputs(11), 0.U)
////  poke(dut.io.inputs(12), 0.U)
////  poke(dut.io.inputs(13), 0.U)
////  poke(dut.io.inputs(14), 0.U)
////  poke(dut.io.inputs(15), "h18".U)
////  step(1)
//
//  for(i <- 0 until 80) {
//    println("第" + i + "次")
//    println("outputs" + i + ":" + peek(dut.io.outputs(i)).toString(16))
////    println("outputs1 : " + peek(dut.io.outputs(1)).toString(16))
////    println("outputs2 : " + peek(dut.io.outputs(2)).toString(16))
////    println("outputs3 : " + peek(dut.io.outputs(3)).toString(16))
//    step(1)
//  }
//
//}
//
//
//
//object DPM_newUnitTest extends App {
//  //LM: 如何添加整个架构
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  val alu_type = "DPM_new"
//  val op_type = 1
//  val in_num = 16
//  val data_sets = 1
//  val PE_num = 80
//  val width = 32
//
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new DPM_new(alu_type, op_type, in_num, data_sets, PE_num,  width)) {
//    c => new DPM_new_Test(c)
//  }
//}