package dsa

import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import dsa.element.ALU.ram
import chisel3.iotesters.Driver

class ram_tester(dut:ram) extends PeekPokeTester(dut) {
  poke(dut.io.address, 23.U)
  step(1)
  println("output from test : outputs0 =  " + peek(dut.io.value).toString(16))

}

//object ram_test extends App {
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new ram(8,8, "E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt")) {
//    c => new ram_tester(c)
//  }
//}