package dsa
import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
import dsa.element.CfgMem
class cfg_Unit_Test (dut:CfgMem) extends PeekPokeTester(dut){

  step(1)
  poke(dut.io.cfgEn, 1)
  poke(dut.io.dpm_ctrlin, 123.U)
  //poke(dut.io.cfgAddr, 1.U)
  poke(dut.io.cfgData, 123123.U)
  poke(dut.io.ob_ctrlin, 369963.U)

  step(1)
  poke(dut.io.cfgEn, 1)
  poke(dut.io.dpm_ctrlin, 123.U)
 // poke(dut.io.cfgAddr, 1.U)
  poke(dut.io.cfgData, 123123.U)
  poke(dut.io.ob_ctrlin, 369963.U)

  step(1)

  poke(dut.io.cfgEn, 1)
  poke(dut.io.dpm_ctrlin, 123.U)
  //poke(dut.io.cfgAddr, 1.U)
  poke(dut.io.cfgData, 123123.U)
  poke(dut.io.ob_ctrlin, 369963.U)

  step(1)
}
//object cfgMemUnitTest extends App {
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  Driver.execute(Array("--generate-vcd-output", "on"), () =>  new CfgMem(32)) {
//    c => new cfg_Unit_Test(c)
//  }
//}