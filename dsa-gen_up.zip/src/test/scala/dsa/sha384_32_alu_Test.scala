package dsa
import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
import dsa.element.ALU.sha384_32_alu
class sha384_32_alu_Test(dut:sha384_32_alu) extends PeekPokeTester(dut) {
  poke(dut.io.cfg, "b1".U)
  poke(dut.io.inputs(0), 0)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), 0)
  poke(dut.io.inputs(7), 0)
  poke(dut.io.inputs(8), 0)
  poke(dut.io.inputs(9), 0)
  poke(dut.io.inputs(10), 0)
  poke(dut.io.inputs(11), 0)
  poke(dut.io.inputs(12), 0)
  poke(dut.io.inputs(13), 0)
  poke(dut.io.inputs(14), 0)
  poke(dut.io.inputs(15), 0)
  poke(dut.io.inputs(16), 0)
  poke(dut.io.inputs(17), "h31323334".U)
  poke(dut.io.inputs(18), "h35363738".U)

  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
  println("outputs1 : " + peek(dut.io.outputs(1)).toString(16))
  println("outputs2 : " + peek(dut.io.outputs(2)).toString(16))
  println("outputs3 : " + peek(dut.io.outputs(3)).toString(16))
  println("outputs4 : " + peek(dut.io.outputs(4)).toString(16))
  println("outputs5 : " + peek(dut.io.outputs(5)).toString(16))
  println("outputs6 : " + peek(dut.io.outputs(6)).toString(16))
  println("outputs7 : " + peek(dut.io.outputs(7)).toString(16))
  println("outputs8 : " + peek(dut.io.outputs(8)).toString(16))
  println("outputs9 : " + peek(dut.io.outputs(9)).toString(16))
  println("outputs10 : " + peek(dut.io.outputs(10)).toString(16))
  println("outputs11 : " + peek(dut.io.outputs(11)).toString(16))
  println("outputs12 : " + peek(dut.io.outputs(12)).toString(16))
  println("outputs13 : " + peek(dut.io.outputs(13)).toString(16))
  println("outputs14 : " + peek(dut.io.outputs(14)).toString(16))
  println("outputs15 : " + peek(dut.io.outputs(15)).toString(16))
  println("outputs16 : " + peek(dut.io.outputs(16)).toString(16))

}

//object sha384_32_aluUnitTest extends App {
//  println("asasdasdasdasa")
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new sha384_32_alu("sha384_32", 32, 16, 1)) {
//    c => new sha384_32_alu_Test(c)
//  }
//}
