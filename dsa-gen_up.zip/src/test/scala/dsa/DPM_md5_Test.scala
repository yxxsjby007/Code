package dsa
import dsa.element.DPM_md5

import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
class DPM_md5_Test (dut:DPM_md5) extends PeekPokeTester(dut) {

  poke(dut.io.cfg, "b10".U)

  poke(dut.io.inputs(0), 111.U)
  poke(dut.io.inputs(1), 1.U)
  poke(dut.io.inputs(2), 2.U)
  poke(dut.io.inputs(3), 3.U)
  poke(dut.io.inputs(4), 4.U)
  poke(dut.io.inputs(5), 5.U)
  poke(dut.io.inputs(6), 6.U)
  poke(dut.io.inputs(7), 7.U)
  poke(dut.io.inputs(8), 8.U)
  poke(dut.io.inputs(9), 9.U)
  poke(dut.io.inputs(10), 10.U)
  poke(dut.io.inputs(11), 11.U)
  poke(dut.io.inputs(12), 12.U)
  poke(dut.io.inputs(13), 13.U)
  poke(dut.io.inputs(14), 14.U)
  poke(dut.io.inputs(15), 15.U)
  step(1)
  poke(dut.io.cfg, "b01".U)
  step(1)
  poke(dut.io.cfg, "b00".U)

  for(i <- 0 until 64) {
    step(1)
    println("outputs0 : " + i + "    " + peek(dut.io.outputs(0)))
  }



}
//object DPM_md5_UnitTest extends App {
//  //LM: 如何添加整个架构
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  val alu_type = "dmp_md5_example"
//  val in_num = 16
//  val PE_num = 1
//  val width = 32
//
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new DPM_md5(alu_type,  in_num, PE_num, width)) {
//    c => new DPM_md5_Test(c)
//  }
//}