package dsa
import dsa.element.DPM

import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
class DPM_Test (dut:DPM) extends PeekPokeTester(dut) {

  //输入数据结束后下一个时钟周期关闭数据读入，即cfg(0)位应该置零
  poke(dut.io.cfg, "b0101".U)

 /* //md5测试数据
  poke(dut.io.inputs(0), 111.U)
  poke(dut.io.inputs(1), 1.U)
  poke(dut.io.inputs(2), 2.U)
  poke(dut.io.inputs(3), 3.U)
  poke(dut.io.inputs(4), 4.U)
  poke(dut.io.inputs(5), 5.U)
  poke(dut.io.inputs(6), 6.U)
  poke(dut.io.inputs(7), 7.U)
  poke(dut.io.inputs(8), 8.U)
  poke(dut.io.inputs(9), 9.U)
  poke(dut.io.inputs(10), 10.U)
  poke(dut.io.inputs(11), 11.U)
  poke(dut.io.inputs(12), 12.U)
  poke(dut.io.inputs(13), 13.U)
  poke(dut.io.inputs(14), 14.U)
  poke(dut.io.inputs(15), 15.U)

  step(1)
  poke(dut.io.inputs(0), 20.U)
  poke(dut.io.inputs(1), 21.U)
  poke(dut.io.inputs(2), 22.U)
  poke(dut.io.inputs(3), 23.U)
  poke(dut.io.inputs(4), 24.U)
  poke(dut.io.inputs(5), 25.U)
  poke(dut.io.inputs(6), 26.U)
  poke(dut.io.inputs(7), 27.U)
  poke(dut.io.inputs(8), 28.U)
  poke(dut.io.inputs(9), 29.U)
  poke(dut.io.inputs(10), 30.U)
  poke(dut.io.inputs(11), 31.U)
  poke(dut.io.inputs(12), 32.U)
  poke(dut.io.inputs(13), 33.U)
  poke(dut.io.inputs(14), 34.U)
  poke(dut.io.inputs(15), 35.U)


  step(1)
  poke(dut.io.inputs(0), 40.U)
  poke(dut.io.inputs(1), 41.U)
  poke(dut.io.inputs(2), 42.U)
  poke(dut.io.inputs(3), 43.U)
  poke(dut.io.inputs(4), 44.U)
  poke(dut.io.inputs(5), 45.U)
  poke(dut.io.inputs(6), 46.U)
  poke(dut.io.inputs(7), 47.U)
  poke(dut.io.inputs(8), 48.U)
  poke(dut.io.inputs(9), 49.U)
  poke(dut.io.inputs(10), 50.U)
  poke(dut.io.inputs(11), 51.U)
  poke(dut.io.inputs(12), 52.U)
  poke(dut.io.inputs(13), 53.U)
  poke(dut.io.inputs(14), 54.U)
  poke(dut.io.inputs(15), 55.U)


  step(1)
  poke(dut.io.inputs(0), 60.U)
  poke(dut.io.inputs(1), 61.U)
  poke(dut.io.inputs(2), 62.U)
  poke(dut.io.inputs(3), 63.U)
  poke(dut.io.inputs(4), 64.U)
  poke(dut.io.inputs(5), 65.U)
  poke(dut.io.inputs(6), 66.U)
  poke(dut.io.inputs(7), 67.U)
  poke(dut.io.inputs(8), 68.U)
  poke(dut.io.inputs(9), 69.U)
  poke(dut.io.inputs(10), 70.U)
  poke(dut.io.inputs(11), 71.U)
  poke(dut.io.inputs(12), 72.U)
  poke(dut.io.inputs(13), 73.U)
  poke(dut.io.inputs(14), 74.U)
  poke(dut.io.inputs(15), 75.U)
  step(1)
  poke(dut.io.cfg, "b00010".U)
  val W = "h61616161".U

  for(i <- 0 until 68) {

    println("第" + i + "次")
    println("outputs0 : " + peek(dut.io.outputs(0)))
    println("outputs1 : " + peek(dut.io.outputs(1)))
    println("outputs2 : " + peek(dut.io.outputs(2)))
    println("outputs3 : " + peek(dut.io.outputs(3)))
    step(1)
  }*/

  //sha1测试数据
  /*
  poke(dut.io.inputs(0), "h61626380".U)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), 0)
  poke(dut.io.inputs(7), 0)
  poke(dut.io.inputs(8), 0)
  poke(dut.io.inputs(9), 0)
  poke(dut.io.inputs(10),  0)
  poke(dut.io.inputs(11),  0)
  poke(dut.io.inputs(12),  0)
  poke(dut.io.inputs(13),  0)
  poke(dut.io.inputs(14),  0)
  poke(dut.io.inputs(15),  "h00000018".U)

  step(1)
  poke(dut.io.inputs(0), "h61626380".U)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), 0)
  poke(dut.io.inputs(7), 0)
  poke(dut.io.inputs(8), 0)
  poke(dut.io.inputs(9), 0)
  poke(dut.io.inputs(10),  0)
  poke(dut.io.inputs(11),  0)
  poke(dut.io.inputs(12),  0)
  poke(dut.io.inputs(13),  0)
  poke(dut.io.inputs(14),  0)
  poke(dut.io.inputs(15),  "h00000018".U)


  step(1)
  poke(dut.io.inputs(0), "h61626380".U)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), 0)
  poke(dut.io.inputs(7), 0)
  poke(dut.io.inputs(8), 0)
  poke(dut.io.inputs(9), 0)
  poke(dut.io.inputs(10),  0)
  poke(dut.io.inputs(11),  0)
  poke(dut.io.inputs(12),  0)
  poke(dut.io.inputs(13),  0)
  poke(dut.io.inputs(14),  0)
  poke(dut.io.inputs(15),  "h00000018".U)


  step(1)
  poke(dut.io.inputs(0), "h61626380".U)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), 0)
  poke(dut.io.inputs(7), 0)
  poke(dut.io.inputs(8), 0)
  poke(dut.io.inputs(9), 0)
  poke(dut.io.inputs(10),  0)
  poke(dut.io.inputs(11),  0)
  poke(dut.io.inputs(12),  0)
  poke(dut.io.inputs(13),  0)
  poke(dut.io.inputs(14),  0)
  poke(dut.io.inputs(15),  "h00000018".U)
  step(1)
  poke(dut.io.cfg, "b0110".U)*/



  //sha256测试数据
  val tx = Seq( "h31323334".U,  "h35363738".U,  "h39307177".U,  "h65727479".U,
                "h80000000".U,  "h00000000".U,  "h00000000".U,  "h00000000".U,
                "h00000000".U,  "h00000000".U,  "h00000000".U,  "h00000000".U,
                "h00000000".U,  "h00000000".U,  "h00000000".U,  "h00000080".U)
  poke(dut.io.inputs(0), tx(0))
  poke(dut.io.inputs(1), tx(1))
  poke(dut.io.inputs(2), tx(2))
  poke(dut.io.inputs(3), tx(3))
  poke(dut.io.inputs(4), tx(4))
  poke(dut.io.inputs(5), tx(5))
  poke(dut.io.inputs(6), tx(6))
  poke(dut.io.inputs(7), tx(7))
  poke(dut.io.inputs(8), tx(8))
  poke(dut.io.inputs(9), tx(9))
  poke(dut.io.inputs(10),  tx(10))
  poke(dut.io.inputs(11),  tx(11))
  poke(dut.io.inputs(12),  tx(12))
  poke(dut.io.inputs(13),  tx(13))
  poke(dut.io.inputs(14),  tx(14))
  poke(dut.io.inputs(15),  tx(15))

  step(1)



  step(1)



  step(1)

  step(1)
  poke(dut.io.cfg, "b1010".U)


  for(i <- 0 until 64) {

    println("第" + i + "次")
    println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
    println("outputs1 : " + peek(dut.io.outputs(1)).toString(16))
    println("outputs2 : " + peek(dut.io.outputs(2)).toString(16))
    println("outputs3 : " + peek(dut.io.outputs(3)).toString(16))
    step(1)
  }



  //sm3测试数据(sm3的数据输出得晚一个周期)
  val sm3 = Seq ( "h54686520".U,  "h71756963".U,  "h6B206272".U,  "h6F776E20".U,
                  "h666F7820".U,  "h6A756D70".U,  "h73206F76".U,  "h65722074".U,
                  "h6865206C".U,  "h617A7920".U,  "h646F6780".U,  "h00000000".U,
                  "h00000000".U,  "h00000000".U,  "h00000000".U,  "h00000158".U)
  /*poke(dut.io.inputs(0), sm3(0))
  poke(dut.io.inputs(1), sm3(1))
  poke(dut.io.inputs(2), sm3(2))
  poke(dut.io.inputs(3), sm3(3))
  poke(dut.io.inputs(4), sm3(4))
  poke(dut.io.inputs(5), sm3(5))
  poke(dut.io.inputs(6), sm3(6))
  poke(dut.io.inputs(7), sm3(7))
  poke(dut.io.inputs(8), sm3(8))
  poke(dut.io.inputs(9), sm3(9))
  poke(dut.io.inputs(10),  sm3(10))
  poke(dut.io.inputs(11),  sm3(11))
  poke(dut.io.inputs(12),  sm3(12))
  poke(dut.io.inputs(13),  sm3(13))
  poke(dut.io.inputs(14),  sm3(14))
  poke(dut.io.inputs(15),  sm3(15))

  step(1)
  poke(dut.io.inputs(0), sm3(0))
  poke(dut.io.inputs(1), sm3(1))
  poke(dut.io.inputs(2), sm3(2))
  poke(dut.io.inputs(3), sm3(3))
  poke(dut.io.inputs(4), sm3(4))
  poke(dut.io.inputs(5), sm3(5))
  poke(dut.io.inputs(6), sm3(6))
  poke(dut.io.inputs(7), sm3(7))
  poke(dut.io.inputs(8), sm3(8))
  poke(dut.io.inputs(9), sm3(9))
  poke(dut.io.inputs(10),  sm3(10))
  poke(dut.io.inputs(11),  sm3(11))
  poke(dut.io.inputs(12),  sm3(12))
  poke(dut.io.inputs(13),  sm3(13))
  poke(dut.io.inputs(14),  sm3(14))
  poke(dut.io.inputs(15),  sm3(15))


  step(1)
  poke(dut.io.inputs(0), sm3(0))
  poke(dut.io.inputs(1), sm3(1))
  poke(dut.io.inputs(2), sm3(2))
  poke(dut.io.inputs(3), sm3(3))
  poke(dut.io.inputs(4), sm3(4))
  poke(dut.io.inputs(5), sm3(5))
  poke(dut.io.inputs(6), sm3(6))
  poke(dut.io.inputs(7), sm3(7))
  poke(dut.io.inputs(8), sm3(8))
  poke(dut.io.inputs(9), sm3(9))
  poke(dut.io.inputs(10),  sm3(10))
  poke(dut.io.inputs(11),  sm3(11))
  poke(dut.io.inputs(12),  sm3(12))
  poke(dut.io.inputs(13),  sm3(13))
  poke(dut.io.inputs(14),  sm3(14))
  poke(dut.io.inputs(15),  sm3(15))


  step(1)
  poke(dut.io.inputs(0), sm3(0))
  poke(dut.io.inputs(1), sm3(1))
  poke(dut.io.inputs(2), sm3(2))
  poke(dut.io.inputs(3), sm3(3))
  poke(dut.io.inputs(4), sm3(4))
  poke(dut.io.inputs(5), sm3(5))
  poke(dut.io.inputs(6), sm3(6))
  poke(dut.io.inputs(7), sm3(7))
  poke(dut.io.inputs(8), sm3(8))
  poke(dut.io.inputs(9), sm3(9))
  poke(dut.io.inputs(10),  sm3(10))
  poke(dut.io.inputs(11),  sm3(11))
  poke(dut.io.inputs(12),  sm3(12))
  poke(dut.io.inputs(13),  sm3(13))
  poke(dut.io.inputs(14),  sm3(14))
  poke(dut.io.inputs(15),  sm3(15))
  step(1)
  poke(dut.io.cfg, "b1100".U)
  step(1)
  poke(dut.io.cfg, "b1110".U)*/

  //sha384 32位测试数据
/*val sha384_32 = Seq(
  "h31323334".U,"h35363738".U,
  "h39307177".U,"h65727479".U,
  "h80000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000000".U,
  "h00000000".U,"h00000080".U)

  poke(dut.io.inputs(0), sha384_32(0))
  poke(dut.io.inputs(1), sha384_32(1))
  poke(dut.io.inputs(2), sha384_32(2))
  poke(dut.io.inputs(3), sha384_32(3))
  poke(dut.io.inputs(4), sha384_32(4))
  poke(dut.io.inputs(5), sha384_32(5))
  poke(dut.io.inputs(6), sha384_32(6))
  poke(dut.io.inputs(7), sha384_32(7))
  poke(dut.io.inputs(8), sha384_32(8))
  poke(dut.io.inputs(9), sha384_32(9))
  poke(dut.io.inputs(10),  sha384_32(10))
  poke(dut.io.inputs(11),  sha384_32(11))
  poke(dut.io.inputs(12),  sha384_32(12))
  poke(dut.io.inputs(13),  sha384_32(13))
  poke(dut.io.inputs(14),  sha384_32(14))
  poke(dut.io.inputs(15),  sha384_32(15))
  poke(dut.io.inputs(16),  sha384_32(16))
  poke(dut.io.inputs(17),  sha384_32(17))
  poke(dut.io.inputs(18),  sha384_32(18))
  poke(dut.io.inputs(19),  sha384_32(19))
  poke(dut.io.inputs(20),  sha384_32(20))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(22),  sha384_32(22))
  poke(dut.io.inputs(23),  sha384_32(23))
  poke(dut.io.inputs(24),  sha384_32(24))
  poke(dut.io.inputs(25),  sha384_32(25))
  poke(dut.io.inputs(26),  sha384_32(26))
  poke(dut.io.inputs(27),  sha384_32(27))
  poke(dut.io.inputs(28),  sha384_32(28))
  poke(dut.io.inputs(29),  sha384_32(29))
  poke(dut.io.inputs(30),  sha384_32(30))
  poke(dut.io.inputs(31),  sha384_32(31))



  step(1)
  poke(dut.io.inputs(0), sha384_32(0))
  poke(dut.io.inputs(1), sha384_32(1))
  poke(dut.io.inputs(2), sha384_32(2))
  poke(dut.io.inputs(3), sha384_32(3))
  poke(dut.io.inputs(4), sha384_32(4))
  poke(dut.io.inputs(5), sha384_32(5))
  poke(dut.io.inputs(6), sha384_32(6))
  poke(dut.io.inputs(7), sha384_32(7))
  poke(dut.io.inputs(8), sha384_32(8))
  poke(dut.io.inputs(9), sha384_32(9))
  poke(dut.io.inputs(10),  sha384_32(10))
  poke(dut.io.inputs(11),  sha384_32(11))
  poke(dut.io.inputs(12),  sha384_32(12))
  poke(dut.io.inputs(13),  sha384_32(13))
  poke(dut.io.inputs(14),  sha384_32(14))
  poke(dut.io.inputs(15),  sha384_32(15))
  poke(dut.io.inputs(16),  sha384_32(16))
  poke(dut.io.inputs(17),  sha384_32(17))
  poke(dut.io.inputs(18),  sha384_32(18))
  poke(dut.io.inputs(19),  sha384_32(19))
  poke(dut.io.inputs(20),  sha384_32(20))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(22),  sha384_32(22))
  poke(dut.io.inputs(23),  sha384_32(23))
  poke(dut.io.inputs(24),  sha384_32(24))
  poke(dut.io.inputs(25),  sha384_32(25))
  poke(dut.io.inputs(26),  sha384_32(26))
  poke(dut.io.inputs(27),  sha384_32(27))
  poke(dut.io.inputs(28),  sha384_32(28))
  poke(dut.io.inputs(29),  sha384_32(29))
  poke(dut.io.inputs(30),  sha384_32(30))
  poke(dut.io.inputs(31),  sha384_32(31))


  step(1)
  poke(dut.io.inputs(0), sha384_32(0))
  poke(dut.io.inputs(1), sha384_32(1))
  poke(dut.io.inputs(2), sha384_32(2))
  poke(dut.io.inputs(3), sha384_32(3))
  poke(dut.io.inputs(4), sha384_32(4))
  poke(dut.io.inputs(5), sha384_32(5))
  poke(dut.io.inputs(6), sha384_32(6))
  poke(dut.io.inputs(7), sha384_32(7))
  poke(dut.io.inputs(8), sha384_32(8))
  poke(dut.io.inputs(9), sha384_32(9))
  poke(dut.io.inputs(10),  sha384_32(10))
  poke(dut.io.inputs(11),  sha384_32(11))
  poke(dut.io.inputs(12),  sha384_32(12))
  poke(dut.io.inputs(13),  sha384_32(13))
  poke(dut.io.inputs(14),  sha384_32(14))
  poke(dut.io.inputs(15),  sha384_32(15))
  poke(dut.io.inputs(16),  sha384_32(16))
  poke(dut.io.inputs(17),  sha384_32(17))
  poke(dut.io.inputs(18),  sha384_32(18))
  poke(dut.io.inputs(19),  sha384_32(19))
  poke(dut.io.inputs(20),  sha384_32(20))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(22),  sha384_32(22))
  poke(dut.io.inputs(23),  sha384_32(23))
  poke(dut.io.inputs(24),  sha384_32(24))
  poke(dut.io.inputs(25),  sha384_32(25))
  poke(dut.io.inputs(26),  sha384_32(26))
  poke(dut.io.inputs(27),  sha384_32(27))
  poke(dut.io.inputs(28),  sha384_32(28))
  poke(dut.io.inputs(29),  sha384_32(29))
  poke(dut.io.inputs(30),  sha384_32(30))
  poke(dut.io.inputs(31),  sha384_32(31))


  step(1)
  poke(dut.io.inputs(0), sha384_32(0))
  poke(dut.io.inputs(1), sha384_32(1))
  poke(dut.io.inputs(2), sha384_32(2))
  poke(dut.io.inputs(3), sha384_32(3))
  poke(dut.io.inputs(4), sha384_32(4))
  poke(dut.io.inputs(5), sha384_32(5))
  poke(dut.io.inputs(6), sha384_32(6))
  poke(dut.io.inputs(7), sha384_32(7))
  poke(dut.io.inputs(8), sha384_32(8))
  poke(dut.io.inputs(9), sha384_32(9))
  poke(dut.io.inputs(10),  sha384_32(10))
  poke(dut.io.inputs(11),  sha384_32(11))
  poke(dut.io.inputs(12),  sha384_32(12))
  poke(dut.io.inputs(13),  sha384_32(13))
  poke(dut.io.inputs(14),  sha384_32(14))
  poke(dut.io.inputs(15),  sha384_32(15))
  poke(dut.io.inputs(16),  sha384_32(16))
  poke(dut.io.inputs(17),  sha384_32(17))
  poke(dut.io.inputs(18),  sha384_32(18))
  poke(dut.io.inputs(19),  sha384_32(19))
  poke(dut.io.inputs(20),  sha384_32(20))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(21),  sha384_32(21))
  poke(dut.io.inputs(22),  sha384_32(22))
  poke(dut.io.inputs(23),  sha384_32(23))
  poke(dut.io.inputs(24),  sha384_32(24))
  poke(dut.io.inputs(25),  sha384_32(25))
  poke(dut.io.inputs(26),  sha384_32(26))
  poke(dut.io.inputs(27),  sha384_32(27))
  poke(dut.io.inputs(28),  sha384_32(28))
  poke(dut.io.inputs(29),  sha384_32(29))
  poke(dut.io.inputs(30),  sha384_32(30))
  poke(dut.io.inputs(31),  sha384_32(31))
  step(1)
  poke(dut.io.cfg, "b10100".U)
  step(1)
  poke(dut.io.cfg, "b10110".U)*/

  //sha384 64为测试数据
  /*val sha384_64 = Seq(
    "h3132333435363738".U,
    "h3930717765727479".U,
    "h8000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000000".U,
    "h0000000000000080".U)

  poke(dut.io.inputs(0), sha384_64(0))
  poke(dut.io.inputs(1), sha384_64(1))
  poke(dut.io.inputs(2), sha384_64(2))
  poke(dut.io.inputs(3), sha384_64(3))
  poke(dut.io.inputs(4), sha384_64(4))
  poke(dut.io.inputs(5), sha384_64(5))
  poke(dut.io.inputs(6), sha384_64(6))
  poke(dut.io.inputs(7), sha384_64(7))
  poke(dut.io.inputs(8), sha384_64(8))
  poke(dut.io.inputs(9), sha384_64(9))
  poke(dut.io.inputs(10),  sha384_64(10))
  poke(dut.io.inputs(11),  sha384_64(11))
  poke(dut.io.inputs(12),  sha384_64(12))
  poke(dut.io.inputs(13),  sha384_64(13))
  poke(dut.io.inputs(14),  sha384_64(14))
  poke(dut.io.inputs(15),  sha384_64(15))

  step(1)
  poke(dut.io.inputs(0), sha384_64(0))
  poke(dut.io.inputs(1), sha384_64(1))
  poke(dut.io.inputs(2), sha384_64(2))
  poke(dut.io.inputs(3), sha384_64(3))
  poke(dut.io.inputs(4), sha384_64(4))
  poke(dut.io.inputs(5), sha384_64(5))
  poke(dut.io.inputs(6), sha384_64(6))
  poke(dut.io.inputs(7), sha384_64(7))
  poke(dut.io.inputs(8), sha384_64(8))
  poke(dut.io.inputs(9), sha384_64(9))
  poke(dut.io.inputs(10),  sha384_64(10))
  poke(dut.io.inputs(11),  sha384_64(11))
  poke(dut.io.inputs(12),  sha384_64(12))
  poke(dut.io.inputs(13),  sha384_64(13))
  poke(dut.io.inputs(14),  sha384_64(14))
  poke(dut.io.inputs(15),  sha384_64(15))


  step(1)
  poke(dut.io.inputs(0), sha384_64(0))
  poke(dut.io.inputs(1), sha384_64(1))
  poke(dut.io.inputs(2), sha384_64(2))
  poke(dut.io.inputs(3), sha384_64(3))
  poke(dut.io.inputs(4), sha384_64(4))
  poke(dut.io.inputs(5), sha384_64(5))
  poke(dut.io.inputs(6), sha384_64(6))
  poke(dut.io.inputs(7), sha384_64(7))
  poke(dut.io.inputs(8), sha384_64(8))
  poke(dut.io.inputs(9), sha384_64(9))
  poke(dut.io.inputs(10),  sha384_64(10))
  poke(dut.io.inputs(11),  sha384_64(11))
  poke(dut.io.inputs(12),  sha384_64(12))
  poke(dut.io.inputs(13),  sha384_64(13))
  poke(dut.io.inputs(14),  sha384_64(14))
  poke(dut.io.inputs(15),  sha384_64(15))


  step(1)
  poke(dut.io.inputs(0), sha384_64(0))
  poke(dut.io.inputs(1), sha384_64(1))
  poke(dut.io.inputs(2), sha384_64(2))
  poke(dut.io.inputs(3), sha384_64(3))
  poke(dut.io.inputs(4), sha384_64(4))
  poke(dut.io.inputs(5), sha384_64(5))
  poke(dut.io.inputs(6), sha384_64(6))
  poke(dut.io.inputs(7), sha384_64(7))
  poke(dut.io.inputs(8), sha384_64(8))
  poke(dut.io.inputs(9), sha384_64(9))
  poke(dut.io.inputs(10),  sha384_64(10))
  poke(dut.io.inputs(11),  sha384_64(11))
  poke(dut.io.inputs(12),  sha384_64(12))
  poke(dut.io.inputs(13),  sha384_64(13))
  poke(dut.io.inputs(14),  sha384_64(14))
  poke(dut.io.inputs(15),  sha384_64(15))
  step(1)
  poke(dut.io.cfg, "b11000".U)
  step(1)
  poke(dut.io.cfg, "b11010".U)*/


  /*//aes128测试数据
  val num0 = "h61626331".U
  val num1 = "h32333435".U
  val num2 = "h36000000".U
  val num3 = "h00000000".U
  poke(dut.io.inputs(0), num0)
  poke(dut.io.inputs(1), num1)
  poke(dut.io.inputs(2), num2)
  poke(dut.io.inputs(3), num3)
  step(1)
  poke(dut.io.inputs(0), num0)
  poke(dut.io.inputs(1), num1)
  poke(dut.io.inputs(2), num2)
  poke(dut.io.inputs(3), num3)
  step(1)
  poke(dut.io.inputs(0), num0)
  poke(dut.io.inputs(1), num1)
  poke(dut.io.inputs(2), num2)
  poke(dut.io.inputs(3), num3)
  step(1)
  poke(dut.io.inputs(0), num0)
  poke(dut.io.inputs(1), num1)
  poke(dut.io.inputs(2), num2)
  poke(dut.io.inputs(3), num3)
  step(1)
  poke(dut.io.cfg, "b11110".U)
  /*step(1)
  poke(dut.io.cfg, "b11010".U)*/


  for(i <- 0 until 12) {
    println("第" + i + "次")
    println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
    println("outputs1 : " + peek(dut.io.outputs(1)).toString(16))
    println("outputs2 : " + peek(dut.io.outputs(2)).toString(16))
    println("outputs3 : " + peek(dut.io.outputs(3)).toString(16))
    /*println("outputs4 : " + peek(dut.io.outputs(4)).toString(16))
    println("outputs5 : " + peek(dut.io.outputs(5)).toString(16))
    println("outputs6 : " + peek(dut.io.outputs(6)).toString(16))
    println("outputs7 : " + peek(dut.io.outputs(7)).toString(16))*/
    step(1)
  }*/

  /*step(1)
  poke(dut.io.inputs(0), 156.U)
  poke(dut.io.inputs(1), 1.U)
  poke(dut.io.inputs(2), 2.U)
  poke(dut.io.inputs(3), 3.U)
  poke(dut.io.inputs(4), 4.U)
  poke(dut.io.inputs(5), 5.U)
  poke(dut.io.inputs(6), 6.U)
  poke(dut.io.inputs(7), 7.U)
  poke(dut.io.inputs(8), 8.U)
  poke(dut.io.inputs(9), 9.U)
  poke(dut.io.inputs(10), 10.U)
  poke(dut.io.inputs(11), 11.U)
  poke(dut.io.inputs(12), 12.U)
  poke(dut.io.inputs(13), 13.U)
  poke(dut.io.inputs(14), 14.U)
  poke(dut.io.inputs(15), 11111.U)*/


  /*println("outputs3 : " + peek(dut.io.outputs(4)))
  println("outputs3 : " + peek(dut.io.outputs(5)))
  println("outputs3 : " + peek(dut.io.outputs(6)))
  println("outputs3 : " + peek(dut.io.outputs(7)))*/

  /*for(i <- 0 until 32) {
    step(1)
    println("outputs0 : " + peek(dut.io.outputs(0)))
    println("outputs1 : " + peek(dut.io.outputs(1)))
    println("outputs2 : " + peek(dut.io.outputs(2)))
    println("outputs3 : " + peek(dut.io.outputs(3)))
    /*println("outputs3 : " + peek(dut.io.outputs(4)))
    println("outputs3 : " + peek(dut.io.outputs(5)))
    println("outputs3 : " + peek(dut.io.outputs(6)))
    println("outputs3 : " + peek(dut.io.outputs(7)))*/
  }*/

  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
  /*println("outputs1 : " + peek(dut.io.outputs(1)))
  println("outputs2 : " + peek(dut.io.outputs(2)))
  println("outputs3 : " + peek(dut.io.outputs(3)))*/


  step(1)
    println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
    /*println("outputs1 : " + peek(dut.io.outputs(1)))
    println("outputs2 : " + peek(dut.io.outputs(2)))
    println("outputs3 : " + peek(dut.io.outputs(3)))*/

  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
  /*println("outputs1 : " + peek(dut.io.outputs(1)))
  println("outputs2 : " + peek(dut.io.outputs(2)))
  println("outputs3 : " + peek(dut.io.outputs(3)))*/

  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
  /*println("outputs1 : " + peek(dut.io.outputs(1)))
  println("outputs2 : " + peek(dut.io.outputs(2)))
  println("outputs3 : " + peek(dut.io.outputs(3)))*/


  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
/*  println("outputs1 : " + peek(dut.io.outputs(1)))
  println("outputs2 : " + peek(dut.io.outputs(2)))
  println("outputs3 : " + peek(dut.io.outputs(3)))*/



  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)))
/*  println("outputs1 : " + peek(dut.io.outputs(1)))
  println("outputs2 : " + peek(dut.io.outputs(2)))
  println("outputs3 : " + peek(dut.io.outputs(3)))*/


  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)))
 /* println("outputs1 : " + peek(dut.io.outputs(1)))
  println("outputs2 : " + peek(dut.io.outputs(2)))
  println("outputs3 : " + peek(dut.io.outputs(3)))*/

}

//object DPMUnitTest extends App {
//  //LM: 如何添加整个架构
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  val alu_type = "example"
//  val op_type = 2
//  val in_num = 16
//  val data_sets = 4
//  val PE_num = 4
//  val width = 32
//  val cycle = 80
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new DPM(alu_type, op_type, in_num, data_sets, PE_num, cycle, width)) {
//    c => new DPM_Test(c)
//  }
//}