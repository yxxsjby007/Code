package dsa

import dsa.element.DPM_sm3

import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
class DPM_sm3_Test (dut:DPM_sm3) extends PeekPokeTester(dut) {

  //输入数据结束后下一个时钟周期关闭数据读入，即cfg(0)位应该置零
  poke(dut.io.cfg, "b11".U)


  //sm3测试数据(sm3的数据输出得晚一个周期)
  val sm3 = Seq ( "h54686520".U,  "h71756963".U,  "h6B206272".U,  "h6F776E20".U,
                  "h666F7820".U,  "h6A756D70".U,  "h73206F76".U,  "h65722074".U,
                  "h6865206C".U,  "h617A7920".U,  "h646F6780".U,  "h00000000".U,
                  "h00000000".U,  "h00000000".U,  "h00000000".U,  "h00000158".U)
  poke(dut.io.inputs(0), sm3(0))
  poke(dut.io.inputs(1), sm3(1))
  poke(dut.io.inputs(2), sm3(2))
  poke(dut.io.inputs(3), sm3(3))
  poke(dut.io.inputs(4), sm3(4))
  poke(dut.io.inputs(5), sm3(5))
  poke(dut.io.inputs(6), sm3(6))
  poke(dut.io.inputs(7), sm3(7))
  poke(dut.io.inputs(8), sm3(8))
  poke(dut.io.inputs(9), sm3(9))
  poke(dut.io.inputs(10),  sm3(10))
  poke(dut.io.inputs(11),  sm3(11))
  poke(dut.io.inputs(12),  sm3(12))
  poke(dut.io.inputs(13),  sm3(13))
  poke(dut.io.inputs(14),  sm3(14))
  poke(dut.io.inputs(15),  sm3(15))


  for(i <- 0 until 64) {
    step(1)
    //  println("outputs0 : " + peek(dut.io.outputs(2 * i)).toString(16))
   println("outputs1 : " + i + "    " + peek(dut.io.outputs(2 * i + 1)).toString(16))
  }


  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))


  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))


}

//object DPM_sm3_UnitTest extends App {
//  //LM: 如何添加整个架构
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  val alu_type = "dmp_sm3_example"
//  val in_num = 16
//  val PE_num = 32
//  val width = 32
//
//  Driver.execute(Array("--generate-vcd-output", "on"), () => new DPM_sm3(alu_type,  in_num, PE_num, width)) {
//    c => new DPM_sm3_Test(c)
//  }
//}