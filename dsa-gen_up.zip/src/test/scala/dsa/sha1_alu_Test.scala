package dsa

import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
import dsa.element.ALU.sha1_alu

class sha1_alu_Test (dut:sha1_alu) extends PeekPokeTester(dut){
  poke(dut.io.cfg, "b1".U)
  poke(dut.io.inputs(0), 0)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), "h61626380".U)
  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
  println("outputs1 : " + peek(dut.io.outputs(1)).toString(16))
  println("outputs2 : " + peek(dut.io.outputs(2)).toString(16))
  println("outputs3 : " + peek(dut.io.outputs(3)).toString(16))
  println("outputs4 : " + peek(dut.io.outputs(4)).toString(16))
  println("outputs5 : " + peek(dut.io.outputs(5)).toString(16))

}

//object sha1_aluUnitTest extends App {
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  Driver.execute(Array("--generate-vcd-output", "on"), () =>  new sha1_alu("alu0",32, 16, 1)) {
//    c => new sha1_alu_Test(c)
//  }
//}
