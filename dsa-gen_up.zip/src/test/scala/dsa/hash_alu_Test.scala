package dsa

import chisel3._
import chisel3.util._
import chisel3.iotesters.PeekPokeTester
import chisel3.iotesters.Driver
import dsa.element.ALU.hash_alu

class hash_alu_Test (dut:hash_alu) extends PeekPokeTester(dut){
  poke(dut.io.cfg, "b111".U)
  poke(dut.io.inputs(0), 0)
  poke(dut.io.inputs(1), 0)
  poke(dut.io.inputs(2), 0)
  poke(dut.io.inputs(3), 0)
  poke(dut.io.inputs(4), 0)
  poke(dut.io.inputs(5), 0)
  poke(dut.io.inputs(6), 0)
  poke(dut.io.inputs(7), 0)
  poke(dut.io.inputs(8), 0)
  poke(dut.io.inputs(10), "h54686520".U)
  poke(dut.io.inputs(9), "h32071D00".U)

  step(1)
  println("outputs0 : " + peek(dut.io.outputs(0)).toString(16))
  println("outputs1 : " + peek(dut.io.outputs(1)).toString(16))
  println("outputs2 : " + peek(dut.io.outputs(2)).toString(16))
  println("outputs3 : " + peek(dut.io.outputs(3)).toString(16))
  println("outputs4 : " + peek(dut.io.outputs(4)).toString(16))
  println("outputs5 : " + peek(dut.io.outputs(5)).toString(16))
  println("outputs6 : " + peek(dut.io.outputs(6)).toString(16))
  println("outputs7 : " + peek(dut.io.outputs(7)).toString(16))
  println("outputs8 : " + peek(dut.io.outputs(8)).toString(16))



}

//object hash_aluUnitTest extends App {
//  println("aSASDFASDFSDsadfgsdfsdfsd")
//  Driver.execute(Array("--generate-vcd-output", "on"), () =>  new hash_alu("hash_alu0", 8, 32, 16, 1)) {
//    c => new hash_alu_Test(c)
//  }
//}
