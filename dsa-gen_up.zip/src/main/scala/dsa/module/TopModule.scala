package dsa.module

import dsa.IR.Info2Xml.getSubModIndex
import dsa.element.ALU.{md5_alu, sha1_alu, sha256_alu, sha224_alu, sm3_alu, sha384_32_alu, sha1_2cycle_alu, sha1_new_alu, md5_new_alu, sha256_new_alu, md5_sha1_sha256_alu, md5_sha1_sha256_2cycle_alu, sha1_regout_alu}
import dsa.element.ALU.{sha1_multi, sha256_multi, md5_multi, aes_alu}
import dsa.element.ALU.sha512_alu
import dsa.element.ALU.md5_sha1_alu
import dsa.element.ALU.hash_alu
import dsa.element.{CfgMem, DPM, IB, Multiplexer, MultiplexerR, OB, DPM_new, DPM_md5_sha1_sha256, DPM_md5_sha1_sha256_2cycle, DPM_sha1_multi, DPM_sha256_multi, DPM_md5_multi}
import dsa.element.{DPM_sha1, DPM_md5, DPM_sha256, DPM_sha512, DPM_sm3, DPM_aes}
import dsa.parameter.EleType
import dsa.parameter.EleType._
import dsa.parameter.EleTypeFun._
import dsa.parameter.Param.cfgDataW
import dsa.parameter.Param.pe_cfgwidth
import chisel3._
import chisel3.util._

import java.io.FileWriter
import scala.collection.mutable.{ArrayBuffer, ListBuffer, Map}

object TopModule {
  val cgfWidthList: ListBuffer[Int] = ListBuffer()

  def getWidthList(moduleInfo: ModuleInfo):Unit = {
    cgfWidthList.clear()
    var lastAddr = 0

    def getAddrWSub(level : Int,moduleInfo: ModuleInfo):Unit = {
      val elesAddr = (moduleInfo.getCfgW() + cfgDataW - 1)/cfgDataW
      if(lastAddr < elesAddr) lastAddr = elesAddr
      if(moduleInfo.getModuleInsts().size != 0){
        val thisAddrW = log2Ceil(moduleInfo.getModuleInsts().size + 1)
        if(cgfWidthList.size < level + 1 )cgfWidthList.append(thisAddrW)
        else{
          if(cgfWidthList(level) < thisAddrW) cgfWidthList(level) = thisAddrW
        }
        moduleInfo.getModuleInsts().foreach{
          index => getAddrWSub(level + 1 , moduleInfo.getModuleList()(index))
        }
      }
    }
    getAddrWSub(0,moduleInfo)
    cgfWidthList.append(log2Ceil(lastAddr))
  }

  class ModuleGen(cfgFile:String,modInsName : String,moduleInfo: ModuleInfo,cfgList:List[Int])extends Module{
    override val desiredName = moduleInfo.getName()
    val cfgLevel = cfgList.indexOf(-1)
    val cfgAddrW = if(cfgLevel == 0){
      cgfWidthList.foldLeft(0)((a,b) => a+b)
    }else if(cfgLevel == -1){
      cgfWidthList.last
    }else{
      (0 until cgfWidthList.size - cfgLevel ).map{
        i => cgfWidthList(i + cfgLevel  )
      }.foldLeft(0)((a,b) => a+b)
    }

    var file:FileWriter = new FileWriter( cfgFile , true)
    val spaceNum = if(cfgLevel == -1) cgfWidthList.size else cfgLevel
    file.write("\n" + "#"*4*spaceNum +modInsName + " :")
    if (cfgLevel == 0) {
      file.write(" " + 0)
    } else if (cfgLevel == -1) {
      cfgList.foreach(ins => file.write(" " + ins))
    } else {
      for (i <- 0 until cfgLevel) {
        file.write(" " + cfgList(i))
      }
    }

    var eleAddrOff= 0
    moduleInfo.getElementLists().toList.sortBy(_._1).map{
      case(eleType , eleList) =>{
        eleList.zipWithIndex.map{
          case(ele,index) =>{
            val headBase = eleAddrOff/cfgDataW
            val headOff = eleAddrOff%cfgDataW
            eleAddrOff = eleAddrOff + getEleCfgW(eleType,ele) - 1
            val tailBase  = eleAddrOff/cfgDataW
            val tailOff = eleAddrOff%cfgDataW
            eleAddrOff = eleAddrOff + 1
            val eleName = eleTypeName(eleType) + index
            if(getEleCfgW(eleType,ele) != 0)
              file.write("\n" + "#" * 4 * (spaceNum + 1) + eleName + " :" +
                "from " + headBase.toString + " " + headOff.toString + " " + "to " + tailBase.toString + " " + tailOff.toString + " \n")
          }
        }
      }
    }

    file.close()

    val width = moduleInfo.getWidth()
    val io = IO(new Bundle() {
      val cfgEn = Input(Bool())
      val cfgAddr = Input(UInt(cfgAddrW.W))
      val cfgData =Input(UInt(cfgDataW.W))
      val dpm_ctrl = Input(UInt(2.W))       //1 or 33
      val ob_ctrl = Input(UInt(1.W))
      val inputs = Input(Vec(moduleInfo.getInPortList().size, UInt(width.W)))
      val outputs = Output(Vec(moduleInfo.getOutPortList().size, UInt(width.W)))
      val pe_cfg = Input(UInt(pe_cfgwidth.W))
    })

    val sinksUCon = new ArrayBuffer[List[Int]]
    val memberList : Map[Int, ArrayBuffer[Any]] = Map()
    (0 until moduleInfo.getOutPortList().size).map{
      i => sinksUCon.append(List(TYPE_IO.id, i))
    }

    memberList += (TYPE_Module.id -> new ArrayBuffer[Any])
    moduleInfo.getModuleInsts().zipWithIndex.map{
      case(modType, i) =>{
        val moduleInst = moduleInfo.getModuleList()(modType)
        for(j <- 0 until moduleInst.getInPortList().size){
          sinksUCon.append(List(TYPE_Module.id, i, j))
        }

        val cfgListSub = cfgList.to[ListBuffer]
        if(cfgLevel == -1){
          println("there is error")
        }else{
          cfgListSub(cfgLevel)= i + 1
        }

        val moduleSub = Module(new ModuleGen(cfgFile,moduleInst.getType()+getSubModIndex(i,moduleInfo.getModuleInsts(),moduleInfo.getModuleList()),moduleInst,cfgListSub.toList)).suggestName(moduleInst.getType()+getSubModIndex(i,moduleInfo.getModuleInsts(),moduleInfo.getModuleList()))
        memberList(TYPE_Module.id).append(moduleSub)
        moduleSub.io.cfgEn := io.cfgEn && io.cfgAddr(cfgAddrW - 1 ,cfgAddrW -  cgfWidthList(cfgLevel ) ) === (i + 1).U
        moduleSub.io.cfgAddr := io.cfgAddr
        moduleSub.io.cfgData := io.cfgData
        moduleSub.io.dpm_ctrl := io.dpm_ctrl
        moduleSub.io.ob_ctrl := io.ob_ctrl
        moduleSub.io.pe_cfg := io.pe_cfg
      }
    }

    val eleLists = moduleInfo.getElementLists().toList.sortBy(_._1)
    eleLists.map{
      case(eleType , eleList) =>{
        memberList += (eleType  -> new ArrayBuffer[Any])
        for( i <- 0 until eleList.size){
          EleType(eleType) match {
            case TYPE_md5 =>{
              memberList(eleType).append(Module(new md5_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[md5_alu].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }
            case TYPE_hash =>{
              memberList(eleType).append(Module(new hash_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2),eleList(i)(3))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[hash_alu].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }
            case TYPE_sha1 => {
              memberList(eleType).append(Module(new sha1_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha1_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_sha512 => {
              memberList(eleType).append(Module(new sha512_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha512_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_aes => {
              memberList(eleType).append(Module(new aes_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[aes_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            
            case TYPE_DPM_aes => {
              memberList(eleType).append(Module(new DPM_aes(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_aes].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_sm3 => {
              memberList(eleType).append(Module(new sm3_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sm3_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }
            case TYPE_sha1_2cycle => {
              memberList(eleType).append(Module(new sha1_2cycle_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha1_2cycle_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }
            case TYPE_sha1_new => {
              memberList(eleType).append(Module(new sha1_new_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha1_new_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_md5_multi => {
              memberList(eleType).append(Module(new md5_multi(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[md5_multi].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }case TYPE_sha1_multi => {
              memberList(eleType).append(Module(new sha1_multi(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha1_multi].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }case TYPE_sha256_multi => {
              memberList(eleType).append(Module(new sha256_multi(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha256_multi].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_sha1_regout => {
              memberList(eleType).append(Module(new sha1_regout_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha1_regout_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_sha1_regout => {
              memberList(eleType).append(Module(new sha1_regout_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha1_regout_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_md5_sha1_sha256 => {
              memberList(eleType).append(Module(new md5_sha1_sha256_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[md5_sha1_sha256_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }


            case TYPE_md5_sha1_sha256_2cycle => {
              memberList(eleType).append(Module(new md5_sha1_sha256_2cycle_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_md5_new => {
              memberList(eleType).append(Module(new md5_new_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[md5_new_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_sha256_new => {
              memberList(eleType).append(Module(new sha256_new_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha256_new_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }
            case TYPE_sha224 => {
              memberList(eleType).append(Module(new sha224_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha224_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }
            case TYPE_sha256 => {
              memberList(eleType).append(Module(new sha256_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha256_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_sha384_32 => {
              memberList(eleType).append(Module(new sha384_32_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[sha384_32_alu].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_md5_sha1 =>{
              memberList(eleType).append(Module(new md5_sha1_alu(eleTypeName(eleType) + i,eleList(i)(0),eleList(i)(1),eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[md5_sha1_alu].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }
            case TYPE_DPM => {
              memberList(eleType).append(Module(new DPM(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2), eleList(i)(3), eleList(i)(4), eleList(i)(5))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }
            case TYPE_DPM_md5_sha1_sha256 => {
              memberList(eleType).append(Module(new DPM_md5_sha1_sha256(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_md5_sha1_sha256].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_md5_sha1_sha256_2cycle => {
              memberList(eleType).append(Module(new DPM_md5_sha1_sha256_2cycle(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_new => {
              memberList(eleType).append(Module(new DPM_new(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_new].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_md5_multi => {
              memberList(eleType).append(Module(new DPM_md5_multi(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_md5_multi].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_sha1_multi => {
              memberList(eleType).append(Module(new DPM_sha1_multi(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_sha1_multi].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_sha1 => {
              memberList(eleType).append(Module(new DPM_sha1(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_sha1].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_sha512 => {
              memberList(eleType).append(Module(new DPM_sha512(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_sha512].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_sm3 => {
              memberList(eleType).append(Module(new DPM_sm3(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_sm3].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_sha256 => {
              memberList(eleType).append(Module(new DPM_sha256(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_sha256].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_md5 => {
              memberList(eleType).append(Module(new DPM_md5(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_md5].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_DPM_sha256_multi => {
              memberList(eleType).append(Module(new DPM_sha256_multi(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1), eleList(i)(2))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[DPM_sha256_multi].io.inputs.size){
                sinksUCon.append(List(eleType,i,j))
              }
            }

            case TYPE_Multiplexer => {
              memberList(eleType).append(Module(new Multiplexer(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[Multiplexer].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }
            case TYPE_MultiplexerR => {
              memberList(eleType).append(Module(new MultiplexerR(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[MultiplexerR].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }

            case TYPE_IB => {
              memberList(eleType).append(Module(new IB(eleTypeName(eleType) + i, eleList(i)(0))).suggestName(eleTypeName(eleType) + i))
              sinksUCon.append(List(eleType, i, 0))
            }
            case TYPE_OB => {
              memberList(eleType).append(Module(new OB(eleTypeName(eleType) + i, eleList(i)(0), eleList(i)(1))).suggestName(eleTypeName(eleType) + i))
              for (j <- 0 until memberList(eleType)(i).asInstanceOf[OB].io.inputs.size) {
                sinksUCon.append(List(eleType, i, j))
              }
            }
          }
        }
      }
    }


    if(moduleInfo.getCfgW() != 0){
      val cfgMemIns = Module(new CfgMem(moduleInfo.getCfgW()))
      /*if(moduleInfo.getModuleInsts().size == 0){
        cfgMemIns.io.cfgEn := io.cfgEn
      }else {
        cfgMemIns.io.cfgEn := io.cfgEn && io.cfgAddr(cfgAddrW - 1, cfgAddrW - cgfWidthList(cfgLevel)) === 0.U
      }*/
      if(moduleInfo.getModuleInsts().size == 0){
        cfgMemIns.io.cfgEn := io.cfgEn
      }else {
        cfgMemIns.io.cfgEn := io.cfgEn && io.cfgAddr(cfgAddrW - 1, cfgAddrW - cgfWidthList(cfgLevel)) === 0.U
      }
      if(cfgMemIns.io.cfgAddr.getWidth != 0) {
        cfgMemIns.io.cfgAddr := io.cfgAddr(cfgMemIns.io.cfgAddr.getWidth - 1, 0)
      }else{
        cfgMemIns.io.cfgAddr := DontCare
      }
      cfgMemIns.io.cfgData := io.cfgData
      cfgMemIns.io.dpm_ctrlin := io.dpm_ctrl
      cfgMemIns.io.ob_ctrlin := io.ob_ctrl
      cfgMemIns.io.pe_cfgin := io.pe_cfg


      val eleCfgLists = moduleInfo.getCfgList().toList.sortBy(i => i._1)
      var eleCfgOff= 0
      eleCfgLists.map{
        case(eleType , eleCfgList) =>{
          eleCfgList.zipWithIndex.map{
            case(eleCfgW,i) =>{
              EleType(eleType) match {
//                case TYPE_md5 => memberList(eleType)(i).asInstanceOf[md5_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_md5 => memberList(eleType)(i).asInstanceOf[md5_alu].io.cfg := cfgMemIns.io.pe_cfgout
                case TYPE_hash => memberList(eleType)(i).asInstanceOf[hash_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
//                case TYPE_sha1 => memberList(eleType)(i).asInstanceOf[sha1_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_sha1 => memberList(eleType)(i).asInstanceOf[sha1_alu].io.cfg := cfgMemIns.io.pe_cfgout
                //case TYPE_sha1_2cycle => memberList(eleType)(i).asInstanceOf[sha1_2cycle_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                //case TYPE_sha1_new=> memberList(eleType)(i).asInstanceOf[sha1_new_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_sha1_multi => memberList(eleType)(i).asInstanceOf[sha1_multi].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_sha256_multi => memberList(eleType)(i).asInstanceOf[sha256_multi].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_md5_multi => memberList(eleType)(i).asInstanceOf[md5_multi].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_md5_sha1_sha256 => memberList(eleType)(i).asInstanceOf[md5_sha1_sha256_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_md5_sha1_sha256_2cycle => memberList(eleType)(i).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_sha224 => memberList(eleType)(i).asInstanceOf[sha224_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
//                case TYPE_sha256 => memberList(eleType)(i).asInstanceOf[sha256_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_sha256 => memberList(eleType)(i).asInstanceOf[sha256_alu].io.cfg := cfgMemIns.io.pe_cfgout
                case TYPE_sha512 => memberList(eleType)(i).asInstanceOf[sha512_alu].io.cfg := cfgMemIns.io.pe_cfgout
//                case TYPE_sm3 => memberList(eleType)(i).asInstanceOf[sm3_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_sm3 => memberList(eleType)(i).asInstanceOf[sm3_alu].io.cfg := cfgMemIns.io.pe_cfgout
                case TYPE_sha384_32 => memberList(eleType)(i).asInstanceOf[sha384_32_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_md5_sha1 => memberList(eleType)(i).asInstanceOf[md5_sha1_alu].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_DPM => memberList(eleType)(i).asInstanceOf[DPM].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_md5_multi => memberList(eleType)(i).asInstanceOf[DPM_md5_multi].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_sha1_multi => memberList(eleType)(i).asInstanceOf[DPM_sha1_multi].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_sha1 => memberList(eleType)(i).asInstanceOf[DPM_sha1].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_sha512 => memberList(eleType)(i).asInstanceOf[DPM_sha512].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_sm3 => memberList(eleType)(i).asInstanceOf[DPM_sm3].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_sha256 => memberList(eleType)(i).asInstanceOf[DPM_sha256].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_md5 => memberList(eleType)(i).asInstanceOf[DPM_md5].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_sha256_multi => memberList(eleType)(i).asInstanceOf[DPM_sha256_multi].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_md5_sha1_sha256 => memberList(eleType)(i).asInstanceOf[DPM_md5_sha1_sha256].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_DPM_md5_sha1_sha256_2cycle => memberList(eleType)(i).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.cfg := cfgMemIns.io.dpm_ctrlout
                case TYPE_Multiplexer => memberList(eleType)(i).asInstanceOf[Multiplexer].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1 ,eleCfgOff)
                case TYPE_MultiplexerR => memberList(eleType)(i).asInstanceOf[MultiplexerR].io.cfg := cfgMemIns.io.cfgOut(eleCfgW + eleCfgOff - 1, eleCfgOff)
                case TYPE_OB => memberList(eleType)(i).asInstanceOf[OB].io.cfg := cfgMemIns.io.ob_ctrlout
                case _ =>
              }
              eleCfgOff = eleCfgOff + eleCfgW
            }
          }
        }
      }

    }
    if(modInsName == "TOP") {
      moduleInfo.getConnect().map {
        case (source, sinkList) =>
          val fromPort = {
            EleType(source(0)) match {
              case TYPE_IO => io.inputs(source(1))
              case TYPE_Module => memberList(source(0))(source(1)).asInstanceOf[ModuleGen].io.outputs(source(2))
              case TYPE_md5 => memberList(source(0))(source(1)).asInstanceOf[md5_alu].io.outputs(source(2))
              case TYPE_hash => memberList(source(0))(source(1)).asInstanceOf[hash_alu].io.outputs(source(2))
              case TYPE_sha1 => memberList(source(0))(source(1)).asInstanceOf[sha1_alu].io.outputs(source(2))
              case TYPE_sha512 => memberList(source(0))(source(1)).asInstanceOf[sha512_alu].io.outputs(source(2))
              case TYPE_sm3 => memberList(source(0))(source(1)).asInstanceOf[sm3_alu].io.outputs(source(2))
              case TYPE_sha1_2cycle => memberList(source(0))(source(1)).asInstanceOf[sha1_2cycle_alu].io.outputs(source(2))
              case TYPE_sha1_new => memberList(source(0))(source(1)).asInstanceOf[sha1_new_alu].io.outputs(source(2))
              case TYPE_md5_multi => memberList(source(0))(source(1)).asInstanceOf[md5_multi].io.outputs(source(2))
              case TYPE_sha1_multi => memberList(source(0))(source(1)).asInstanceOf[sha1_multi].io.outputs(source(2))
              case TYPE_sha256_multi => memberList(source(0))(source(1)).asInstanceOf[sha256_multi].io.outputs(source(2))
              case TYPE_sha1_regout => memberList(source(0))(source(1)).asInstanceOf[sha1_regout_alu].io.outputs(source(2))
              case TYPE_md5_sha1_sha256 => memberList(source(0))(source(1)).asInstanceOf[md5_sha1_sha256_alu].io.outputs(source(2))
              case TYPE_md5_sha1_sha256_2cycle => memberList(source(0))(source(1)).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.outputs(source(2))
              case TYPE_md5_new => memberList(source(0))(source(1)).asInstanceOf[md5_new_alu].io.outputs(source(2))
              case TYPE_sha256_new => memberList(source(0))(source(1)).asInstanceOf[sha256_new_alu].io.outputs(source(2))
              case TYPE_sha224 => memberList(source(0))(source(1)).asInstanceOf[sha224_alu].io.outputs(source(2))
              case TYPE_sha256 => memberList(source(0))(source(1)).asInstanceOf[sha256_alu].io.outputs(source(2))
              case TYPE_sha384_32 => memberList(source(0))(source(1)).asInstanceOf[sha384_32_alu].io.outputs(source(2))
              case TYPE_md5_sha1 => memberList(source(0))(source(1)).asInstanceOf[md5_sha1_alu].io.outputs(source(2))
              case TYPE_DPM => memberList(source(0))(source(1)).asInstanceOf[DPM].io.outputs(source(2))
              case TYPE_DPM_md5_multi => memberList(source(0))(source(1)).asInstanceOf[DPM_md5_multi].io.outputs(source(2))
              case TYPE_DPM_sha1_multi => memberList(source(0))(source(1)).asInstanceOf[DPM_sha1_multi].io.outputs(source(2))
              case TYPE_DPM_sha1 => memberList(source(0))(source(1)).asInstanceOf[DPM_sha1].io.outputs(source(2))
              case TYPE_DPM_sha512 => memberList(source(0))(source(1)).asInstanceOf[DPM_sha512].io.outputs(source(2))
              case TYPE_DPM_sm3 => memberList(source(0))(source(1)).asInstanceOf[DPM_sm3].io.outputs(source(2))
              case TYPE_DPM_sha256 => memberList(source(0))(source(1)).asInstanceOf[DPM_sha256].io.outputs(source(2))
              case TYPE_DPM_md5 => memberList(source(0))(source(1)).asInstanceOf[DPM_md5].io.outputs(source(2))
              case TYPE_DPM_sha256_multi => memberList(source(0))(source(1)).asInstanceOf[DPM_sha256_multi].io.outputs(source(2))
              case TYPE_DPM_md5_sha1_sha256 => memberList(source(0))(source(1)).asInstanceOf[DPM_md5_sha1_sha256].io.outputs(source(2))
              case TYPE_DPM_md5_sha1_sha256_2cycle => memberList(source(0))(source(1)).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.outputs(source(2))
              case TYPE_DPM_new => memberList(source(0))(source(1)).asInstanceOf[DPM_new].io.outputs(source(2))
              case TYPE_Multiplexer => memberList(source(0))(source(1)).asInstanceOf[Multiplexer].io.outputs(source(2))
              case TYPE_MultiplexerR => memberList(source(0))(source(1)).asInstanceOf[MultiplexerR].io.outputs(source(2))
              case TYPE_IB => memberList(source(0))(source(1)).asInstanceOf[IB].io.outputs(source(2))
              case TYPE_OB => memberList(source(0))(source(1)).asInstanceOf[OB].io.outputs(source(2))
              case TYPE_aes => memberList(source(0))(source(1)).asInstanceOf[aes_alu].io.outputs(source(2))
              case TYPE_DPM_aes => memberList(source(0))(source(1)).asInstanceOf[DPM_aes].io.outputs(source(2))
              case _ => DontCare
            }
          }

          sinkList.map {
            sink => {
              val toPort =
                EleType(sink(0)) match {
                  case TYPE_IO => io.outputs(sink(1))
                  case TYPE_Module => memberList(sink(0))(sink(1)).asInstanceOf[ModuleGen].io.inputs(sink(2))
                  case TYPE_md5 => memberList(sink(0))(sink(1)).asInstanceOf[md5_alu].io.inputs(sink(2))
                  case TYPE_hash => memberList(sink(0))(sink(1)).asInstanceOf[hash_alu].io.inputs(sink(2))
                  case TYPE_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[sha1_alu].io.inputs(sink(2))
                  case TYPE_sha512 => memberList(sink(0))(sink(1)).asInstanceOf[sha512_alu].io.inputs(sink(2))
                  case TYPE_sm3 => memberList(sink(0))(sink(1)).asInstanceOf[sm3_alu].io.inputs(sink(2))
                  case TYPE_sha1_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[sha1_2cycle_alu].io.inputs(sink(2))
                  case TYPE_sha1_new => memberList(sink(0))(sink(1)).asInstanceOf[sha1_new_alu].io.inputs(sink(2))
                  case TYPE_md5_multi => memberList(sink(0))(sink(1)).asInstanceOf[md5_multi].io.inputs(sink(2))
                  case TYPE_sha1_multi => memberList(sink(0))(sink(1)).asInstanceOf[sha1_multi].io.inputs(sink(2))
                  case TYPE_sha256_multi => memberList(sink(0))(sink(1)).asInstanceOf[sha256_multi].io.inputs(sink(2))
                  case TYPE_sha1_regout => memberList(sink(0))(sink(1)).asInstanceOf[sha1_regout_alu].io.inputs(sink(2))
                  case TYPE_md5_sha1_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_sha256_alu].io.inputs(sink(2))
                  case TYPE_md5_sha1_sha256_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.inputs(sink(2))
                  case TYPE_md5_new => memberList(sink(0))(sink(1)).asInstanceOf[md5_new_alu].io.inputs(sink(2))
                  case TYPE_sha256_new => memberList(sink(0))(sink(1)).asInstanceOf[sha256_new_alu].io.inputs(sink(2))
                  case TYPE_sha224 => memberList(sink(0))(sink(1)).asInstanceOf[sha224_alu].io.inputs(sink(2))
                  case TYPE_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[sha256_alu].io.inputs(sink(2))
                  case TYPE_sha384_32 => memberList(sink(0))(sink(1)).asInstanceOf[sha384_32_alu].io.inputs(sink(2))
                  case TYPE_md5_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_alu].io.inputs(sink(2))
                  case TYPE_DPM => memberList(sink(0))(sink(1)).asInstanceOf[DPM].io.inputs(sink(2))
                  case TYPE_DPM_md5_sha1_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_sha1_sha256].io.inputs(sink(2))
                  case TYPE_DPM_md5_sha1_sha256_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.inputs(sink(2))
                  case TYPE_DPM_new => memberList(sink(0))(sink(1)).asInstanceOf[DPM_new].io.inputs(sink(2))
                  case TYPE_DPM_md5_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_multi].io.inputs(sink(2))
                  case TYPE_DPM_sha1_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha1_multi].io.inputs(sink(2))
                  case TYPE_DPM_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha1].io.inputs(sink(2))
                  case TYPE_DPM_sha512 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha512].io.inputs(sink(2))
                  case TYPE_DPM_sm3 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sm3].io.inputs(sink(2))
                  case TYPE_DPM_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha256].io.inputs(sink(2))
                  case TYPE_DPM_md5=> memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5].io.inputs(sink(2))
                  case TYPE_DPM_sha256_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha256_multi].io.inputs(sink(2))
                  case TYPE_Multiplexer => memberList(sink(0))(sink(1)).asInstanceOf[Multiplexer].io.inputs(sink(2))
                  case TYPE_MultiplexerR => memberList(sink(0))(sink(1)).asInstanceOf[MultiplexerR].io.inputs(sink(2))
                  case TYPE_IB => memberList(sink(0))(sink(1)).asInstanceOf[IB].io.inputs(sink(2))
                  case TYPE_OB => memberList(sink(0))(sink(1)).asInstanceOf[OB].io.inputs(sink(2))
                  case TYPE_aes => memberList(sink(0))(sink(1)).asInstanceOf[aes_alu].io.inputs(sink(2))
                  case TYPE_DPM_aes => memberList(sink(0))(sink(1)).asInstanceOf[DPM_aes].io.inputs(sink(2))
                  case _ => DontCare
                }
              toPort := fromPort
              sinksUCon -= sink
            }
          }
      }
    }
    else moduleInfo.getConnect().map {
      case (source, sinkList) => {
        val fromPort = {
          EleType(source(0)) match {
            case TYPE_IO => io.inputs(source(1))
            case TYPE_Module => memberList(source(0))(source(1)).asInstanceOf[ModuleGen].io.outputs(source(2))
            case TYPE_md5 => memberList(source(0))(source(1)).asInstanceOf[md5_alu].io.outputs(source(2))
            case TYPE_hash => memberList(source(0))(source(1)).asInstanceOf[hash_alu].io.outputs(source(2))
            case TYPE_sha1 => memberList(source(0))(source(1)).asInstanceOf[sha1_alu].io.outputs(source(2))
            case TYPE_sha512 => memberList(source(0))(source(1)).asInstanceOf[sha512_alu].io.outputs(source(2))
            case TYPE_sm3 => memberList(source(0))(source(1)).asInstanceOf[sm3_alu].io.outputs(source(2))
            case TYPE_sha1_2cycle => memberList(source(0))(source(1)).asInstanceOf[sha1_2cycle_alu].io.outputs(source(2))
            case TYPE_sha1_new => memberList(source(0))(source(1)).asInstanceOf[sha1_new_alu].io.outputs(source(2))
            case TYPE_md5_multi => memberList(source(0))(source(1)).asInstanceOf[md5_multi].io.outputs(source(2))
            case TYPE_sha1_multi => memberList(source(0))(source(1)).asInstanceOf[sha1_multi].io.outputs(source(2))
            case TYPE_sha256_multi => memberList(source(0))(source(1)).asInstanceOf[sha256_multi].io.outputs(source(2))
            case TYPE_sha1_regout => memberList(source(0))(source(1)).asInstanceOf[sha1_regout_alu].io.outputs(source(2))
            case TYPE_md5_sha1_sha256 => memberList(source(0))(source(1)).asInstanceOf[md5_sha1_sha256_alu].io.outputs(source(2))
            case TYPE_md5_sha1_sha256_2cycle => memberList(source(0))(source(1)).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.outputs(source(2))
            case TYPE_md5_new => memberList(source(0))(source(1)).asInstanceOf[md5_new_alu].io.outputs(source(2))
            case TYPE_sha256_new => memberList(source(0))(source(1)).asInstanceOf[sha256_new_alu].io.outputs(source(2))
            case TYPE_sha224 => memberList(source(0))(source(1)).asInstanceOf[sha224_alu].io.outputs(source(2))
            case TYPE_sha256 => memberList(source(0))(source(1)).asInstanceOf[sha256_alu].io.outputs(source(2))
            case TYPE_sha384_32 => memberList(source(0))(source(1)).asInstanceOf[sha384_32_alu].io.outputs(source(2))
            case TYPE_md5_sha1 => memberList(source(0))(source(1)).asInstanceOf[md5_sha1_alu].io.outputs(source(2))
            case TYPE_DPM => memberList(source(0))(source(1)).asInstanceOf[DPM].io.outputs(source(2))
            case TYPE_DPM_md5_sha1_sha256 => memberList(source(0))(source(1)).asInstanceOf[DPM_md5_sha1_sha256].io.outputs(source(2))
            case TYPE_DPM_md5_sha1_sha256_2cycle => memberList(source(0))(source(1)).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.outputs(source(2))
            case TYPE_DPM_new => memberList(source(0))(source(1)).asInstanceOf[DPM_new].io.outputs(source(2))
            case TYPE_DPM_sha1_multi => memberList(source(0))(source(1)).asInstanceOf[DPM_sha1_multi].io.outputs(source(2))
            case TYPE_DPM_sha1 => memberList(source(0))(source(1)).asInstanceOf[DPM_sha1].io.outputs(source(2))
            case TYPE_DPM_sha512 => memberList(source(0))(source(1)).asInstanceOf[DPM_sha512].io.outputs(source(2))
            case TYPE_DPM_sm3 => memberList(source(0))(source(1)).asInstanceOf[DPM_sm3].io.outputs(source(2))
            case TYPE_DPM_sha256 => memberList(source(0))(source(1)).asInstanceOf[DPM_sha256].io.outputs(source(2))
            case TYPE_DPM_md5 => memberList(source(0))(source(1)).asInstanceOf[DPM_md5].io.outputs(source(2))
            case TYPE_DPM_sha256_multi => memberList(source(0))(source(1)).asInstanceOf[DPM_sha256_multi].io.outputs(source(2))
            case TYPE_Multiplexer => memberList(source(0))(source(1)).asInstanceOf[Multiplexer].io.outputs(source(2))
            case TYPE_MultiplexerR => memberList(source(0))(source(1)).asInstanceOf[MultiplexerR].io.outputs(source(2))
            case TYPE_IB => memberList(source(0))(source(1)).asInstanceOf[IB].io.outputs(source(2))
            case TYPE_OB => memberList(source(0))(source(1)).asInstanceOf[OB].io.outputs(source(2))
            case TYPE_aes => memberList(source(0))(source(1)).asInstanceOf[aes_alu].io.outputs(source(2))
            case TYPE_DPM_aes => memberList(source(0))(source(1)).asInstanceOf[DPM_aes].io.outputs(source(2))
            case _ => DontCare
          }
        }

        sinkList.map {
          sink => {
            val toPort =
              EleType(sink(0)) match {
                case TYPE_IO => io.outputs(sink(1))
                case TYPE_Module => memberList(sink(0))(sink(1)).asInstanceOf[ModuleGen].io.inputs(sink(2))
                case TYPE_md5 => memberList(sink(0))(sink(1)).asInstanceOf[md5_alu].io.inputs(sink(2))
                case TYPE_hash => memberList(sink(0))(sink(1)).asInstanceOf[hash_alu].io.inputs(sink(2))
                case TYPE_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[sha1_alu].io.inputs(sink(2))
                case TYPE_sha512 => memberList(sink(0))(sink(1)).asInstanceOf[sha512_alu].io.inputs(sink(2))
                case TYPE_sm3 => memberList(sink(0))(sink(1)).asInstanceOf[sm3_alu].io.inputs(sink(2))
                case TYPE_sha1_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[sha1_2cycle_alu].io.inputs(sink(2))
                case TYPE_sha1_new => memberList(sink(0))(sink(1)).asInstanceOf[sha1_new_alu].io.inputs(sink(2))
                case TYPE_md5_multi => memberList(sink(0))(sink(1)).asInstanceOf[md5_multi].io.inputs(sink(2))
                case TYPE_sha1_multi => memberList(sink(0))(sink(1)).asInstanceOf[sha1_multi].io.inputs(sink(2))
                case TYPE_sha256_multi => memberList(sink(0))(sink(1)).asInstanceOf[sha256_multi].io.inputs(sink(2))
                case TYPE_sha1_regout => memberList(sink(0))(sink(1)).asInstanceOf[sha1_regout_alu].io.inputs(sink(2))
                case TYPE_md5_sha1_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_sha256_alu].io.inputs(sink(2))
                case TYPE_md5_sha1_sha256_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.inputs(sink(2))
                case TYPE_sha256_new => memberList(sink(0))(sink(1)).asInstanceOf[sha256_new_alu].io.inputs(sink(2))
                case TYPE_md5_new => memberList(sink(0))(sink(1)).asInstanceOf[md5_new_alu].io.inputs(sink(2))
                case TYPE_sha224 => memberList(sink(0))(sink(1)).asInstanceOf[sha224_alu].io.inputs(sink(2))
                case TYPE_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[sha256_alu].io.inputs(sink(2))
                case TYPE_sha384_32 => memberList(sink(0))(sink(1)).asInstanceOf[sha384_32_alu].io.inputs(sink(2))
                case TYPE_md5_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_alu].io.inputs(sink(2))
                case TYPE_DPM => memberList(sink(0))(sink(1)).asInstanceOf[DPM].io.inputs(sink(2))
                case TYPE_DPM_md5_sha1_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_sha1_sha256].io.inputs(sink(2))
                case TYPE_DPM_md5_sha1_sha256_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.inputs(sink(2))
                case TYPE_DPM_new => memberList(sink(0))(sink(1)).asInstanceOf[DPM_new].io.inputs(sink(2))
                case TYPE_DPM_sha1_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha1_multi].io.inputs(sink(2))
                case TYPE_DPM_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha1].io.inputs(sink(2))
                case TYPE_DPM_sha512 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha512].io.inputs(sink(2))
                case TYPE_DPM_sm3 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sm3].io.inputs(sink(2))
                case TYPE_DPM_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha256].io.inputs(sink(2))
                case TYPE_DPM_md5 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5].io.inputs(sink(2))
                case TYPE_DPM_sha256_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha256_multi].io.inputs(sink(2))
                case TYPE_Multiplexer => memberList(sink(0))(sink(1)).asInstanceOf[Multiplexer].io.inputs(sink(2))
                case TYPE_MultiplexerR => memberList(sink(0))(sink(1)).asInstanceOf[MultiplexerR].io.inputs(sink(2))
                case TYPE_IB => memberList(sink(0))(sink(1)).asInstanceOf[IB].io.inputs(sink(2))
                case TYPE_OB => memberList(sink(0))(sink(1)).asInstanceOf[OB].io.inputs(sink(2))
                case TYPE_aes => memberList(sink(0))(sink(1)).asInstanceOf[aes_alu].io.inputs(sink(2))
                case TYPE_DPM_aes => memberList(sink(0))(sink(1)).asInstanceOf[DPM_aes].io.inputs(sink(2))
                case _ => DontCare
              }
            toPort := fromPort
            sinksUCon -= sink
          }
        }
      }
    }


    sinksUCon.map(sink => {
      val toPort = EleType(sink(0)) match {
        case TYPE_IO => io.outputs(sink(1))
        case TYPE_Module => memberList(sink(0))(sink(1)).asInstanceOf[ModuleGen].io.inputs(sink(2))
        case TYPE_md5 => memberList(sink(0))(sink(1)).asInstanceOf[md5_alu].io.inputs(sink(2))
        case TYPE_md5 => memberList(sink(0))(sink(1)).asInstanceOf[hash_alu].io.inputs(sink(2))
        case TYPE_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[sha1_alu].io.inputs(sink(2))
        case TYPE_sha512 => memberList(sink(0))(sink(1)).asInstanceOf[sha512_alu].io.inputs(sink(2))
        case TYPE_sm3 => memberList(sink(0))(sink(1)).asInstanceOf[sm3_alu].io.inputs(sink(2))
        case TYPE_sha1_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[sha1_2cycle_alu].io.inputs(sink(2))
        case TYPE_sha1_new => memberList(sink(0))(sink(1)).asInstanceOf[sha1_new_alu].io.inputs(sink(2))
        case TYPE_md5_multi => memberList(sink(0))(sink(1)).asInstanceOf[md5_multi].io.inputs(sink(2))
        case TYPE_sha1_multi => memberList(sink(0))(sink(1)).asInstanceOf[sha1_multi].io.inputs(sink(2))
        case TYPE_sha256_multi => memberList(sink(0))(sink(1)).asInstanceOf[sha256_multi].io.inputs(sink(2))
        case TYPE_sha1_regout => memberList(sink(0))(sink(1)).asInstanceOf[sha1_regout_alu].io.inputs(sink(2))
        case TYPE_md5_sha1_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_sha256_alu].io.inputs(sink(2))
        case TYPE_md5_sha1_sha256_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_sha256_2cycle_alu].io.inputs(sink(2))
        case TYPE_sha256_new => memberList(sink(0))(sink(1)).asInstanceOf[sha256_new_alu].io.inputs(sink(2))
        case TYPE_md5_new => memberList(sink(0))(sink(1)).asInstanceOf[md5_new_alu].io.inputs(sink(2))
        case TYPE_sha224 => memberList(sink(0))(sink(1)).asInstanceOf[sha224_alu].io.inputs(sink(2))
        case TYPE_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[sha256_alu].io.inputs(sink(2))
        case TYPE_sha384_32 => memberList(sink(0))(sink(1)).asInstanceOf[sha384_32_alu].io.inputs(sink(2))
        case TYPE_md5_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[md5_sha1_alu].io.inputs(sink(2))
        case TYPE_DPM => memberList(sink(0))(sink(1)).asInstanceOf[DPM].io.inputs(sink(2))
        case TYPE_DPM_md5_sha1_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_sha1_sha256].io.inputs(sink(2))
        case TYPE_DPM_md5_sha1_sha256_2cycle => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5_sha1_sha256_2cycle].io.inputs(sink(2))
        case TYPE_DPM_new => memberList(sink(0))(sink(1)).asInstanceOf[DPM_new].io.inputs(sink(2))
        case TYPE_DPM_sha1_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha1_multi].io.inputs(sink(2))
        case TYPE_DPM_sha1 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha1].io.inputs(sink(2))
        case TYPE_DPM_sha512 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha512].io.inputs(sink(2))
        case TYPE_DPM_sm3 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sm3].io.inputs(sink(2))
        case TYPE_DPM_sha256 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha256].io.inputs(sink(2))
        case TYPE_DPM_md5 => memberList(sink(0))(sink(1)).asInstanceOf[DPM_md5].io.inputs(sink(2))
        case TYPE_DPM_sha256_multi => memberList(sink(0))(sink(1)).asInstanceOf[DPM_sha256_multi].io.inputs(sink(2))
        case TYPE_Multiplexer => memberList(sink(0))(sink(1)).asInstanceOf[Multiplexer].io.inputs(sink(2))
        case TYPE_MultiplexerR => memberList(sink(0))(sink(1)).asInstanceOf[MultiplexerR].io.inputs(sink(2))
        case TYPE_IB => memberList(sink(0))(sink(1)).asInstanceOf[IB].io.inputs(sink(2))
        case TYPE_OB => memberList(sink(0))(sink(1)).asInstanceOf[OB].io.inputs(sink(2))
        case TYPE_aes => memberList(sink(0))(sink(1)).asInstanceOf[aes_alu].io.inputs(sink(2))
        case TYPE_DPM_aes => memberList(sink(0))(sink(1)).asInstanceOf[DPM_aes].io.inputs(sink(2))
      }
      toPort := 0.U
    })

  }


  def topGen(module:ModuleInfo,cfgFile:String ) ={
    getWidthList(module)
    val file:FileWriter = new FileWriter( cfgFile , false)
    file.write("adress width : ")
    cgfWidthList.foreach(ins => file.write(" " + ins))
    file.write("\n")
    file.close()

    new ModuleGen(cfgFile,"TOP", module,(0 until cgfWidthList.size).map(ins => -1).toList)
  }
}
