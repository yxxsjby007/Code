package dsa.module

object dsaParam {

  class IBParam(maxDelay_ : Int, width_ : Int, deviceName_ : String) {
    val maxDelay = maxDelay_
    //    val outPortsNum = outPortsNum_
    val width = width_
    val deviceName = deviceName_
  }

  object IBParam {
    def apply(maxDelay_ : Int, width_ : Int, deviceName_ : String): IBParam = {
      new IBParam(maxDelay_, width_, deviceName_)
    }
  }


  class OBParam(inPortsNum_ : Int, width_ : Int, deviceName_ : String) {
    val inPortsNum = inPortsNum_
    val width = width_
    val deviceName = deviceName_
  }

  object OBParam {
    def apply(inPortsNum_ : Int, width_ : Int, deviceName_ : String): OBParam = {
      new OBParam(inPortsNum_, width_, deviceName_)
    }
  }

  class MuxParam(inPortsNum_ : Int, width_ : Int, deviceName_ : String) {
    val inPortsNum = inPortsNum_
    val width = width_
    val deviceName = deviceName_
  }

  object MuxParam {
    def apply(inPortsNum_ : Int, width_ : Int, deviceName_ : String): MuxParam = {
      new MuxParam(inPortsNum_, width_, deviceName_)
    }
  }

  class alu_Param(alu_type_ : String, in_num_ : Int, out_num_ : Int, Param_ : List[Int], alu_name_ : String) {
    val alu_type = alu_type_
    val in_num = in_num_
    val out_num = out_num_
    val param = Param_
    val alu_name = alu_name_
  }

  object alu_Param {
    def apply(alu_type_ : String, in_num_ : Int, out_num_ : Int, Param_ : List[Int], alu_name_ : String): alu_Param = {
      new alu_Param(alu_type_, in_num_, out_num_, Param_, alu_name_)
    }
  }

  class PEParam(width_ : Int, deviceName_ : String, alu_num_ :Int, alu_Params_ : List[alu_Param]) {
    val width = width_
    val deviceName = deviceName_
    val alu_num = alu_num_
    val alu_Params = alu_Params_

  }

  object PEParam{
    def apply(width_ :Int, deviceName_ : String, alu_num_ :Int, alu_Params_ : List[alu_Param]) : PEParam = {
      new PEParam(width_, deviceName_, alu_num_, alu_Params_)
    }
  }

  class dsa_Param(PE_num_ :Int, IB_num_ : Int, OB_num_ : Int, peParams_ : List[PEParam]) {
    val PE_num = PE_num_
    val IB_num = IB_num_
    val OB_num = OB_num_
    val peParams = peParams_
  }

  object dsa_Param{
    def apply(PE_num_ :Int,  IB_num_ : Int, OB_num_ : Int, peParams_ : List[PEParam]) : dsa_Param = {
      new dsa_Param(PE_num_,  IB_num_, OB_num_, peParams_)
    }
  }

  object DPM_Param{
    def apply(IN_num_ :Int, OUT_num_ :Int, Width_ :Int) : DPM_Param = {
      new DPM_Param(IN_num_ , OUT_num_, Width_)
    }
  }

  class  DPM_Param(IN_num_ :Int, OUT_num_ :Int, Width_ :Int) {
    val in_num = IN_num_
    val out_num = OUT_num_
    val width = Width_
  }


  object Connect{
    def apply(Out_obj_ :String, OobjNo_ :Int, out_No_ :Int, In_obj_ :String, IobjNo_ :Int, in_No_ :Int) : Connect = {
      new Connect(Out_obj_, out_No_, In_obj_, in_No_)
    }
  }

  class Connect(Out_obj_ :String, out_No_ :Int, In_obj_ :String, in_No_ :Int) {
    val Out_obj = Out_obj_
    val out_No = out_No_
    val In_obj = In_obj_
    val in_No = in_No_
  }

  object Connect_Params{
    def apply(cn_ :List[Connect]) : Connect_Params = {
      new Connect_Params(cn_)
    }
  }

  class Connect_Params(cn_ :List[Connect]) {
    val cn = cn_
    val cn_length = cn.length
  }
}