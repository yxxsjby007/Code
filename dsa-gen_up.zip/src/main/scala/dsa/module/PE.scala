
package dsa.module

import chisel3._
import chisel3.util._
import dsa.element.ALU.md5_alu
import dsa.ADL.ADL.{EleTrace, ModuleTrace}
import dsa.module.TopModule.topGen
import dsa.module.dsaParam.PEParam
import dsa.module.dsaParam.alu_Param
import dsa.parameter.EleType._
import dsa.IR.Info2Xml.dumpIR

import scala.collection.mutable.ListBuffer

//需要传入ALU的数目，和ALU对应的参数
//在下面的模块中，需要把ALU的输入输出和PE端口的输入输出连接
//然后实现，当存在多个ALU时，根据cfg选择输出PE的输出
//如果存在多个ALU时，需要加入MUX选择输出，
//添加mux数量，例如输出数为5,5,5,5时，mux数为5，当输出数为5,4,3时mux数为4
class PE(peParam: PEParam, name: String) extends ModuleTrace(name) {
  this.typeStr = "PE"
  this.deviceStr = peParam.deviceName
  this.width = peParam.width

  val inNum_max = peParam.alu_Params.map(_.in_num).max
  val inPortList_max = (0 until inNum_max).map {
    i => {
      "in" + i.toString
    }
  }.toList
  this.inPorts = inPortList_max

  val outNum_max = peParam.alu_Params.map(_.out_num).max
  val outPortList_max = (0 until outNum_max).map {
    i => {
      "out" + i.toString
    }
  }.toList
  this.outPorts = outPortList_max

  //添加mux数量，例如输出数为5,5,5,5时，mux数为5，当输出数为5,4,3时mux数为4
  val mux_count = findSecondLargest(peParam.alu_Params.map(_.out_num)).getOrElse(-1)
//  println("mux_count: " + mux_count)


  //当alu_num数目大于1时，需要添加mux，选择连接到PE.out的输出
  if(peParam.alu_num > 1) {
    val inlist = ListBuffer[String]()
    for (i <- 0 until peParam.alu_num) {
      inlist += ("in" + i)
//      println("inlist :" + inlist)
    }
//    println("inlist :" + inlist)
    for(i <- 0 until mux_count) {
      val MUX = new EleTrace("MUXPE" + i.toString, TYPE_Multiplexer.id, inlist.toList, List("out0"), List(peParam.alu_num, width))
//      println("muxcount = :" + mux_count)
      addEle(MUX)
      //添加mux和输出之间的连接

      addConnect(("MUXPE" + i.toString, "out0"),("this", "out" + i.toString))

    }

  }

  /*val inPortList = (0 until peParam.alu_Params(0).in_num).map {
    i => {
      "in" + i.toString
    }
  }.toList
  val outPortList = (0 until peParam.alu_Params(0).out_num).map {
    i => {
      "out" + i.toString
    }
  }.toList
  val aluIns = new EleTrace("ALU", TYPE_md5.id, inPortList, outPortList, peParam.alu_Params(0).param) //LM: 获取输入的ALU类型
  addEle(aluIns)

  inPortList.indices.map {
    i => addConnect(("this", "in" + i.toString), ("ALU", "in" + i.toString))
  }
  outPortList.indices.map {
    i => addConnect(("ALU", "out" + i.toString), ("this", "out" + i.toString))
  }*/
  for (i <- 0 until peParam.alu_num) {
    val alu_type = peParam.alu_Params(i).alu_type
    val aluname = peParam.alu_Params(i).alu_name
//    println("aluname : " + aluname)
    alu_type match {
      case "md5" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_md5.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }
      case "sha224" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha224.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in PE的第一个输入连接到alu的最后一个输入
        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        for(i <- 1 until peParam.alu_Params(i).in_num) {
          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha256" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha256.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha512" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha512.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sm3" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sm3.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha384_32" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha384_32.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in PE的第一个输入连接到alu的最后一个输入
        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        for(i <- 1 until peParam.alu_Params(i).in_num) {
          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }



      case "hash" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_hash.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)

        /*inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),("ALU" ,  "in" + i.toString))
        }*/
        //ALU的输入连接到PE.in PE的第一个输入连接到alu的最后一个输入
        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        for(i <- 1 until peParam.alu_Params(i).in_num) {
          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }
      case "sha1" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha1.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }
      case "sha1_2cycle" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha1_2cycle.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
//        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
//        for(i <- 1 until peParam.alu_Params(i).in_num) {
//          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
//        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "md5_new" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_md5_new.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha256_new" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha256_new.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "md5_sha1_sha256_2cycle" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_md5_sha1_sha256_2cycle.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }


       case "aes" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_aes.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        outPortList.indices.map {
          i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
        }
      }

      case "md5_sha1_sha256" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_md5_sha1_sha256.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha1_regout" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha1_regout.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }


      case "sha1_new" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha1_new.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }


      case "md5_multi" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_md5_multi.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha1_multi" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha1_multi.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "sha256_multi" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_sha256_multi.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in
        //        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
        //        for(i <- 1 until peParam.alu_Params(i).in_num) {
        //          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
        //        }

        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }

        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case "md5_sha1" => {
        val inPortList = (0 until peParam.alu_Params(i).in_num).map {
          i => {
            "in" + i.toString
          }
        }.toList
        val outPortList = (0 until peParam.alu_Params(i).out_num).map {
          i => {
            "out" + i.toString
          }
        }.toList
        val aluIns = new EleTrace(aluname, TYPE_md5_sha1.id, inPortList, outPortList, peParam.alu_Params(i).param) //LM: 获取输入的ALU类型
        addEle(aluIns)
        //ALU的输入连接到PE.in PE的第一个输入连接到alu的最后一个输入
//        addConnect(("this", "in0"), (aluname, "in" + (peParam.alu_Params(i).in_num - 1).toString))
//        for(i <- 1 until peParam.alu_Params(i).in_num) {
//          addConnect(("this", "in" + i.toString), (aluname, "in" + (i-1).toString))
//        }



        inPortList.indices.map{
          i => addConnect(("this" , "in" + i.toString),(aluname ,  "in" + i.toString))
        }
        //当只有一个alu时，ALU的输出直接连接到PE.out
        if(peParam.alu_num == 1) {
          outPortList.indices.map {
            i => addConnect((aluname, "out" + i.toString), ("this", "out" + i.toString))
          }
        }
        else {
          if(peParam.alu_Params(i).out_num > mux_count) {
            for(k <- 0 until mux_count) {
              addConnect((aluname, "out" + k.toString), ("MUXPE" + k.toString, "in" + i.toString))
            }
            for(l <- mux_count until peParam.alu_Params(i).out_num) {
              addConnect((aluname, "out" + l.toString), ("this", "out" + l.toString))
            }
          }
          else {
            outPortList.indices.map {
              j => addConnect((aluname, "out" + j.toString), ("MUXPE" + j.toString, "in" + i.toString))
            }
          }
        }
      }

      case _ => DontCare
    }
  }



  //返回第二大的值，例如3,4,5则返回4,例如3,4,4则返回4
  def findSecondLargest(lst: List[Int]): Option[Int] = {
    val distinctList = lst.sorted
    if (distinctList.length < 2) {
      None
    } else {
      Some(distinctList(distinctList.length - 2))
    }
  }

}


object PE {
  def apply(peParam: PEParam, name: String): PE = {
    new PE(peParam, name)
  }
}


//object PEFGen extends App {
//  val alu_md5_p1 = List(32, 32, 0, 2, 0, 1, 2, 3, 4, 5, 6,
//    7, 8, 9, 0, 1, 1, 1, 1, 1,0,1,2,3,4,5,6,7,8,9,
//    10,11,12,13,14,15,16,17,18,19,
//    20,21,22,23,24,25,26,27,28,29,
//    30,31,32,33,34,35,36,37,38,39,
//    40,41,42,43,44,45,46,47,48,49,
//    50,51,52,53,54,55,56,57,58,59,
//    60,61,62,63)
//  val alu_p1 = alu_Param("md5", 6, 5, alu_md5_p1, "ALU0")
//  val alu_md5_p2 = List(32, 16, 0, 2, 0, 1, 2, 3, 4, 5, 6,
//    7, 8, 9, 0, 1, 1, 1, 1, 1,0,1,2,3,4,5,6,7,8,9,
//    10,11,12,13,14,15,16,17,18,19,
//    20,21,22,23,24,25,26,27,28,29,
//    30,31,32,33,34,35,36,37,38,39,
//    40,41,42,43,44,45,46,47,48,49,
//    50,51,52,53,54,55,56,57,58,59,
//    60,61,62,63)
//  val alu_p2 = alu_Param("md5", 6, 5, alu_md5_p2, "ALU1")
//  val alu_sha1 = List(32, 1, 0, 1, 2, 3, 0, 1)
//  val alu_sha1_p1 = alu_Param("sha1", 7, 6, alu_sha1, "ALU1")
//
//  chisel3.Driver.execute(args, () => topGen(PE(PEParam(32, "PETest", 2, List(alu_p1,alu_sha1_p1)), "PE").getModuleInfo(), "PETest.txt")) //生成verilog
//  dumpIR(PE(PEParam(32, "PETest", 2, List(alu_p1,alu_sha1_p1)), "PE").getModuleInfo(),"PE.xml","PE")
//
//  //chisel3.Driver.execute(args, () => new PE(PEParam(32, "PETest", 1, List(alu_p1)), "PE"))
//}




