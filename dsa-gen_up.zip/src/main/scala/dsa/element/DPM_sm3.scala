package dsa.element

import chisel3._
import chisel3.util._

class DPM_sm3(elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num * 2, UInt(width.W)))
    val cfg = Input(UInt(2.W))
  })
  val DPM_sm3_Ins = Seq.tabulate(PE_num)(i => Module(new sm3_dpm(width, i + 1, PE_num)))

  DPM_sm3_Ins(0).io.cfg := io.cfg(0)
  if(PE_num == 64) {
    DPM_sm3_Ins(0).io.inputs := io.inputs
    DPM_sm3_Ins(0).io.cycle_in := 0.U
  } else {
    when(io.cfg(1) === 1.U) {
      DPM_sm3_Ins(0).io.inputs := io.inputs
      DPM_sm3_Ins(0).io.cycle_in := 0.U
    } .otherwise {
      for (j <- 0 until 16) {
        DPM_sm3_Ins(0).io.inputs(j) := DPM_sm3_Ins(PE_num - 1).io.outputs(j + 2)
        DPM_sm3_Ins(0).io.cycle_in := DPM_sm3_Ins(PE_num - 1).io.cycle_out
      }
    }

  }



  for (i <- 1 until PE_num) {
    for (j <- 0 until 16) {
      DPM_sm3_Ins(i).io.inputs(j) := DPM_sm3_Ins(i - 1).io.outputs(j + 2)
    }
    DPM_sm3_Ins(i).io.cfg := io.cfg(0)
    DPM_sm3_Ins(i).io.cycle_in := DPM_sm3_Ins(i - 1).io.cycle_out
  }

  for (i <- 0 until PE_num) {
    io.outputs(2 * i) := DPM_sm3_Ins(i).io.outputs(0)
    io.outputs(2 * i + 1) := DPM_sm3_Ins(i).io.outputs(1)
  }

}

class sm3_dpm(width: Int, NO_PE: Int, PE_num: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W))) //16位作为数据输入
    val cycle_in = Input(UInt(6.W))
    val outputs = Output(Vec(18, UInt(width.W))) //0->pe,2~16->data,17->cycle
    val cycle_out = Output(UInt(6.W))
    val cfg = Input(UInt(1.W))

  })
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for (i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }
  val cycle_in_Wire = Wire(UInt(6.W))

  io.cycle_out := cycle_in_Wire + 1.U

  if (NO_PE == 1) {
    when(io.cfg === 1.U) {
      cycle_in_Wire := 0.U
    }.otherwise {
      cycle_in_Wire := RegNext(io.cycle_in)
    }
  } else {
    cycle_in_Wire := RegNext(io.cycle_in)
  }


  val tmp0 = Wire(UInt(width.W))
  val tmp0_shift = Wire(UInt(width.W))
  val tmp1 = Wire(UInt(width.W))
  val P1 = Wire(UInt(width.W))
  val tmp2 = Wire(UInt(width.W))
  val tmp2_shift = Wire(UInt(width.W))
  val tmp_data1 = Wire(UInt(width.W))
  val tmp_data2 = Wire(UInt(width.W))

  tmp0 := inputsWire(1)
  tmp0_shift := Cat(tmp0(16, 0), tmp0(31, 17))
  tmp1 := inputsWire(4) ^ inputsWire(11) ^ tmp0_shift
  P1 := tmp1 ^ Cat(tmp1(16, 0), tmp1(31, 17)) ^ Cat(tmp1(8, 0), tmp1(31, 9))
  tmp2 := inputsWire(7)
  tmp2_shift := Cat(tmp2(24, 0), tmp2(31, 25))
  tmp_data1 := P1 ^ tmp2_shift ^ inputsWire(14)


  io.outputs(0) := inputsWire(0)
  io.outputs(1) := tmp_data2
  io.outputs(17) := inputsWire(0)
  if(PE_num == 64) {
    if(NO_PE <= 12) {
      for (i <- 2 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
      tmp_data2 := inputsWire(0) ^ inputsWire(4)
    }

    else {
      io.outputs(5) := tmp_data1
      for(i <- 2 until 5) {
        io.outputs(i) := inputsWire(i - 1)
      }
      for(i <- 6 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
      tmp_data2 := inputsWire(0) ^ tmp_data1
    }
  } else if (PE_num == 32 || PE_num == 16) {
    if(NO_PE <= 12) {
      when(cycle_in_Wire < 12.U) {
        for (i <- 2 until 17) {
          io.outputs(i) := inputsWire(i - 1)
        }
        tmp_data2 := inputsWire(0) ^ inputsWire(4)
      } .otherwise {
        io.outputs(5) := tmp_data1
        for(i <- 2 until 5) {
          io.outputs(i) := inputsWire(i - 1)
        }
        for(i <- 6 until 17) {
          io.outputs(i) := inputsWire(i - 1)
        }
        tmp_data2 := inputsWire(0) ^ tmp_data1
      }
    } else {
      io.outputs(5) := tmp_data1
      for(i <- 2 until 5) {
        io.outputs(i) := inputsWire(i - 1)
      }
      for(i <- 6 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
      tmp_data2 := inputsWire(0) ^ tmp_data1
    }
  } else {
    when(cycle_in_Wire < 12.U) {
      for (i <- 2 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
      tmp_data2 := inputsWire(0) ^ inputsWire(4)
    }.otherwise {
      io.outputs(5) := tmp_data1
      for(i <- 2 until 5) {
        io.outputs(i) := inputsWire(i - 1)
      }
      for(i <- 6 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
      tmp_data2 := inputsWire(0) ^ tmp_data1
    }
  }
}


