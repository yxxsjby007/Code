package dsa.element

import chisel3._
import chisel3.util._
import dsa.element.ALU.alu_Info.md5_penumMap

class DPM_md5_multi(elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num, UInt(width.W)))
    val cfg = Input(UInt(33.W))
  })
  val md5_dpm = Seq.tabulate(PE_num)(i => Module(new DPM_md5_1(32, PE_num, i + 1)))


  when(io.cfg(32) === 1.U) {
    for (j <- 0 until 16) {
      md5_dpm(0).io.inputs(j) := md5_dpm(PE_num - 1).io.outputs(j + 1)
    }
  }.otherwise {
    md5_dpm(0).io.inputs := io.inputs
  }

  md5_dpm(0).io.cfg := io.cfg(1, 0)
  for (i <- 1 until PE_num) {
    for (j <- 0 until 16) {
      md5_dpm(i).io.inputs(j) := md5_dpm(i - 1).io.outputs(j + 1)
      md5_dpm(i).io.cfg := io.cfg(i*2+1, i*2)
    }
  }
  for (i <- 0 until PE_num) {
    io.outputs(i) := md5_dpm(i).io.outputs(0)
  }
}

class DPM_md5_1(width: Int, PE_num: Int, NO_PE: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W))) //最后一位作为计数器，前16位作为数据输入
    val outputs = Output(Vec(17, UInt(width.W)))
    val cfg = Input(UInt(2.W))

  })
  println("NO_PE : " + NO_PE)
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for (i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }
  val oreder_ori = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)

//2025/5/11
  val order_set = VecInit(Seq.fill(md5_penumMap(PE_num)(1))(0.U(4.W)))

  for(i <- 0 until md5_penumMap(PE_num)(1)) {
    if(PE_num > 64) {
      order_set(i) := oreder_ori((NO_PE - 1) % 64).U
    }
    else {
      order_set(i) := oreder_ori((i * PE_num) + NO_PE - 1).U
    }

  }
  val order = Wire(UInt(4.W))

  when(io.cfg(1, 0) === 0.U) {
    order := order_set(0)
  }.elsewhen(io.cfg(1, 0) === 1.U) {
    order := order_set(1)
  }.elsewhen(io.cfg(1, 0) === 2.U) {
    order := order_set(2)
  }.otherwise {
    order := order_set(3)
  }
  if (NO_PE == 1) {
    when(io.cfg(1, 0) === 0.U) {
      io.outputs(0) := Cat(inputsWire(0)(7, 0), inputsWire(0)(15, 8), inputsWire(0)(23, 16), inputsWire(0)(31, 24))
      for (i <- 1 until 15) {
        io.outputs(i) := Cat(inputsWire(i - 1)(7, 0), inputsWire(i - 1)(15, 8), inputsWire(i - 1)(23, 16), inputsWire(i - 1)(31, 24))
      }
      io.outputs(15) := inputsWire(14)
      io.outputs(16) := inputsWire(15)
    }.otherwise {
      io.outputs(0) := inputsWire(order)
      for (i <- 1 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
    }
  } else {
    io.outputs(0) := inputsWire(order)
    for (i <- 1 until 17) {
      io.outputs(i) := inputsWire(i - 1)
    }
  }
}

