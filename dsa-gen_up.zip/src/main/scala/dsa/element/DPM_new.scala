//package dsa.element
//
//import chisel3._
//
//import chisel3.util._
//import dsa.element.ALU.OPC
//import dsa.element.ALU.OpInfo
//class DPM_new (elename: String, op_type: Int, in_num: Int, data_sets: Int, PE_num: Int, width: Int) extends Module{
//  //一个周期输入十六个数据（先不考虑数据扩展）
//  override val desiredName = elename
//  println("DPM :" + op_type)
//  val alu_type = OpInfo.fuget(op_type)
//  println("alu_type : " + alu_type)
//  val max_cycle = alu_type.map(OpInfo.getOperandCycle(_)).max
//  val max_out = alu_type.map(OpInfo.getDPMoutNum(_)).max
//  println("max_out :" + max_out)
//  val out_num = max_out * PE_num
//  //先考虑只有一个输出的情况
//  val io = IO(new Bundle() {
//    //cfg分高低控制为，低两位0~1控制数据输入输出，高几位控制运算类型
//    val cfg = Input(UInt(7.W)) //cfg = 1时开始读入数据，cfg = 2时开始往外输出数据，cfg同时需要确定运算类型，从而确定outbuffers的数据
//    val inputs = Input(Vec(in_num, UInt(width.W)))
//    val outputs = Output(Vec(PE_num, UInt(width.W)))
//  })
//  val data_in_wire = Wire(UInt(log2Ceil(data_sets).W))
//  val data_in_Reg = RegEnable(data_in_wire + 1.U, 0.U, data_in_wire < data_sets.U)
//  data_in_wire := data_in_Reg
//  val inbuffers = RegInit(VecInit(Seq.fill(data_sets)(VecInit(Seq.fill(in_num)(0.U(width.W)))))) // 创建多个输入缓冲区，每个缓冲区存放in_num个数据
//  when(io.cfg(0) === 1.U) {
//    inbuffers(data_in_wire) := io.inputs
//  }
//  //创建一个输出计数寄存器
//  val data_out_wire = Wire(UInt(10.W))
//  val data_out_reg = RegEnable(data_out_wire + 1.U, 0.U, io.cfg(1) === 1.U)
//  data_out_wire := data_out_reg
//
//  //循环选择数据输出的来源
//  val cntwire = Wire(UInt(log2Ceil(PE_num).W))
//  val cntReg = RegEnable(cntwire + 1.U, 0.U, io.cfg(1) === 1.U)
//  cntwire := cntReg
//
//  val oreder = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
//    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
//    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
//    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)
//
////  val DPM1_1 = Module(new DMP1(32, 4, 1))
////  DPM1_1.io.counter := data_out_wire
////  DPM1_1.io.inputs := inbuffers(0)
//
////  for(i <- 0 until 15) {
////    inbuffers(0)(i) := inbuffers(0)(i + 1)
////  }
////  when(data_out_wire > 16.U) {
////    inbuffers(0)(15) := DPM1_1.io.outputs
////  } .otherwise {
////    inbuffers(0)(15) := inbuffers(0)(0)
////  }
//
//  val DPM1_module = Seq.tabulate(PE_num)(i => Module(new DMP1(1,32, PE_num, i + 1, oreder(i % 64))))
//
//  DPM1_module(0).io.inputs := io.inputs
//  DPM1_module(0).io.cfg := io.cfg
//  for(i <- 1 until PE_num) {
//    for(j <- 0 until 16){
//      DPM1_module(i).io.inputs(j) := DPM1_module(i - 1).io.outputs(j + 1)
//    }
//    DPM1_module(i).io.cfg := io.cfg
//  }
//  for(i <- 0 until PE_num) {
//    io.outputs(i) := DPM1_module(i).io.outputs(0)
//  }
//
//
//}
//
//
//class DMP1(op_type: Int, width: Int, PE_num: Int, NO_PE: Int, md5_NO: Int) extends Module {
//  val io = IO(new Bundle() {
//    val inputs = Input(Vec(16, UInt(width.W)))  //最后一位作为计数器，前16位作为数据输入
//    val cfg = Input(UInt(7.W))
//    //val counter = Input(UInt(10.W))
//    val outputs = Output(Vec(17, UInt(width.W)))
//  })
//  val inputsWire = Wire(Vec(16, UInt(width.W)))
//  for(i <- 0 until 16) {
//    inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
//  }
//  val alu_type = OpInfo.fuget(op_type)
//
//
//  when(io.cfg(6,2) === 0.U) {
//    io.outputs(0) := io.inputs(md5_NO)
//    for(i <- 1 until 17) {
//      io.outputs(i) := inputsWire(i - 1)
//    }
//  } .elsewhen(io.cfg(6,2) === 1.U) {
//    val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
//    val tmp_data = Cat(tmp(30, 0), tmp(31))
//    if(NO_PE > 16) {
//      io.outputs(0) := tmp_data
//      io.outputs(16) := tmp_data
//    } else {
//      io.outputs(0) := inputsWire(0)
//      io.outputs(16) := inputsWire(0)
//    }
//    for(i <- 1 until 16) {
//      io.outputs(i) := inputsWire(i)
//    }
//  } .elsewhen(io.cfg(6,2) === 2.U) {
//    val tmp0 = inputsWire(14)
//    val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
//    val tmp1 = inputsWire(1)
//    val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
//    val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)
//    if(NO_PE > 16) {
//      io.outputs(0) := tmp2
//      io.outputs(16) := tmp2
//    } else {
//      io.outputs(0) := inputsWire(0)
//      io.outputs(16) := inputsWire(0)
//    }
//    for(i <- 1 until 16) {
//      io.outputs(i) := inputsWire(i)
//    }
//  } .otherwise {
//    for(i <- 0 until 17) {
//      io.outputs(i) := 0.U
//    }
//  }
//
//
//  //假设有4个PE单元
////  when(io.counter > 16.U) {
////    io.outputs(0) := tmp_data
////  } .otherwise {
////    io.outputs(0) := inputsWire(0)
////  }
////  for(i <- 1 until 17) {
////    io.outputs(i) := inputsWire(i - 1)
////  }
//
//}
//
//object DPM_newMain extends App {
//  val op_type = 1
//  val in_num = 16
//  val data_sets = 1
//  val PE_num = 80
//  val width = 32
//  chisel3.Driver.execute(args, () => new DPM_new("DPM_newTest", op_type, in_num, data_sets, PE_num, width))
//
//}

package dsa.element

import chisel3._

import chisel3.util._
import dsa.element.ALU.OPC
import dsa.element.ALU.OpInfo

class DPM_new (elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num, UInt(width.W)))
  })
  val DPM1_module = Seq.tabulate(PE_num)(i => Module(new DPM_new1(32,  i + 1)))
  DPM1_module(0).io.inputs := io.inputs
  for(i <- 1 until PE_num) {
    for(j <- 0 until 16){
      DPM1_module(i).io.inputs(j) := DPM1_module(i - 1).io.outputs(j + 1)
    }
  }
  for(i <- 0 until PE_num) {
    io.outputs(i) := DPM1_module(i).io.outputs(0)
  }

}

class DPM_new1(width: Int, NO_PE: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W)))  //最后一位作为计数器，前16位作为数据输入
    val outputs = Output(Vec(17, UInt(width.W)))

  })
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for(i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }
  //只有sha1
  val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
  val tmp_data = Cat(tmp(30, 0), tmp(31))
  if(NO_PE > 16) {
    io.outputs(0) := tmp_data
    io.outputs(16) := tmp_data
  } else {
    io.outputs(0) := inputsWire(0)
    io.outputs(16) := inputsWire(0)
  }
  for(i <- 1 until 16) {
    io.outputs(i) := inputsWire(i)
  }


  //只有sha256
//    val tmp0 = inputsWire(14)
//    val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
//    val tmp1 = inputsWire(1)
//    val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
//    val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)
//    if(NO_PE > 16) {
//      io.outputs(0) := tmp2
//      io.outputs(16) := tmp2
//    } else {
//      io.outputs(0) := inputsWire(0)
//      io.outputs(16) := inputsWire(0)
//    }
//    for(i <- 1 until 16) {
//      io.outputs(i) := inputsWire(i)
//    }



  //只有md5
  val oreder = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)
//    io.outputs(0) := io.inputs(oreder((NO_PE-1) % 64))
//    for(i <- 1 until 17) {
//      io.outputs(i) := inputsWire(i - 1)
//    }

  //只有md5
//  if(NO_PE == 1) {
//    io.outputs(0) := Cat(io.inputs(oreder((NO_PE - 1) % 64))(7, 0), io.inputs(oreder((NO_PE - 1) % 64))(15, 8), io.inputs(oreder((NO_PE-1) % 64))(23, 16), io.inputs(oreder((NO_PE-1) % 64))(31, 24))
//    for(i <- 1 until 15) {
//      io.outputs(i) := Cat(inputsWire(i - 1)(7, 0), inputsWire(i - 1)(15, 8), inputsWire(i - 1)(23, 16), inputsWire(i - 1)(31, 24))
//    }
//    io.outputs(15) := inputsWire(14)
//    io.outputs(16) := inputsWire(15)
//  } else {
//    io.outputs(0) := io.inputs(oreder((NO_PE-1) % 64))
//    for(i <- 1 until 17) {
//      io.outputs(i) := inputsWire(i - 1)
//    }
//  }


}