package dsa.element
import chisel3._
import chisel3.util._

class DPM_md5_sha1_sha256 (elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num, UInt(width.W)))
    val cfg = Input(UInt(2.W))
  })


  val DPM2_module = Seq.tabulate(PE_num)(i => Module(new DPM_new2(32,  i + 1)))
  DPM2_module(0).io.inputs := io.inputs
  DPM2_module(0).io.cfg := io.cfg
  for(i <- 1 until PE_num) {
    DPM2_module(i).io.cfg := io.cfg
    for(j <- 0 until 16){
      DPM2_module(i).io.inputs(j) := DPM2_module(i - 1).io.outputs(j + 1)
    }
  }
  for(i <- 0 until PE_num) {
    io.outputs(i) := DPM2_module(i).io.outputs(0)
  }
}



class DPM_new2(width: Int, NO_PE: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W))) //最后一位作为计数器，前16位作为数据输入
    val outputs = Output(Vec(17, UInt(width.W)))
    val cfg = Input(UInt(2.W))

  })
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for (i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }


  //只有sha1
  val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
  val tmp_data = Cat(tmp(30, 0), tmp(31))



  //只有sha256
  val tmp0 = inputsWire(14)
  val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
  val tmp1 = inputsWire(1)
  val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
  val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)



  //只有md5
  val oreder = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)

  //三种算法
  if (NO_PE == 1) {
    when(io.cfg === 1.U) {
      io.outputs(0) := Cat(inputsWire(0)(7, 0), inputsWire(0)(15, 8), inputsWire(0)(23, 16), inputsWire(0)(31, 24))
      for (i <- 1 until 15) {
        io.outputs(i) := Cat(inputsWire(i - 1)(7, 0), inputsWire(i - 1)(15, 8), inputsWire(i - 1)(23, 16), inputsWire(i - 1)(31, 24))
      }
      io.outputs(15) := inputsWire(14)
      io.outputs(16) := inputsWire(15)
    }.otherwise {
      io.outputs(0) := inputsWire(0)
      io.outputs(16) := inputsWire(0)
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  } else if (NO_PE == 65) {
    when(io.cfg === 1.U) {
      io.outputs(0) := Cat(inputsWire(0)(7, 0), inputsWire(0)(15, 8), inputsWire(0)(23, 16), inputsWire(0)(31, 24))
      for (i <- 1 until 15) {
        io.outputs(i) := Cat(inputsWire(i - 1)(7, 0), inputsWire(i - 1)(15, 8), inputsWire(i - 1)(23, 16), inputsWire(i - 1)(31, 24))
      }
      io.outputs(15) := inputsWire(14)
      io.outputs(16) := inputsWire(15)
    } .elsewhen(io.cfg === 3.U) {
      io.outputs(0) := inputsWire(0)
      io.outputs(16) := inputsWire(0)
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    } .otherwise {
      io.outputs(0) := tmp_data
      io.outputs(16) := tmp_data
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  }
  else if (NO_PE > 16) {
    when(io.cfg === 2.U) {
      io.outputs(0) := tmp_data
      io.outputs(16) := tmp_data
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }.elsewhen(io.cfg === 3.U) {
      io.outputs(0) := tmp2
      io.outputs(16) := tmp2
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }.otherwise {
      io.outputs(0) := inputsWire(oreder((NO_PE - 1) % 64))
      for (i <- 1 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
    }
  } else {
    when(io.cfg === 1.U) {
      io.outputs(0) := inputsWire(oreder((NO_PE - 1) % 64))
      for (i <- 1 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
    }.otherwise {
      io.outputs(0) := inputsWire(0)
      io.outputs(16) := inputsWire(0)
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  }


  //md5+sha1
  /*
  if (NO_PE > 16) {
    when(io.cfg === 2.U) {
      io.outputs(0) := tmp_data
      io.outputs(16) := tmp_data
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }.otherwise {
      io.outputs(0) := io.inputs(oreder((NO_PE - 1) % 64))
      for (i <- 1 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
    }
  } else {
    when(io.cfg === 1.U) {
      io.outputs(0) := io.inputs(oreder((NO_PE - 1) % 64))
      for (i <- 1 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
    }.otherwise {
      io.outputs(0) := inputsWire(0)
      io.outputs(16) := inputsWire(0)
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  }
*/





}
