package dsa.element

import chisel3._
import chisel3.util._

class DPM_md5_sha1_sha256_2cycle(elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num * 2, UInt(width.W)))
    val cfg = Input(UInt(2.W))
  })
  val DPM3_module = Seq.tabulate(PE_num)(i => Module(new DPM_new3(32, i + 1)))
  DPM3_module(0).io.inputs := io.inputs
  DPM3_module(0).io.cfg := io.cfg
  for (i <- 1 until PE_num) {
    DPM3_module(i).io.cfg := io.cfg
    for (j <- 0 until 16) {
      DPM3_module(i).io.inputs(j) := DPM3_module(i - 1).io.outputs(j + 2)
    }
  }
  for (i <- 0 until PE_num) {
    io.outputs(i * 2) := DPM3_module(i).io.outputs(0)
    io.outputs(i * 2 + 1) := DPM3_module(i).io.outputs(1)
  }
}


class DPM_new3(width: Int, NO_PE: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W))) //最后一位作为计数器，前16位作为数据输入
    val outputs = Output(Vec(18, UInt(width.W)))
    val cfg = Input(UInt(2.W))

  })
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for (i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }


  //只有sha1
  val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
  val tmp_data = Cat(tmp(30, 0), tmp(31))
  val tmp_1 = inputsWire(14) ^ inputsWire(9) ^ inputsWire(3) ^ inputsWire(1)
  val tmp_data_1 = Cat(tmp_1(30, 0), tmp_1(31))


  //只有sha256
  val tmp0 = inputsWire(14)
  val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
  val tmp1 = inputsWire(1)
  val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
  val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)

  val tmp0_1 = inputsWire(15)
  val SIGMA_MIN1_1 = Cat(tmp0_1(16, 0), tmp0_1(31, 17)) ^ Cat(tmp0_1(18, 0), tmp0_1(31, 19)) ^ Cat(Fill(10, 0.U), tmp0_1(31, 10))
  val tmp1_1 = inputsWire(2)
  val SIGMA_MIN0_1 = Cat(tmp1_1(6, 0), tmp1_1(31, 7)) ^ Cat(tmp1_1(17, 0), tmp1_1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1_1(31, 3))
  val tmp2_1 = SIGMA_MIN1_1 + inputsWire(10) + SIGMA_MIN0_1 + inputsWire(1)


  //只有md5
  val oreder = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)
  //  io.outputs(0) := inputsWire(oreder((NO_PE - 1) % 32))
  //  for (i <- 1 until 17) {
  //    io.outputs(i) := inputsWire(i - 1)
  //  }


  if (NO_PE == 1) {
    when(io.cfg === 1.U) {
      io.outputs(0) := Cat(inputsWire(oreder(((NO_PE - 1) % 32) * 2))(7, 0), inputsWire(oreder(((NO_PE - 1) % 32) * 2))(15, 8), inputsWire(oreder(((NO_PE - 1) % 32) * 2))(23, 16), inputsWire(oreder(((NO_PE - 1) % 32) * 2))(31, 24))
      io.outputs(1) := Cat(inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(7, 0), inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(15, 8), inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(23, 16), inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(31, 24))

      for (i <- 2 until 16) {
        io.outputs(i) := Cat(inputsWire(i - 2)(7, 0), inputsWire(i - 2)(15, 8), inputsWire(i - 2)(23, 16), inputsWire(i - 2)(31, 24))
      }
      io.outputs(16) := inputsWire(14)
      io.outputs(17) := inputsWire(15)
    }.otherwise {
      io.outputs(0) := inputsWire(0)
      io.outputs(1) := inputsWire(1)
      io.outputs(16) := inputsWire(0)
      io.outputs(17) := inputsWire(1)
      for (i <- 2 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  }
  else if(NO_PE == 32) {
    when(io.cfg === 1.U) {
      io.outputs(0) := Cat(inputsWire(oreder(((NO_PE - 1) % 32) * 2))(7, 0), inputsWire(oreder(((NO_PE - 1) % 32) * 2))(15, 8), inputsWire(oreder(((NO_PE - 1) % 32) * 2))(23, 16), inputsWire(oreder(((NO_PE - 1) % 32) * 2))(31, 24))
      io.outputs(1) := Cat(inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(7, 0), inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(15, 8), inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(23, 16), inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))(31, 24))

      for (i <- 2 until 16) {
        io.outputs(i) := Cat(inputsWire(i - 2)(7, 0), inputsWire(i - 2)(15, 8), inputsWire(i - 2)(23, 16), inputsWire(i - 2)(31, 24))
      }
      io.outputs(16) := inputsWire(14)
      io.outputs(17) := inputsWire(15)
    }.elsewhen(io.cfg === 3.U) {
      io.outputs(0) := inputsWire(0)
      io.outputs(1) := inputsWire(1)
      io.outputs(16) := inputsWire(0)
      io.outputs(17) := inputsWire(1)
      for (i <- 2 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    } .otherwise{
      io.outputs(0) := tmp_data
      io.outputs(1) := tmp_data_1
      io.outputs(16) := tmp_data
      io.outputs(17) := tmp_data_1
      for (i <- 2 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  }

  else if (NO_PE > 8) {
    when(io.cfg === 2.U) {
      io.outputs(0) := tmp_data
      io.outputs(1) := tmp_data_1
      io.outputs(16) := tmp_data
      io.outputs(17) := tmp_data_1
      for (i <- 2 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }.elsewhen(io.cfg === 3.U) {
      io.outputs(0) := tmp2
      io.outputs(1) := tmp2_1
      io.outputs(16) := tmp2
      io.outputs(17) := tmp2_1
      for (i <- 2 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }.otherwise {
      io.outputs(0) := inputsWire(oreder(((NO_PE - 1) % 32) * 2))
      io.outputs(1) := inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))
      for (i <- 2 until 18) {
        io.outputs(i) := inputsWire(i - 2)
      }
    }
  } else {
    when(io.cfg === 1.U) {
      io.outputs(0) := inputsWire(oreder(((NO_PE - 1) % 32) * 2))
      io.outputs(1) := inputsWire(oreder(((NO_PE - 1) % 32) * 2 + 1))
      for (i <- 2 until 18) {
        io.outputs(i) := inputsWire(i - 2)
      }
    }.otherwise {
      io.outputs(0) := inputsWire(0)
      io.outputs(1) := inputsWire(1)
      io.outputs(16) := inputsWire(0)
      io.outputs(17) := inputsWire(1)
      for (i <- 2 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  }
}
