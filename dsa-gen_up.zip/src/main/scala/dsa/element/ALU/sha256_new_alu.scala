package dsa.element.ALU
import chisel3._
import chisel3.util._
class sha256_new_alu(elename: String, width: Int, pe_num: Int, NO_PE: Int) extends  Module{
  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(9, UInt(width.W))) //a,b,c,d,e,w
    val outputs = Output(Vec(8, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(9, UInt(width.W)))

  if((NO_PE % 64) == 1) {
    inputsWire(0) := "h6A09E667".U
    inputsWire(1) := "hBB67AE85".U
    inputsWire(2) := "h3C6EF372".U
    inputsWire(3) := "hA54FF53A".U
    inputsWire(4) := "h510E527F".U
    inputsWire(5) := "h9B05688C".U
    inputsWire(6) := "h1F83D9AB".U
    inputsWire(7) := "h5BE0CD19".U
    inputsWire(8) := RegNext(io.inputs(8))
  }
  else{
    for(i <- 0 until 9) {
      inputsWire(i) := RegNext(io.inputs(i))
    }
  }

  val kt_ori = Seq(
    "h428A2F98".U, "h71374491".U, "hB5C0FBCF".U, "hE9B5DBA5".U, "h3956C25B".U, "h59F111F1".U, "h923F82A4".U, "hAB1C5ED5".U,
    "hD807AA98".U, "h12835B01".U, "h243185BE".U, "h550C7DC3".U, "h72BE5D74".U, "h80DEB1FE".U, "h9BDC06A7".U, "hC19BF174".U,
    "hE49B69C1".U, "hEFBE4786".U, "h0FC19DC6".U, "h240CA1CC".U, "h2DE92C6F".U, "h4A7484AA".U, "h5CB0A9DC".U, "h76F988DA".U,
    "h983E5152".U, "hA831C66D".U, "hB00327C8".U, "hBF597FC7".U, "hC6E00BF3".U, "hD5A79147".U, "h06CA6351".U, "h14292967".U,
    "h27B70A85".U, "h2E1B2138".U, "h4D2C6DFC".U, "h53380D13".U, "h650A7354".U, "h766A0ABB".U, "h81C2C92E".U, "h92722C85".U,
    "hA2BFE8A1".U, "hA81A664B".U, "hC24B8B70".U, "hC76C51A3".U, "hD192E819".U, "hD6990624".U, "hF40E3585".U, "h106AA070".U,
    "h19A4C116".U, "h1E376C08".U, "h2748774C".U, "h34B0BCB5".U, "h391C0CB3".U, "h4ED8AA4A".U, "h5B9CCA4F".U, "h682E6FF3".U,
    "h748F82EE".U, "h78A5636F".U, "h84C87814".U, "h8CC70208".U, "h90BEFFFA".U, "hA4506CEB".U, "hBEF9A3F7".U, "hC67178F2".U)
  val k = Wire(UInt(32.W))
  k := kt_ori((NO_PE - 1) % 64)

  val SIGMA0 = Wire(UInt(width.W))
  val SIGMA1 = Wire(UInt(width.W))
  val ROTR2 = Wire(UInt(width.W))
  val ROTR13 = Wire(UInt(width.W))
  val ROTR22 = Wire(UInt(width.W))
  val ROTR6 = Wire(UInt(width.W))
  val ROTR11 = Wire(UInt(width.W))
  val ROTR25 = Wire(UInt(width.W))
  val Ch = Wire(UInt(width.W))
  val Maj = Wire(UInt(width.W))
  val T1 = Wire(UInt(width.W))
  val T2 = Wire(UInt(width.W))
  ROTR6 := Cat(inputsWire(4)(5,0), inputsWire(4)(31,6))
  ROTR11 := Cat(inputsWire(4)(10,0), inputsWire(4)(31,11))
  ROTR25 := Cat(inputsWire(4)(24,0), inputsWire(4)(31,25))
  ROTR2 := Cat(inputsWire(0)(1,0), inputsWire(0)(31,2))
  ROTR13 := Cat(inputsWire(0)(12,0), inputsWire(0)(31,13))
  ROTR22 := Cat(inputsWire(0)(21,0), inputsWire(0)(31,22))
  //(e&f) ^ (~e&g)
  Ch := (inputsWire(4) & inputsWire(5)) ^ (~inputsWire(4) & inputsWire(6))
  //(a&b) | (a&c) | (b&c)
  Maj := (inputsWire(0) & inputsWire(1)) ^ (inputsWire(0) & inputsWire(2)) ^ (inputsWire(1) & inputsWire(2))
  SIGMA0 := ROTR2 ^ ROTR13 ^ ROTR22
  SIGMA1 := ROTR6 ^ ROTR11 ^ ROTR25
  T1 := inputsWire(7) + SIGMA1 + Ch + k + inputsWire(8)
  T2 := SIGMA0 + Maj



  if((NO_PE % 64) == 0) {
    io.outputs(0) := T1 + T2 + "h6A09E667".U
    io.outputs(1) := inputsWire(0) + "hBB67AE85".U
    io.outputs(2) := inputsWire(1) + "h3C6EF372".U
    io.outputs(3) := inputsWire(2) + "hA54FF53A".U
    io.outputs(4) := T1 + inputsWire(3) + "h510E527F".U
    io.outputs(5) := inputsWire(4) + "h9B05688C".U
    io.outputs(6) := inputsWire(5) + "h1F83D9AB".U
    io.outputs(7) := inputsWire(6) + "h5BE0CD19".U
  } else {
    io.outputs(0) := T1 + T2
    io.outputs(1) := inputsWire(0)
    io.outputs(2) := inputsWire(1)
    io.outputs(3) := inputsWire(2)
    io.outputs(4) := T1 + inputsWire(3)
    io.outputs(5) := inputsWire(4)
    io.outputs(6) := inputsWire(5)
    io.outputs(7) := inputsWire(6)
  }

}
