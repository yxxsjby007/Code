package dsa.element.ALU
import chisel3._
import chisel3.util._
import scala.Array
import scala.collection.mutable.ListBuffer
import dsa.element.ALU.alu_Info.sha1_penumMap
class sha1_2cycle_alu (elename: String, width: Int, pe_num: Int, NO_PE: Int) extends Module{

  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(8, UInt(width.W))) //a,b,c,d,e,cycle,w
    val outputs = Output(Vec(5, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(8, UInt(width.W)))
  if(NO_PE.U == 1) {
    inputsWire(0) := "h67452301".U
    inputsWire(1) := "hEFCDAB89".U
    inputsWire(2) := "h98badcfe".U
    inputsWire(3) := "h10325476".U
    inputsWire(4) := "hC3D2E1F0".U
    inputsWire(5) := 0.U
    inputsWire(6) := RegEnable(io.inputs(6), 0.U, true.asBool())
    inputsWire(7) := RegEnable(io.inputs(7), 0.U, true.asBool())
  } else {
    for (i <- 0 until 8) {
      inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
    }
  }

  val kt = Wire(UInt(32.W))
  val k_ori = Seq("h5A827999".U, "h6ED9EBA1".U, "h8F1BBCDC".U, "hCA62C1D6".U)
  if(NO_PE < 11) {
    kt := k_ori(0)
  } else if(11 <= NO_PE  && NO_PE < 21) {
    kt := k_ori(1)
  } else if(21 <= NO_PE  && NO_PE < 31) {
    kt := k_ori(2)
  } else {
    kt := k_ori(3)
  }

  val sha1func_res = Wire(UInt(width.W))
  val sha1func_res0 = Wire(UInt(width.W))
  val sha1func_res1 = Wire(UInt(width.W))
  val sha1func_res2 = Wire(UInt(width.W))


  if (NO_PE <= 10) {
    kt := k_ori(0)
    sha1func_res := sha1func_res0
    sha1func_res_1 := sha1func_res0_1
  } else if (10 < NO_PE && NO_PE <= 20) {
    kt := k_ori(1)
    sha1func_res := sha1func_res1
    sha1func_res_1 := sha1func_res1_1
  } else if (20 < NO_PE && NO_PE <= 30) {
    kt := k_ori(2)
    sha1func_res := sha1func_res2
    sha1func_res_1 := sha1func_res2_1
  } else {
    kt := k_ori(3)
    sha1func_res := sha1func_res1
    sha1func_res_1 := sha1func_res1_1
  }


  //(b&c) | (~b&d)
  sha1func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
  //b^c^d
  sha1func_res1 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
  //(b&c) | (b&d) | (c&d)
  sha1func_res2 := (inputsWire(1) & inputsWire(2)) | (inputsWire(1) & inputsWire(3)) | (inputsWire(2) & inputsWire(3))

  val shift_a = Wire(UInt(width.W))
  val shift_b = Wire(UInt(width.W))
  val tmp_A = Wire(UInt(width.W))
  shift_a := Cat(inputsWire(0)(26, 0), inputsWire(0)(31, 27))
  shift_b := Cat(inputsWire(1)(1, 0), inputsWire(1)(31, 2))
  tmp_A := shift_a + sha1func_res + inputsWire(4) + kt + inputsWire(6)

  val iooutputs0 = tmp_A
  val iooutputs1 = inputsWire(0)
  val iooutputs2 = shift_b
  val iooutputs3 = inputsWire(2)
  val iooutputs4 = inputsWire(3)
  val iooutputs5 = inputsWire(5) + 1.U

  val sha1func_res_1 = Wire(UInt(width.W))
  val sha1func_res0_1 = Wire(UInt(width.W))
  val sha1func_res1_1 = Wire(UInt(width.W))
  val sha1func_res2_1 = Wire(UInt(width.W))

  //(b&c) | (~b&d)
  sha1func_res0_1 := (iooutputs1 & iooutputs2) | ((~iooutputs1) & iooutputs3)
  //b^c^d
  sha1func_res1_1 := iooutputs1 ^ iooutputs2 ^ iooutputs3
  //(b&c) | (b&d) | (c&d)
  sha1func_res2_1 := (iooutputs1 & iooutputs2) | (iooutputs1 & iooutputs3) | (iooutputs2 & iooutputs3)

  val shift_a_1 = Wire(UInt(width.W))
  val shift_b_1 = Wire(UInt(width.W))
  val tmp_A_1 = Wire(UInt(width.W))
  shift_a_1 := Cat(iooutputs0(26, 0), iooutputs0(31, 27))
  shift_b_1 := Cat(iooutputs1(1, 0), iooutputs1(31, 2))
  tmp_A_1 := shift_a_1 + sha1func_res_1 + iooutputs4 + kt + inputsWire(7)


  if(NO_PE == 80) {

      io.outputs(0) := tmp_A_1 + "h67452301".U
      io.outputs(1) := iooutputs0 + "hEFCDAB89".U
      io.outputs(2) := shift_b_1 + "h98badcfe".U
      io.outputs(3) := iooutputs2 + "h10325476".U
      io.outputs(4) := iooutputs3 + "hC3D2E1F0".U



  } else {
    io.outputs(0) := tmp_A_1
    io.outputs(1) := iooutputs0
    io.outputs(2) := shift_b_1
    io.outputs(3) := iooutputs2
    io.outputs(4) := iooutputs3

  }

}

//object sha1_2_cycle extends App {
//  chisel3.Driver.execute(args, () => new sha1_alu("alu_sha1", 32, 80, 1))
//}
