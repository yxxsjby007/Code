package dsa.element.ALU
import chisel3._
import chisel3.util._

class sm3_alu(elename: String,  width: Int, pe_num: Int, NO_PE: Int) extends Module{
  override val desiredName = elename

  val io = IO(new Bundle {
    val cfg = Input(UInt(1.W)) //通过cfg判断为循环的起始位置
    val inputs = Input(Vec(11, UInt(width.W))) //a,b,c,d,e,f,g,h,cycle,w,w'
    val outputs = Output(Vec(9, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(10, UInt(width.W)))
  val cycle = Wire(UInt(6.W))
  if(pe_num == 64) {
    if(NO_PE == 1){
      inputsWire(0) := "h7380166F".U
      inputsWire(1) := "h4914B2B9".U
      inputsWire(2) := "h172442D7".U
      inputsWire(3) := "hDA8A0600".U
      inputsWire(4) := "hA96F30BC".U
      inputsWire(5) := "h163138AA".U
      inputsWire(6) := "hE38DEE4D".U
      inputsWire(7) := "hB0FB0E4E".U
      cycle := 0.U
      inputsWire(8) := RegNext(io.inputs(9))
      inputsWire(9) := RegNext(io.inputs(10))
    } else {
      for (i <- 0 until 8) {
        inputsWire(i) := RegNext(io.inputs(i))
      }
      cycle := RegNext(io.inputs(8)(5, 0))
      inputsWire(8) := RegNext(io.inputs(9))
      inputsWire(9) := RegNext(io.inputs(10))
    }
  }
  else if(NO_PE == 1) {
    when(io.cfg === 1.U) {
      inputsWire(0) := "h7380166F".U
      inputsWire(1) := "h4914B2B9".U
      inputsWire(2) := "h172442D7".U
      inputsWire(3) := "hDA8A0600".U
      inputsWire(4) := "hA96F30BC".U
      inputsWire(5) := "h163138AA".U
      inputsWire(6) := "hE38DEE4D".U
      inputsWire(7) := "hB0FB0E4E".U
      cycle := 0.U
      inputsWire(8) := RegNext(io.inputs(9))
      inputsWire(9) := RegNext(io.inputs(10))
    }.otherwise {
      for (i <- 0 until 8) {
        inputsWire(i) := RegNext(io.inputs(i))
      }
      cycle := RegNext(io.inputs(8)(5, 0))
      inputsWire(8) := RegNext(io.inputs(9))
      inputsWire(9) := RegNext(io.inputs(10))
    }
  } else {
    for (i <- 0 until 8) {
      inputsWire(i) := RegNext(io.inputs(i))
    }
    cycle := RegNext(io.inputs(8)(5, 0))
    inputsWire(8) := RegNext(io.inputs(9))
    inputsWire(9) := RegNext(io.inputs(10))
  }


  val A_shift = Wire(UInt(width.W))
  val T_shift = Wire(UInt(width.W))
  val tmp_shift = Wire(UInt(width.W))
  val SS1 = Wire(UInt(width.W))
  val SS2 = Wire(UInt(width.W))
  val TT1 = Wire(UInt(width.W))
  val TT2 = Wire(UInt(width.W))
  val j = Wire(UInt(5.W))

  val ff1 = Wire(UInt(width.W))
  val ff2 = Wire(UInt(width.W))
  val ff_res = Wire(UInt(width.W))
  val gg1 = Wire(UInt(width.W))
  val gg2 = Wire(UInt(width.W))
  val gg_res = Wire(UInt(width.W))
  val B_shift = Wire(UInt(width.W))
  val F_shift = Wire(UInt(width.W))
  val P = Wire(UInt(width.W))
  val Tj = Wire(UInt(width.W))



  A_shift := Cat(inputsWire(0)(19, 0), inputsWire(0)(31, 20))
  j := cycle(4,0)
  T_shift := (Tj << j) | (Tj  >> (32.U - j))
  tmp_shift := A_shift + inputsWire(4) + T_shift
  SS1 := Cat(tmp_shift(24, 0), tmp_shift(31, 25))
  SS2 := SS1 ^ A_shift

  if(pe_num == 64) {
    if(NO_PE <= 16) {
      ff_res := ff1
      gg_res := gg1
      Tj := "h79cc4519".U
    } else {
      ff_res := ff2
      gg_res := gg2
      Tj := "h7a879d8a".U
    }
  } else {
    Tj := Mux(cycle < 16.U,  "h79cc4519".U,  "h7a879d8a".U)
    ff_res := Mux(cycle < 16.U,  ff1, ff2)
    gg_res := Mux(cycle < 16.U,  gg1,  gg2)
  }

  //a^b^c
  ff1 := inputsWire(0) ^ inputsWire(1) ^ inputsWire(2)
  //(a&b) | (a&c) | (b&v)
  ff2 := (inputsWire(0) & inputsWire(1)) | (inputsWire(0) & inputsWire(2)) | (inputsWire(1) & inputsWire(2))


  //e^f^g
  gg1 := inputsWire(4) ^ inputsWire(5) ^ inputsWire(6)
  //(e&f) | (~e&g)
  gg2 := (inputsWire(4) & inputsWire(5)) | ((~inputsWire(4)) & inputsWire(6))


  TT1 := ff_res + inputsWire(3) + SS2 + inputsWire(9)
  TT2 := gg_res + inputsWire(7) + SS1 + inputsWire(8)

  B_shift := Cat(inputsWire(1)(22, 0), inputsWire(1)(31, 23))
  F_shift := Cat(inputsWire(5)(12, 0), inputsWire(5)(31, 13))

  P := TT2 ^ Cat(TT2(22, 0), TT2(31, 23)) ^ Cat(TT2(14, 0), TT2(31, 15))

  if(NO_PE == 64) {
    io.outputs(0) := TT1 ^ "h7380166F".U
    io.outputs(1) := inputsWire(0) ^ "h4914B2B9".U
    io.outputs(2) := B_shift ^ "h172442D7".U
    io.outputs(3) := inputsWire(2) ^ "hDA8A0600".U
    io.outputs(4) := P ^ "hA96F30BC".U
    io.outputs(5) := inputsWire(4) ^ "h163138AA".U
    io.outputs(6) := F_shift ^ "hE38DEE4D".U
    io.outputs(7) := inputsWire(6) ^ "hB0FB0E4E".U
    io.outputs(8) := 0.U
  }
  else if(NO_PE == pe_num) {
    when(cycle === 63.U) {
      io.outputs(0) := TT1 ^ "h7380166F".U
      io.outputs(1) := inputsWire(0) ^ "h4914B2B9".U
      io.outputs(2) := B_shift ^ "h172442D7".U
      io.outputs(3) := inputsWire(2) ^ "hDA8A0600".U
      io.outputs(4) := P ^ "hA96F30BC".U
      io.outputs(5) := inputsWire(4) ^ "h163138AA".U
      io.outputs(6) := F_shift ^ "hE38DEE4D".U
      io.outputs(7) := inputsWire(6) ^ "hB0FB0E4E".U
      io.outputs(8) := 0.U
    }.otherwise {
      io.outputs(0) := TT1
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := B_shift
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := P
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := F_shift
      io.outputs(7) := inputsWire(6)
      io.outputs(8) := cycle + 1.U
    }
  } else {
    io.outputs(0) := TT1
    io.outputs(1) := inputsWire(0)
    io.outputs(2) := B_shift
    io.outputs(3) := inputsWire(2)
    io.outputs(4) := P
    io.outputs(5) := inputsWire(4)
    io.outputs(6) := F_shift
    io.outputs(7) := inputsWire(6)
    io.outputs(8) := cycle + 1.U
  }
}

//object sm3Gen extends App {
//  chisel3.Driver.execute(args, () => new md5_alu("sm3",32, 16, 1))
//}