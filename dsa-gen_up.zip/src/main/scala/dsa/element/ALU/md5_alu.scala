package dsa.element.ALU

import chisel3._
import chisel3.util._
import scala.Array
import scala.collection.mutable.ListBuffer
import dsa.element.ALU.alu_Info.md5_penumMap

class md5_alu(elename: String, width: Int, pe_num: Int, NO_PE: Int) extends  Module{
  println("NO_PE : " + NO_PE)
  //参数：名称, pe_num: PE数, NO_PE: 第几个PE
  override val desiredName = elename
  val io = IO(new Bundle {
    val cfg = Input(UInt(1.W)) //LM: 单种算法只需要判断开始
    val inputs = Input(Vec(6, UInt(width.W)))     //a,b,c,d,cycle,text
    val outputs = Output(Vec(5, UInt(width.W))) //LM: 输出端口应该改成Vec(输出数，)
  })
  val inputsWire = Wire(Vec(5, UInt(width.W)))
  val cycle = Wire(UInt(6.W))
  if(pe_num == 64) {
    if(NO_PE == 1) {
        inputsWire(0) := "h67452301".U
        inputsWire(1) := "hefcdab89".U
        inputsWire(2) := "h98badcfe".U
        inputsWire(3) := "h10325476".U
        cycle := 0.U
        inputsWire(4) := RegNext(io.inputs(5))
      } else {
        for (i <- 0 until 4) {
          inputsWire(i) := RegNext(io.inputs(i))
        }
    cycle := RegNext(io.inputs(4)(5, 0))
        inputsWire(4) := RegNext(io.inputs(5))
      }
  }
  else if(NO_PE == 1) {
    when(io.cfg === 1.U) { //只有在起始的PE中添加这个判断
      inputsWire(0) := "h67452301".U
      inputsWire(1) := "hefcdab89".U
      inputsWire(2) := "h98badcfe".U
      inputsWire(3) := "h10325476".U
      cycle := 0.U
      inputsWire(4) := RegNext(io.inputs(5))
    }.otherwise {
      for (i <- 0 until 4) {
        inputsWire(i) := RegNext(io.inputs(i))
      }
      cycle := RegNext(io.inputs(4)(5, 0))
      inputsWire(4) := RegNext(io.inputs(5))
    }
  } else{
    for (i <- 0 until 4) {
      inputsWire(i) := RegNext(io.inputs(i))
    }
    cycle := RegNext(io.inputs(4)(5, 0))
    inputsWire(4) := RegNext(io.inputs(5))
  }


  val si_ori = Seq(7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U,
                   5.U,  9.U, 14.U, 20.U, 5.U,  9.U, 14.U, 20.U, 5.U,  9.U, 14.U, 20.U, 5.U,  9.U, 14.U, 20.U,
                   4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U,
                   6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U)
  //构建si的选择序列
  val si = VecInit(Seq.fill(md5_penumMap(pe_num)(0))(0.U(5.W)))
  //如果是64个pe，直接
  if(pe_num == 64) {
    for(i <- 0 until md5_penumMap(pe_num)(0)) {
      si(i) := si_ori(NO_PE - 1)
    }
  } else if(pe_num == 32) {
    for(i <- 0 until md5_penumMap(pe_num)(0)) {
      si(i) := si_ori((i * pe_num) + NO_PE - 1)
    }
  } else if(pe_num == 16) {
    for(i <- 0 until md5_penumMap(pe_num)(0)) {
      si(i) := si_ori((i * 16) + NO_PE - 1)
    }
  } else if(pe_num == 8) {
    for(i <- 0 until md5_penumMap(pe_num)(0)) {
      si(i) := si_ori((i * 16) + NO_PE - 1)
    }
  } else if(pe_num == 4) {
    for(i <- 0 until md5_penumMap(pe_num)(0)) {
      si(i) := si_ori((i * 16) + NO_PE - 1)
    }
  } else if(pe_num == 2) {
    if(NO_PE == 1) {
      si := Seq(7.U, 17.U, 5.U, 14.U, 4.U, 16.U, 6.U, 15.U)
    }
    else {
      si := Seq(12.U, 22.U, 9.U, 20.U, 11.U, 23.U, 10.U, 21.U)
    }
  }
  else if  (pe_num == 1) {
    si := Seq(7.U, 12.U, 17.U, 22.U, 5.U, 9.U, 14.U, 20.U, 4.U, 11.U, 16.U, 23.U, 6.U, 10.U, 15.U, 21.U)
  } else {
    for(i <- 0 until md5_penumMap(pe_num)(0)) {
      si(i) := si_ori(NO_PE - 1)
    }
  }

  val Ti_ori = Seq(
    "hd76aa478".U, "he8c7b756".U, "h242070db".U, "hc1bdceee".U, "hf57c0faf".U, "h4787c62a".U, "ha8304613".U, "hfd469501".U,
    "h698098d8".U,"h8b44f7af".U, "hffff5bb1".U, "h895cd7be".U, "h6b901122".U, "hfd987193".U, "ha679438e".U, "h49b40821".U,
    "hf61e2562".U, "hc040b340".U, "h265e5a51".U, "he9b6c7aa".U, "hd62f105d".U, "h02441453".U, "hd8a1e681".U, "he7d3fbc8".U,
    "h21e1cde6".U, "hc33707d6".U, "hf4d50d87".U, "h455a14ed".U, "ha9e3e905".U, "hfcefa3f8".U, "h676f02d9".U, "h8d2a4c8a".U,
    "hfffa3942".U, "h8771f681".U, "h6d9d6122".U, "hfde5380c".U, "ha4beea44".U, "h4bdecfa9".U, "hf6bb4b60".U, "hbebfbc70".U,
    "h289b7ec6".U, "heaa127fa".U, "hd4ef3085".U, "h04881d05".U, "hd9d4d039".U, "he6db99e5".U, "h1fa27cf8".U, "hc4ac5665".U,
    "hf4292244".U, "h432aff97".U, "hab9423a7".U, "hfc93a039".U, "h655b59c3".U, "h8f0ccc92".U, "hffeff47d".U, "h85845dd1".U,
    "h6fa87e4f".U, "hfe2ce6e0".U, "ha3014314".U, "h4e0811a1".U, "hf7537e82".U, "hbd3af235".U, "h2ad7d2bb".U, "heb86d391".U)

  //构建Ti的选择序列
  val Ti = VecInit(Seq.fill(md5_penumMap(pe_num)(1))(0.U(32.W)))
  for(i <- 0 until md5_penumMap(pe_num)(1)) {
    if(pe_num > 64) {
      Ti(i) := Ti_ori((NO_PE - 1) % 64)
    }
    else {
      Ti(i) := Ti_ori((i * pe_num) + NO_PE - 1)
    }
  }
  val T = Wire(UInt(32.W))

  //根据pe和cycle的数选择Ti
  if(pe_num > 64) {
    T := Ti(0)
  }
  else if(pe_num == 64) { //一选一
    T := Ti(0)
  } else if(pe_num == 32) {    //二选一
    T := Mux(cycle(5), Ti(1), Ti(0))
  } else if(pe_num == 16) { //四选一
    T := MuxCase(0.U, Array(
      (cycle(5,4) === 0.U) -> Ti(0),
      (cycle(5,4) === 1.U) -> Ti(1),
      (cycle(5,4) === 2.U) -> Ti(2),
      (cycle(5,4) === 3.U) -> Ti(3)
    ))
  } else if(pe_num == 8.U) {     //八选一
    T := MuxCase(0.U, Array(
      (cycle(5,3) === 0.U) -> Ti(0),
      (cycle(5,3) === 1.U) -> Ti(1),
      (cycle(5,3) === 2.U) -> Ti(2),
      (cycle(5,3) === 3.U) -> Ti(3),
      (cycle(5,3) === 4.U) -> Ti(4),
      (cycle(5,3) === 5.U) -> Ti(5),
      (cycle(5,3) === 6.U) -> Ti(6),
      (cycle(5,3) === 7.U) -> Ti(7)
    ))
  } else if(pe_num == 4) {     //十六选一
    T := MuxCase(0.U, Array(
      (cycle(5,2) === 0.U) -> Ti(0),
      (cycle(5,2) === 1.U) -> Ti(1),
      (cycle(5,2) === 2.U) -> Ti(2),
      (cycle(5,2) === 3.U) -> Ti(3),
      (cycle(5,2) === 4.U) -> Ti(4),
      (cycle(5,2) === 5.U) -> Ti(5),
      (cycle(5,2) === 6.U) -> Ti(6),
      (cycle(5,2) === 7.U) -> Ti(7),
      (cycle(5,2) === 8.U) -> Ti(8),
      (cycle(5,2) === 9.U) -> Ti(9),
      (cycle(5,2) === 10.U) -> Ti(10),
      (cycle(5,2) === 11.U) -> Ti(11),
      (cycle(5,2) === 12.U) -> Ti(12),
      (cycle(5,2) === 13.U) -> Ti(13),
      (cycle(5,2) === 14.U) -> Ti(14),
      (cycle(5,2) === 15.U) -> Ti(15)
    ))
  } else if(pe_num == 2) {    //三十二选一
    T := MuxCase(0.U, Array(
      (cycle(5, 1) === 0.U) -> Ti(0),
      (cycle(5, 1) === 1.U) -> Ti(1),
      (cycle(5, 1) === 2.U) -> Ti(2),
      (cycle(5, 1) === 3.U) -> Ti(3),
      (cycle(5, 1) === 4.U) -> Ti(4),
      (cycle(5, 1) === 5.U) -> Ti(5),
      (cycle(5, 1) === 6.U) -> Ti(6),
      (cycle(5, 1) === 7.U) -> Ti(7),
      (cycle(5, 1) === 8.U) -> Ti(8),
      (cycle(5, 1) === 9.U) -> Ti(9),
      (cycle(5, 1) === 10.U) -> Ti(10),
      (cycle(5, 1) === 11.U) -> Ti(11),
      (cycle(5, 1) === 12.U) -> Ti(12),
      (cycle(5, 1) === 13.U) -> Ti(13),
      (cycle(5, 1) === 14.U) -> Ti(14),
      (cycle(5, 1) === 15.U) -> Ti(15),
      (cycle(5, 1) === 16.U) -> Ti(16),
      (cycle(5, 1) === 17.U) -> Ti(17),
      (cycle(5, 1) === 18.U) -> Ti(18),
      (cycle(5, 1) === 19.U) -> Ti(19),
      (cycle(5, 1) === 20.U) -> Ti(20),
      (cycle(5, 1) === 21.U) -> Ti(21),
      (cycle(5, 1) === 22.U) -> Ti(22),
      (cycle(5, 1) === 23.U) -> Ti(23),
      (cycle(5, 1) === 24.U) -> Ti(24),
      (cycle(5, 1) === 25.U) -> Ti(25),
      (cycle(5, 1) === 26.U) -> Ti(26),
      (cycle(5, 1) === 27.U) -> Ti(27),
      (cycle(5, 1) === 28.U) -> Ti(28),
      (cycle(5, 1) === 29.U) -> Ti(29),
      (cycle(5, 1) === 30.U) -> Ti(30),
      (cycle(5, 1) === 31.U) -> Ti(31)
    ))
  } else if(pe_num == 1) { //六十四选一
    T := MuxCase(0.U, Array(
      (cycle(5, 0) === 0.U) -> Ti(0),
      (cycle(5, 0) === 1.U) -> Ti(1),
      (cycle(5, 0) === 2.U) -> Ti(2),
      (cycle(5, 0) === 3.U) -> Ti(3),
      (cycle(5, 0) === 4.U) -> Ti(4),
      (cycle(5, 0) === 5.U) -> Ti(5),
      (cycle(5, 0) === 6.U) -> Ti(6),
      (cycle(5, 0) === 7.U) -> Ti(7),
      (cycle(5, 0) === 8.U) -> Ti(8),
      (cycle(5, 0) === 9.U) -> Ti(9),
      (cycle(5, 0) === 10.U) -> Ti(10),
      (cycle(5, 0) === 11.U) -> Ti(11),
      (cycle(5, 0) === 12.U) -> Ti(12),
      (cycle(5, 0) === 13.U) -> Ti(13),
      (cycle(5, 0) === 14.U) -> Ti(14),
      (cycle(5, 0) === 15.U) -> Ti(15),
      (cycle(5, 0) === 16.U) -> Ti(16),
      (cycle(5, 0) === 17.U) -> Ti(17),
      (cycle(5, 0) === 18.U) -> Ti(18),
      (cycle(5, 0) === 19.U) -> Ti(19),
      (cycle(5, 0) === 20.U) -> Ti(20),
      (cycle(5, 0) === 21.U) -> Ti(21),
      (cycle(5, 0) === 22.U) -> Ti(22),
      (cycle(5, 0) === 23.U) -> Ti(23),
      (cycle(5, 0) === 24.U) -> Ti(24),
      (cycle(5, 0) === 25.U) -> Ti(25),
      (cycle(5, 0) === 26.U) -> Ti(26),
      (cycle(5, 0) === 27.U) -> Ti(27),
      (cycle(5, 0) === 28.U) -> Ti(28),
      (cycle(5, 0) === 29.U) -> Ti(29),
      (cycle(5, 0) === 30.U) -> Ti(30),
      (cycle(5, 0) === 31.U) -> Ti(31),
      (cycle(5, 0) === 32.U) -> Ti(32),
      (cycle(5, 0) === 33.U) -> Ti(33),
      (cycle(5, 0) === 34.U) -> Ti(34),
      (cycle(5, 0) === 35.U) -> Ti(35),
      (cycle(5, 0) === 36.U) -> Ti(36),
      (cycle(5, 0) === 37.U) -> Ti(37),
      (cycle(5, 0) === 38.U) -> Ti(38),
      (cycle(5, 0) === 39.U) -> Ti(39),
      (cycle(5, 0) === 40.U) -> Ti(40),
      (cycle(5, 0) === 41.U) -> Ti(41),
      (cycle(5, 0) === 42.U) -> Ti(42),
      (cycle(5, 0) === 43.U) -> Ti(43),
      (cycle(5, 0) === 44.U) -> Ti(44),
      (cycle(5, 0) === 45.U) -> Ti(45),
      (cycle(5, 0) === 46.U) -> Ti(46),
      (cycle(5, 0) === 47.U) -> Ti(47),
      (cycle(5, 0) === 48.U) -> Ti(48),
      (cycle(5, 0) === 49.U) -> Ti(49),
      (cycle(5, 0) === 50.U) -> Ti(50),
      (cycle(5, 0) === 51.U) -> Ti(51),
      (cycle(5, 0) === 52.U) -> Ti(52),
      (cycle(5, 0) === 53.U) -> Ti(53),
      (cycle(5, 0) === 54.U) -> Ti(54),
      (cycle(5, 0) === 55.U) -> Ti(55),
      (cycle(5, 0) === 56.U) -> Ti(56),
      (cycle(5, 0) === 57.U) -> Ti(57),
      (cycle(5, 0) === 58.U) -> Ti(58),
      (cycle(5, 0) === 59.U) -> Ti(59),
      (cycle(5, 0) === 60.U) -> Ti(60),
      (cycle(5, 0) === 61.U) -> Ti(61),
      (cycle(5, 0) === 62.U) -> Ti(62),
      (cycle(5, 0) === 63.U) -> Ti(63)
    ))
  } else {
    T := Ti(0)
  }

  val s = Wire(UInt(5.W))
  //根据pe数选择s

  if(pe_num == 64) {     //一选一
    s := si(0)
  } else if(pe_num == 32) { //二选一
    s := Mux(cycle(5), si(1), si(0))
  } else if(pe_num == 16) { //四选一
    s := MuxCase(0.U, Array(
      (cycle(5,4) === 0.U) -> si(0),
      (cycle(5,4) === 1.U) -> si(1),
      (cycle(5,4) === 2.U) -> si(2),
      (cycle(5,4) === 3.U) -> si(3)
    ))
  } else if(pe_num == 8) {     //四选一，每个重复两次（八选一）
    s := MuxCase(0.U, Array(
      (cycle(5,4) === 0.U) -> si(0),
      (cycle(5,4) === 1.U) -> si(1),
      (cycle(5,4) === 2.U) -> si(2),
      (cycle(5,4) === 3.U) -> si(3)
    ))
  } else if(pe_num == 4) { //四选一，每个重复四次（十六选一）
    s := MuxCase(0.U, Array(
      (cycle(5, 4) === 0.U) -> si(0),
      (cycle(5, 4) === 1.U) -> si(1),
      (cycle(5, 4) === 2.U) -> si(2),
      (cycle(5, 4) === 3.U) -> si(3)
    ))
  } else if(pe_num == 2) { //八选一，每个重复四次（三十二选一）
    s := MuxCase(0.U, Array(
      (Cat(cycle(5, 4), cycle(1)) === 0.U) -> si(0),
      (Cat(cycle(5, 4), cycle(1)) === 1.U) -> si(1),
      (Cat(cycle(5, 4), cycle(1)) === 2.U) -> si(2),
      (Cat(cycle(5, 4), cycle(1)) === 3.U) -> si(3),
      (Cat(cycle(5, 4), cycle(1)) === 4.U) -> si(4),
      (Cat(cycle(5, 4), cycle(1)) === 5.U) -> si(5),
      (Cat(cycle(5, 4), cycle(1)) === 6.U) -> si(6),
      (Cat(cycle(5, 4), cycle(1)) === 7.U) -> si(7),
    ))
  } else if(pe_num == 1) { //十六选一，每个重复四次（六十四选一）
    s := MuxCase(0.U, Array(
      (Cat(cycle(5, 4), cycle(1,0)) === 0.U) -> si(0),
      (Cat(cycle(5, 4), cycle(1,0)) === 1.U) -> si(1),
      (Cat(cycle(5, 4), cycle(1,0)) === 2.U) -> si(2),
      (Cat(cycle(5, 4), cycle(1,0)) === 3.U) -> si(3),
      (Cat(cycle(5, 4), cycle(1,0)) === 4.U) -> si(4),
      (Cat(cycle(5, 4), cycle(1,0)) === 5.U) -> si(5),
      (Cat(cycle(5, 4), cycle(1,0)) === 6.U) -> si(6),
      (Cat(cycle(5, 4), cycle(1,0)) === 7.U) -> si(7),
      (Cat(cycle(5, 4), cycle(1,0)) === 8.U) -> si(8),
      (Cat(cycle(5, 4), cycle(1,0)) === 9.U) -> si(9),
      (Cat(cycle(5, 4), cycle(1,0)) === 10.U) -> si(10),
      (Cat(cycle(5, 4), cycle(1,0)) === 11.U) -> si(11),
      (Cat(cycle(5, 4), cycle(1,0)) === 12.U) -> si(12),
      (Cat(cycle(5, 4), cycle(1,0)) === 13.U) -> si(13),
      (Cat(cycle(5, 4), cycle(1,0)) === 14.U) -> si(14),
      (Cat(cycle(5, 4), cycle(1,0)) === 15.U) -> si(15)
    ))
  } else{
    s := si(0)
  }

  val md5func_res0 = Wire(UInt(width.W))
  val md5func_res1 = Wire(UInt(width.W))
  val md5func_res2 = Wire(UInt(width.W))
  val md5func_res3 = Wire(UInt(width.W))
  val md5fun_res = Wire(UInt(width.W))
  val tmp_B = Wire(UInt(width.W))
  val tmp_B_shift = Wire(UInt(width.W))
  val B_out = Wire(UInt(width.W))


  //根据PE数选择压缩函数
  if (pe_num == 64) {
    if(NO_PE <= 16) {
      md5fun_res := md5func_res0
    } else if(16 < NO_PE && NO_PE <= 32) {
      md5fun_res := md5func_res1
    } else if(32 < NO_PE && NO_PE <= 48) {
      md5fun_res := md5func_res2
    } else {
      md5fun_res := md5func_res3
    }
  } else if(pe_num == 32) {
    if(NO_PE <= 16) {
      md5fun_res := Mux(cycle > 31.U, md5func_res2, md5func_res0)
    } else {
      md5fun_res := Mux(cycle > 31.U, md5func_res3, md5func_res1)
    }
  } else {
    md5fun_res := MuxCase(0.U, Array(
      (cycle(5, 4) === 0.U) -> md5func_res0,
      (cycle(5, 4) === 1.U) -> md5func_res1,
      (cycle(5, 4) === 2.U) -> md5func_res2,
      (cycle(5, 4) === 3.U) -> md5func_res3
    ))
  }


  //(b&c) | (~b&d)
  md5func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
  //(b&d) | (c&~d)
  md5func_res1 := (inputsWire(1) & inputsWire(3)) | ((~inputsWire(3)) & (inputsWire(2)))
  //b^c^d
  md5func_res2 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
  //c^(b|~d)
  md5func_res3 := inputsWire(2) ^ (~inputsWire(3) | inputsWire(1))
  tmp_B := md5fun_res + inputsWire(0) + T + inputsWire(4)
  tmp_B_shift := (tmp_B << s) | (tmp_B >> (32.U - s))
  B_out := tmp_B_shift + inputsWire(1)
  if(NO_PE == 64) {
    val res1 = inputsWire(3) + "h67452301".U
    val res2 = B_out + "hefcdab89".U
    val res3 = inputsWire(1) + "h98badcfe".U
    val res4 = inputsWire(2) + "h10325476".U
    io.outputs(0) := Cat(res1(7, 0), res1(15, 8), res1(23, 16), res1(31, 24))
    io.outputs(1) := Cat(res2(7, 0), res2(15, 8), res2(23, 16), res2(31, 24))
    io.outputs(2) := Cat(res3(7, 0), res3(15, 8), res3(23, 16), res3(31, 24))
    io.outputs(3) := Cat(res4(7, 0), res4(15, 8), res4(23, 16), res4(31, 24))
    io.outputs(4) := 0.U
  }
  else if (NO_PE == pe_num)  {
    when(cycle === 63.U) {
      val res1 = inputsWire(3) + "h67452301".U
      val res2 = B_out + "hefcdab89".U
      val res3 = inputsWire(1) + "h98badcfe".U
      val res4 = inputsWire(2) + "h10325476".U
      io.outputs(0) := Cat(res1(7, 0), res1(15, 8), res1(23, 16), res1(31, 24))
      io.outputs(1) := Cat(res2(7, 0), res2(15, 8), res2(23, 16), res2(31, 24))
      io.outputs(2) := Cat(res3(7, 0), res3(15, 8), res3(23, 16), res3(31, 24))
      io.outputs(3) := Cat(res4(7, 0), res4(15, 8), res4(23, 16), res4(31, 24))
      io.outputs(4) := 0.U
    }.otherwise{
      io.outputs(0) := inputsWire(3)
      io.outputs(1) := B_out
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := cycle + 1.U
    }
  } else {
    io.outputs(0) := inputsWire(3)
    io.outputs(1) := B_out
    io.outputs(2) := inputsWire(1)
    io.outputs(3) := inputsWire(2)
    io.outputs(4) := cycle + 1.U
  }

}
//object md5Gen extends App {
//  chisel3.Driver.execute(args, () => new md5_alu("md5_2",32, 64, 1))
//}