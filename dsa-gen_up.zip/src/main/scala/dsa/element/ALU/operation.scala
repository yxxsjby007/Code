package dsa.element.ALU

import chisel3._
import chisel3.util._

import chisel3.UInt

import scala.collection.mutable.ListBuffer


object OPC extends Enumeration {
  type OPC = Value
  val md5,
  sha1,
  sha256,
  sm3,
  sha224,
  sha384_32,
  sha384_64,
  aes128 = Value
  val numOPC = this.values.size

  def printOPC = {
    this.values.foreach{ op => println(s"$op\t: ${op.id}")}
  }
}

object alu_Info {
  val md5_penumMap: Map[Int, List[Int]] = Map(
    //penum -> s的seq中的元素个数,Ti的seq中的元素个数
    80 -> List(1,1),
    64 -> List(1,1),
    32 -> List(2,2),
    16 -> List(4,4),
    8 -> List(4,8),
    4 -> List(4,16),
    2 -> List(8,32),
    1 -> List(16,64)
  )

  val sha1_penumMap: Map[Int, List[Int]] = Map(
    //pe_num -> kt中seq的元素个数
    80 -> List(1),
    40 -> List(2),
    20 -> List(4),
    16 -> List(4),
    8  -> List(4),
    5  -> List(4),
    4  -> List(4),
    2  -> List(4),
    1  -> List(4)
  )

  val sha512_penumMap: Map[Int, List[Int]] = Map(
    //pe_num -> kt中seq的元素个数
    80 -> List(1),
    40 -> List(2),
    20 -> List(4),
    16 -> List(5),
    10 -> List(8),
    8  -> List(10),
    5  -> List(16),
    4  -> List(20),
    2  -> List(40),
    1  -> List(80)
  )

  val sha224_penumMap: Map[Int, List[Int]] = Map(
    //pe_num -> kt中元素个数
    64 -> List(1),
    32 -> List(2),
    16 -> List(4),
    8 -> List(8),
    4 -> List(16),
    2 -> List(32),
    1 -> List(64)
  )

  val sha256_penumMap: Map[Int, List[Int]] = Map(
    //pe_num -> kt中元素个数
    80 -> List(1),
    64 -> List(1),
    32 -> List(2),
    16 -> List(4),
    8 -> List(8),
    4 -> List(16),
    2 -> List(32),
    1 -> List(64)
  )

  val sha384_32_penumMap: Map[Int, List[Int]] = Map(
    //pe_num -> kt中元素个数
    80 -> List(1),
    40 -> List(2),
    20 -> List(4),
    16 -> List(5),
    8  -> List(10),
    5  -> List(16),
    4  -> List(20),
    2  -> List(40),
    1  -> List(80)
  )
}

object OpInfo {
  import dsa.element.ALU.OPC._
  val OpInfoMap: Map[OPC.OPC, List[Int]] = Map(
    //in_num, outnum, cycle, DPM_outnum, DPM_out_data
    OPC.md5 -> List(6,5,64,1,64),
    OPC.sha1 -> List(7,6,80,1,80),
    OPC.sha256 -> List(10,9,64,1,64),
    OPC.sm3 -> List(11,9,64,2,128),
    OPC.sha224 -> List(10,9,64,1,64),
    OPC.sha384_32 -> List(19,17,80,2,160),
    OPC.sha384_64 -> List(8,9,80,1,80),
    OPC.aes128 -> List(6,5,10,1,10)
  )

  def getALUinNum(op: OPC.OPC): Int = {
    OpInfoMap(op)(0)
  }

  def getALUoutNum(op: OPC.OPC): Int = {
    OpInfoMap(op)(1)
  }
55
  def getDPMoutNum(op: OPC.OPC): Int = {
    OpInfoMap(op)(3)
  }

  def getDPMOutData(op: OPC.OPC): Int = {
    OpInfoMap(op)(4)
  }



  val String2IntMap : Map[String,Int] = Map(
    "md5" -> md5.id,
    "sha1" -> sha1.id,
    "sha256" -> sha256.id,
    "sm3" -> sm3.id,
    "sha224" -> sha224.id,
    "sha384_32" -> sha384_32.id,
    "sha384_64" -> sha384_64.id,
    "aes128" -> aes128.id
  )

  def getOperandCycle(op: OPC.OPC): Int = {
    OpInfoMap(op)(2)
  }

  val opInt2StringMap : Map[Int, String] = Map(
    0 -> "md5",
    1 -> "sha1"
  )


  def fuget(op : Int) :ListBuffer[OPC.OPC]= {
    val oplist = new ListBuffer[OPC.OPC]
    for( i <- 0 until OPC.numOPC ){
      if((op & ( 1 << i))> 0){
        oplist.append(OPC(i))
      }
    }
    oplist
  }

}


