package dsa.element.ALU

import chisel3._
import chisel3.util._

class aes_alu(elename: String, width: Int, NO_PE: Int, aes_type: Int) extends Module {
  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(4, UInt(width.W)))
    val outputs = Output(Vec(4, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(4, UInt(width.W)))

  for (i <- 0 until 4) {
    inputsWire(i) := RegNext(io.inputs(i))
  }

  val shiftrow0 = Cat(inputsWire(0)(31, 24), inputsWire(1)(23, 16), inputsWire(2)(15, 8), inputsWire(3)(7, 0))
  val shiftrow1 = Cat(inputsWire(1)(31, 24), inputsWire(2)(23, 16), inputsWire(3)(15, 8), inputsWire(0)(7, 0))
  val shiftrow2 = Cat(inputsWire(2)(31, 24), inputsWire(3)(23, 16), inputsWire(0)(15, 8), inputsWire(1)(7, 0))
  val shiftrow3 = Cat(inputsWire(3)(31, 24), inputsWire(0)(23, 16), inputsWire(1)(15, 8), inputsWire(2)(7, 0))

  //列变换实现方式1
  //  def mixc(IN1: UInt, IN2: UInt, IN3: UInt, IN4: UInt): UInt = {
  //    val  MIXCOLUMN =  Wire(Vec(8, Bool()))
  //    MIXCOLUMN(7) := IN1(6)^IN2(6)^IN2(7)^IN3(7)^IN4(7)
  //    MIXCOLUMN(6) := IN1(5)^IN2(5)^IN2(6)^IN3(6)^IN4(6)
  //    MIXCOLUMN(5) := IN1(4)^IN2(4)^IN2(5)^IN3(5)^IN4(5)
  //    MIXCOLUMN(4) := IN1(3)^IN1(7)^IN2(3)^IN2(4)^IN2(7)^IN3(4)^IN4(4)
  //    MIXCOLUMN(3) := IN1(2)^IN1(7)^IN2(2)^IN2(3)^IN2(7)^IN3(3)^IN4(3)
  //    MIXCOLUMN(2) := IN1(1)^IN2(1)^IN2(2)^IN3(2)^IN4(2)
  //    MIXCOLUMN(1) := IN1(0)^IN1(7)^IN2(0)^IN2(1)^IN2(7)^IN3(1)^IN4(1)
  //    MIXCOLUMN(0) := IN1(7)^IN2(7)^IN2(0)^IN3(0)^IN4(0)
  //    val res = MIXCOLUMN.asUInt()
  //    res
  //  }
  //
  //  val mixdata0 = mixc(inputsWire(0)(31, 24), inputsWire(0)(23, 16), inputsWire(0)(15, 8), inputsWire(0)(7, 0))
  //  val mixdata1 = mixc(inputsWire(0)(23, 16), inputsWire(0)(15, 8), inputsWire(0)(7, 0), inputsWire(0)(31, 24))
  //  val mixdata2 = mixc(inputsWire(0)(15, 8), inputsWire(0)(7, 0), inputsWire(0)(31, 24), inputsWire(0)(23, 16))
  //  val mixdata3 = mixc(inputsWire(0)(7, 0), inputsWire(0)(31, 24), inputsWire(0)(23, 16), inputsWire(0)(15, 8))
  //  val mixcolumn = Cat(mixdata0, mixdata1, mixdata2, mixdata3)
  //

  //列变换实现方式2
  def twoTimesFunc(mixinTwo: UInt): UInt = {
    Mux(mixinTwo(7) === 0.U, Cat(mixinTwo(6, 0), 0.U(1.W)), Cat(mixinTwo(6, 0), 0.U(1.W)) ^ "b00011011".U)
  }

  def ThreeTimesFunc(mixinThree: UInt): UInt = {
    Mux(mixinThree(7) === 0.U, Cat(mixinThree(6, 0), 0.U(1.W)) ^ mixinThree, Cat(mixinThree(6, 0), 0.U(1.W)) ^ "b00011011".U ^ mixinThree)
  }

  //  //用ram构建sbox的查找表
  //  val subram0 = Module(new ram(8,8,"E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
  //  val subram1 = Module(new ram(8,8,"E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
  //  val subram2 = Module(new ram(8,8,"E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
  //  val subram3 = Module(new ram(8,8,"E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
  //  val cntwire = Wire(UInt(3.W))
  //  val cntReg = RegEnable(cntwire + 1.U, 0.U, true.asBool())
  //  cntwire := Mux(cntReg === 5.U, 0.U, cntReg)
  //  subram0.io.address := MuxLookup(cntwire, 0.U, Array(1.U -> s_data(0), 2.U -> s_data(4), 3.U -> s_data(8), 4.U -> s_data(12)))
  //  subram1.io.address := MuxLookup(cntwire, 0.U, Array(1.U -> s_data(1), 2.U -> s_data(5), 3.U -> s_data(9), 4.U -> s_data(13)))
  //  subram2.io.address := MuxLookup(cntwire, 0.U, Array(1.U -> s_data(2), 2.U -> s_data(6), 3.U -> s_data(10), 4.U -> s_data(14)))
  //  subram3.io.address := MuxLookup(cntwire, 0.U, Array(1.U -> s_data(3), 2.U -> s_data(7), 3.U -> s_data(11), 4.U -> s_data(15)))
  //  val w0_s = RegEnable(Cat(subram0.io.value,subram1.io.value,subram2.io.value,subram3.io.value), cntwire === 1.U)
  //  val w1_s = RegEnable(Cat(subram0.io.value,subram1.io.value,subram2.io.value,subram3.io.value), cntwire === 2.U)
  //  val w2_s = RegEnable(Cat(subram0.io.value,subram1.io.value,subram2.io.value,subram3.io.value), cntwire === 3.U)
  //  val w3_s = RegEnable(Cat(subram0.io.value,subram1.io.value,subram2.io.value,subram3.io.value), cntwire === 4.U)


  val w0_mc0 = twoTimesFunc(inputsWire(0)(31, 24)) ^ ThreeTimesFunc(inputsWire(0)(23, 16)) ^ inputsWire(0)(15, 8) ^ inputsWire(0)(7, 0)
  val w0_mc1 = inputsWire(0)(31, 24) ^ twoTimesFunc(inputsWire(0)(23, 16)) ^ ThreeTimesFunc(inputsWire(0)(15, 8)) ^ inputsWire(0)(7, 0)
  val w0_mc2 = inputsWire(0)(31, 24) ^ inputsWire(0)(23, 16) ^ twoTimesFunc(inputsWire(0)(15, 8)) ^ ThreeTimesFunc(inputsWire(0)(7, 0))
  val w0_mc3 = ThreeTimesFunc(inputsWire(0)(31, 24)) ^ inputsWire(0)(23, 16) ^ inputsWire(0)(15, 8) ^ twoTimesFunc(inputsWire(0)(7, 0))

  val mixcolumn = Cat(w0_mc0, w0_mc1, w0_mc2, w0_mc3)




  val xordata = inputsWire(0) ^ inputsWire(1) //输入的第一个值与第二个值异或
  val passdata = inputsWire(0)


  if (NO_PE % 13 == 0 || NO_PE % 13 == 1 || NO_PE % 13 == 2 || NO_PE % 13 == 3) {
    io.outputs(0) := xordata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U

  } else if (NO_PE % 13 == 8) {
    io.outputs(0) := shiftrow0
    io.outputs(1) := shiftrow1
    io.outputs(2) := shiftrow2
    io.outputs(3) := shiftrow3
  } else if ((NO_PE % 13 == 4 || NO_PE % 13 == 5 || NO_PE % 13 == 6 || NO_PE % 13 == 7)) {

    val s_data = Wire(Vec(4, UInt(8.W)))
    s_data(0) := inputsWire(0)(31, 24)
    s_data(1) := inputsWire(0)(23, 16)
    s_data(2) := inputsWire(0)(15, 8)
    s_data(3) := inputsWire(0)(7, 0)

    val subrom = Module(new multiport_rom(8, 8, 4, 0))
    for (i <- 0 until 4) {
      subrom.io.address(i) := s_data(i)
    }
    val subword = Cat(subrom.io.value(0), subrom.io.value(1), subrom.io.value(2), subrom.io.value(3))

    io.outputs(0) := subword
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U

  } else if ((NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) && (NO_PE > 117) && (aes_type == 0)) {
    io.outputs(0) := passdata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  } else if ((NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) && (NO_PE > 143) && (aes_type == 1)) {
    io.outputs(0) := passdata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  } else if ((NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) && (NO_PE > 169) && (aes_type == 2)) {
    io.outputs(0) := passdata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  } else if (NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) {
    io.outputs(0) := mixcolumn
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  }


}
