package dsa.element.ALU
import chisel3._
import chisel3.util.experimental.loadMemoryFromFile
class ram(address_width: Int, value_width: Int, data_from: String) extends Module {
  val io = IO(new Bundle {
    val address = Input(UInt(address_width.W))
    val value   = Output(UInt(value_width.W))
  })
  val memory = Mem(256, UInt(value_width.W))
  io.value := memory.read(io.address)
  loadMemoryFromFile(memory, data_from)
}

//object test_ram extends App {
//  val address_width = 8
//  val value_width = 8
//  val data_from = "E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"
//
//}
