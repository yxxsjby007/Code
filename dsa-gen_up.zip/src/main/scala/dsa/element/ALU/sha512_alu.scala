package dsa.element.ALU

import chisel3._
import chisel3.util._
import scala.Array
import scala.collection.mutable.ListBuffer
import dsa.element.ALU.alu_Info.sha512_penumMap

class sha512_alu(elename: String, width: Int, pe_num: Int, NO_PE: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle {
    val cfg = Input(UInt(1.W)) //通过cfg判断为循环的起始位置
    val inputs = Input(Vec(10, UInt(width.W))) //a,b,c,d,e,cycle,w
    val outputs = Output(Vec(9, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(9, UInt(width.W)))
  val cycle = Wire(UInt(7.W))
  if(pe_num == 80) {
    if (NO_PE == 1) {
      inputsWire(0) := "h6A09E667F3BCC908".U
      inputsWire(1) := "hBB67AE8584CAA73B".U
      inputsWire(2) := "h3C6EF372FE94F82B".U
      inputsWire(3) := "hA54FF53A5F1D36F1".U
      inputsWire(4) := "h510E527FADE682D1".U
      inputsWire(5) := "h9B05688C2B3E6C1F".U
      inputsWire(6) := "h1F83D9ABFB41BD6B".U
      inputsWire(7) := "h5BE0CD19137E2179".U
      cycle := 0.U
      inputsWire(8) := RegNext(io.inputs(9))
    } else {
      for (i <- 0 until 8) {
        inputsWire(i) := RegNext(io.inputs(i))
        inputsWire(8) := RegNext(io.inputs(9))
        cycle := RegNext(io.inputs(8)(6, 0))
      }
    }
  }else if(NO_PE == 1) {
    when(io.cfg === 1.U) {
      inputsWire(0) := "h6A09E667F3BCC908".U
      inputsWire(1) := "hBB67AE8584CAA73B".U
      inputsWire(2) := "h3C6EF372FE94F82B".U
      inputsWire(3) := "hA54FF53A5F1D36F1".U
      inputsWire(4) := "h510E527FADE682D1".U
      inputsWire(5) := "h9B05688C2B3E6C1F".U
      inputsWire(6) := "h1F83D9ABFB41BD6B".U
      inputsWire(7) := "h5BE0CD19137E2179".U
      cycle := 0.U
      inputsWire(8) := RegNext(io.inputs(9))
    }.otherwise {
      for (i <- 0 until 8) {
        inputsWire(i) := RegNext(io.inputs(i))
        inputsWire(8) := RegNext(io.inputs(9))
        cycle := RegNext(io.inputs(8)(6,0))
      }
    }
  } else {
    for (i <- 0 until 8) {
      inputsWire(i) := RegNext(io.inputs(i))
      inputsWire(8) := RegNext(io.inputs(9))
      cycle := RegNext(io.inputs(8)(6,0))
    }
  }

  val kt = Wire(UInt(width.W))
  val k_ori = Seq("h428A2F98D728AE22".U, "h7137449123EF65CD".U, "hB5C0FBCFEC4D3B2F".U, "hE9B5DBA58189DBBC".U,
                  "h3956C25BF348B538".U, "h59F111F1B605D019".U, "h923F82A4AF194F9B".U, "hAB1C5ED5DA6D8118".U,
                  "hD807AA98A3030242".U, "h12835B0145706FBE".U, "h243185BE4EE4B28C".U, "h550C7DC3D5FFB4E2".U,
                  "h72BE5D74F27B896F".U, "h80DEB1FE3B1696B1".U, "h9BDC06A725C71235".U, "hC19BF174CF692694".U,
                  "hE49B69C19EF14AD2".U, "hEFBE4786384F25E3".U, "h0FC19DC68B8CD5B5".U, "h240CA1CC77AC9C65".U,
                  "h2DE92C6F592B0275".U, "h4A7484AA6EA6E483".U, "h5CB0A9DCBD41FBD4".U, "h76F988DA831153B5".U,
                  "h983E5152EE66DFAB".U, "hA831C66D2DB43210".U, "hB00327C898FB213F".U, "hBF597FC7BEEF0EE4".U,
                  "hC6E00BF33DA88FC2".U, "hD5A79147930AA725".U, "h06CA6351E003826F".U, "h142929670A0E6E70".U,
                  "h27B70A8546D22FFC".U, "h2E1B21385C26C926".U, "h4D2C6DFC5AC42AED".U, "h53380D139D95B3DF".U,
                  "h650A73548BAF63DE".U, "h766A0ABB3C77B2A8".U, "h81C2C92E47EDAEE6".U, "h92722C851482353B".U,
                  "hA2BFE8A14CF10364".U, "hA81A664BBC423001".U, "hC24B8B70D0F89791".U, "hC76C51A30654BE30".U,
                  "hD192E819D6EF5218".U, "hD69906245565A910".U, "hF40E35855771202A".U, "h106AA07032BBD1B8".U,
                  "h19A4C116B8D2D0C8".U, "h1E376C085141AB53".U, "h2748774CDF8EEB99".U, "h34B0BCB5E19B48A8".U,
                  "h391C0CB3C5C95A63".U, "h4ED8AA4AE3418ACB".U, "h5B9CCA4F7763E373".U, "h682E6FF3D6B2B8A3".U,
                  "h748F82EE5DEFB2FC".U, "h78A5636F43172F60".U, "h84C87814A1F0AB72".U, "h8CC702081A6439EC".U,
                  "h90BEFFFA23631E28".U, "hA4506CEBDE82BDE9".U, "hBEF9A3F7B2C67915".U, "hC67178F2E372532B".U,
                  "hCA273ECEEA26619C".U, "hD186B8C721C0C207".U, "hEADA7DD6CDE0EB1E".U, "hF57D4F7FEE6ED178".U,
                  "h06F067AA72176FBA".U, "h0A637DC5A2C898A6".U, "h113F9804BEF90DAE".U, "h1B710B35131C471B".U,
                  "h28DB77F523047D84".U, "h32CAAB7B40C72493".U, "h3C9EBE0A15C9BEBC".U, "h431D67C49C100D4C".U,
                  "h4CC5D4BECB3E42B6".U, "h597F299CFC657E2A".U, "h5FCB6FAB3AD6FAEC".U, "h6C44198C4A475817".U)



  val k = VecInit(Seq.fill(sha512_penumMap(pe_num)(0))(0.U(width.W)))
  for(i <- 0 until sha512_penumMap(pe_num)(0)) {
    k(i) := k_ori((i * pe_num) + NO_PE - 1)
  }

  //根据PE_num选择kt
  if(pe_num == 80) {
    kt := k(0)
  } else if(pe_num == 40) { // 二选一
    kt := Mux(cycle < 40.U, k(0), k(1))
  } else if(pe_num == 20) { //四选一
    kt := MuxCase(0.U, Array(
      (cycle < 20.U) -> k(0),
      (20.U <= cycle && cycle < 40.U) -> k(1),
      (40.U <= cycle && cycle < 60.U) -> k(2),
      (60.U <= cycle && cycle < 80.U) -> k(3)))
  } else if(pe_num == 16) {
    kt := MuxCase(0.U, Array(
      (cycle < 16.U) -> k(0),
      (16.U <= cycle && cycle < 32.U) -> k(1),
      (32.U <= cycle && cycle < 48.U) -> k(2),
      (48.U <= cycle && cycle < 64.U) -> k(3),
      (64.U <= cycle && cycle < 80.U) -> k(4)))
  } else if(pe_num == 1) {
    kt := MuxCase(0.U, Array(
      (cycle === 0.U) -> k(0),
      (cycle === 1.U) -> k(1),
      (cycle === 2.U) -> k(2),
      (cycle === 3.U) -> k(3),
      (cycle === 4.U) -> k(4),
      (cycle === 5.U) -> k(5),
      (cycle === 6.U) -> k(6),
      (cycle === 7.U) -> k(7),
      (cycle === 8.U) -> k(8),
      (cycle === 9.U) -> k(9),
      (cycle === 10.U) -> k(10),
      (cycle === 11.U) -> k(11),
      (cycle === 12.U) -> k(12),
      (cycle === 13.U) -> k(13),
      (cycle === 14.U) -> k(14),
      (cycle === 15.U) -> k(15),
      (cycle === 16.U) -> k(16),
      (cycle === 17.U) -> k(17),
      (cycle === 18.U) -> k(18),
      (cycle === 19.U) -> k(19),
      (cycle === 20.U) -> k(20),
      (cycle === 21.U) -> k(21),
      (cycle === 22.U) -> k(22),
      (cycle === 23.U) -> k(23),
      (cycle === 24.U) -> k(24),
      (cycle === 25.U) -> k(25),
      (cycle === 26.U) -> k(26),
      (cycle === 27.U) -> k(27),
      (cycle === 28.U) -> k(28),
      (cycle === 29.U) -> k(29),
      (cycle === 30.U) -> k(30),
      (cycle === 31.U) -> k(31),
      (cycle === 32.U) -> k(32),
      (cycle === 33.U) -> k(33),
      (cycle === 34.U) -> k(34),
      (cycle === 35.U) -> k(35),
      (cycle === 36.U) -> k(36),
      (cycle === 37.U) -> k(37),
      (cycle === 38.U) -> k(38),
      (cycle === 39.U) -> k(39),
      (cycle === 40.U) -> k(40),
      (cycle === 41.U) -> k(41),
      (cycle === 42.U) -> k(42),
      (cycle === 43.U) -> k(43),
      (cycle === 44.U) -> k(44),
      (cycle === 45.U) -> k(45),
      (cycle === 46.U) -> k(46),
      (cycle === 47.U) -> k(47),
      (cycle === 48.U) -> k(48),
      (cycle === 49.U) -> k(49),
      (cycle === 50.U) -> k(50),
      (cycle === 51.U) -> k(51),
      (cycle === 52.U) -> k(52),
      (cycle === 53.U) -> k(53),
      (cycle === 54.U) -> k(54),
      (cycle === 55.U) -> k(55),
      (cycle === 56.U) -> k(56),
      (cycle === 57.U) -> k(57),
      (cycle === 58.U) -> k(58),
      (cycle === 59.U) -> k(59),
      (cycle === 60.U) -> k(60),
      (cycle === 61.U) -> k(61),
      (cycle === 62.U) -> k(62),
      (cycle === 63.U) -> k(63),
      (cycle === 64.U) -> k(64),
      (cycle === 65.U) -> k(65),
      (cycle === 66.U) -> k(66),
      (cycle === 67.U) -> k(67),
      (cycle === 68.U) -> k(68),
      (cycle === 69.U) -> k(69),
      (cycle === 70.U) -> k(70),
      (cycle === 71.U) -> k(71),
      (cycle === 72.U) -> k(72),
      (cycle === 73.U) -> k(73),
      (cycle === 74.U) -> k(74),
      (cycle === 75.U) -> k(75),
      (cycle === 76.U) -> k(76),
      (cycle === 77.U) -> k(77),
      (cycle === 78.U) -> k(78),
      (cycle === 79.U) -> k(79)))
  } else {
    kt := k(0)
  }
  val SIGMA0 = Wire(UInt(width.W))
  val SIGMA1 = Wire(UInt(width.W))
  val Ch = Wire(UInt(width.W))
  val Maj = Wire(UInt(width.W))
  val T1 = Wire(UInt(width.W))
  val T2 = Wire(UInt(width.W))
  val ROTR28 = Wire(UInt(width.W))
  val ROTR34 = Wire(UInt(width.W))
  val ROTR39 = Wire(UInt(width.W))
  val ROTR14 = Wire(UInt(width.W))
  val ROTR18 = Wire(UInt(width.W))
  val ROTR41 = Wire(UInt(width.W))

  ROTR28 := Cat(inputsWire(0)(27,0), inputsWire(0)(63,28))
  ROTR34 := Cat(inputsWire(0)(33,0), inputsWire(0)(63,34))
  ROTR39 := Cat(inputsWire(0)(38,0), inputsWire(0)(63,39))
  ROTR14 := Cat(inputsWire(4)(13,0), inputsWire(4)(63,14))
  ROTR18 := Cat(inputsWire(4)(17,0), inputsWire(4)(63,18))
  ROTR41 := Cat(inputsWire(4)(40,0), inputsWire(4)(63,41))
  //(e&f) ^ (~e&g)
  Ch := (inputsWire(4) & inputsWire(5)) ^ (~inputsWire(4) & inputsWire(6))
  //(a&b) | (a&c) | (b&c)
  Maj := (inputsWire(0) & inputsWire(1)) ^ (inputsWire(0) & inputsWire(2)) ^ (inputsWire(1) & inputsWire(2))
  SIGMA0 := ROTR28 ^ ROTR34 ^ ROTR39
  SIGMA1 := ROTR14 ^ ROTR18 ^ ROTR41
  T1 := inputsWire(7) + SIGMA1 + Ch + kt + inputsWire(8)
  T2 := SIGMA0 + Maj


  if(NO_PE == 80) {
    io.outputs(0) := T1 + T2 + "h6A09E667F3BCC908".U;
    io.outputs(1) := inputsWire(0) + "hBB67AE8584CAA73B".U;
    io.outputs(2) := inputsWire(1) + "h3C6EF372FE94F82B".U;
    io.outputs(3) := inputsWire(2) + "hA54FF53A5F1D36F1".U;
    io.outputs(4) := T1 + inputsWire(3) + "h510E527FADE682D1".U;
    io.outputs(5) := inputsWire(4) + "h9B05688C2B3E6C1F".U;
    io.outputs(6) := inputsWire(5) + "h1F83D9ABFB41BD6B".U;
    io.outputs(7) := inputsWire(6) + "h5BE0CD19137E2179".U;
    io.outputs(8) := 0.U
  } else if(NO_PE == pe_num) {
    when(cycle === 79.U) {
      io.outputs(0) := T1 + T2 + "h6A09E667F3BCC908".U;
      io.outputs(1) := inputsWire(0) + "hBB67AE8584CAA73B".U;
      io.outputs(2) := inputsWire(1) + "h3C6EF372FE94F82B".U;
      io.outputs(3) := inputsWire(2) + "hA54FF53A5F1D36F1".U;
      io.outputs(4) := T1 + inputsWire(3) + "h510E527FADE682D1".U;
      io.outputs(5) := inputsWire(4) + "h9B05688C2B3E6C1F".U;
      io.outputs(6) := inputsWire(5) + "h1F83D9ABFB41BD6B".U;
      io.outputs(7) := inputsWire(6) + "h5BE0CD19137E2179".U;
      io.outputs(8) := 0.U
    } .otherwise{
      io.outputs(0) := T1 + T2
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)
      io.outputs(8) := cycle + 1.U
    }
  } else {
    io.outputs(0) := T1 + T2
    io.outputs(1) := inputsWire(0)
    io.outputs(2) := inputsWire(1)
    io.outputs(3) := inputsWire(2)
    io.outputs(4) := T1 + inputsWire(3)
    io.outputs(5) := inputsWire(4)
    io.outputs(6) := inputsWire(5)
    io.outputs(7) := inputsWire(6)
    io.outputs(8) := cycle + 1.U
  }
}

//object sha512Gen extends App {
//  chisel3.Driver.execute(args, () => new sha512_alu("alu_sha512", 32, 16, 1))
//}