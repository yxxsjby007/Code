package dsa.element.ALU
import chisel3._
import chisel3.util._
import dsa.element.ALU.alu_Info.sha1_penumMap
class sha1_new_alu (elename: String, width: Int, pe_num: Int, NO_PE: Int) extends Module {
  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(6, UInt(width.W))) //a,b,c,d,e,w
    val outputs = Output(Vec(5, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(6, UInt(width.W)))
  if(NO_PE == 1) {
    inputsWire(0) := "h67452301".U
    inputsWire(1) := "hEFCDAB89".U
    inputsWire(2) := "h98badcfe".U
    inputsWire(3) := "h10325476".U
    inputsWire(4) := "hC3D2E1F0".U
    inputsWire(5) := RegNext(io.inputs(5))
  } else {
    for (i <- 0 until 6) {
      inputsWire(i) := RegNext(io.inputs(i))
    }
  }
  val kt = Wire(UInt(32.W))
  val sha1func_res = Wire(UInt(width.W))
  val sha1func_res0 = Wire(UInt(width.W))
  val sha1func_res1 = Wire(UInt(width.W))
  val sha1func_res2 = Wire(UInt(width.W))
  val k_ori = Seq("h5A827999".U, "h6ED9EBA1".U, "h8F1BBCDC".U, "hCA62C1D6".U)
  if(NO_PE <= 20) {
    kt := k_ori(0)
    sha1func_res := sha1func_res0
  } else if (20 < NO_PE &&  NO_PE <= 40) {
    kt := k_ori(1)
    sha1func_res := sha1func_res1
  } else if (40 < NO_PE &&  NO_PE <= 60) {
    kt := k_ori(2)
    sha1func_res := sha1func_res2
  } else {
    kt := k_ori(3)
    sha1func_res := sha1func_res1
  }

  //(b&c) | (~b&d)
  sha1func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
  //b^c^d
  sha1func_res1 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
  //(b&c) | (b&d) | (c&d)
  sha1func_res2 := (inputsWire(1) & inputsWire(2)) | (inputsWire(1) & inputsWire(3)) | (inputsWire(2) & inputsWire(3))

  val shift_a = Wire(UInt(width.W))
  val shift_b = Wire(UInt(width.W))
  val tmp_A = Wire(UInt(width.W))
  shift_a := Cat(inputsWire(0)(26, 0), inputsWire(0)(31, 27))
  shift_b := Cat(inputsWire(1)(1, 0), inputsWire(1)(31, 2))
  tmp_A := shift_a + sha1func_res + inputsWire(4) + kt + inputsWire(5)

  if(NO_PE == 80) {
    io.outputs(0) := tmp_A + "h67452301".U
    io.outputs(1) := inputsWire(0) + "hEFCDAB89".U
    io.outputs(2) := shift_b + "h98badcfe".U
    io.outputs(3) := inputsWire(2) + "h10325476".U
    io.outputs(4) := inputsWire(3) + "hC3D2E1F0".U
  } else {
    io.outputs(0) := tmp_A
    io.outputs(1) := inputsWire(0)
    io.outputs(2) := shift_b
    io.outputs(3) := inputsWire(2)
    io.outputs(4) := inputsWire(3)
  }

}
