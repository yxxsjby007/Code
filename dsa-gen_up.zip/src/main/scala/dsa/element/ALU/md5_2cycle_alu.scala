package dsa.element.ALU
import chisel3._
import chisel3.util._

class md5_2cycle_alu (elename: String, width: Int, pe_num: Int, NO_PE: Int) extends Module{

  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(6, UInt(width.W))) //a,b,c,d,e,cycle,w
    val outputs = Output(Vec(4, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(6, UInt(width.W)))
  if((NO_PE - 1) % 32 == 0) {
    inputsWire(0) := "h67452301".U
    inputsWire(1) := "hefcdab89".U
    inputsWire(2) := "h98badcfe".U
    inputsWire(3) := "h10325476".U
    inputsWire(4) := RegEnable(io.inputs(4), 0.U, true.asBool())
    inputsWire(5) := RegEnable(io.inputs(5), 0.U, true.asBool())
  } else {
    for (i <- 0 until 6) {
      inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
    }
  }

  val si_ori = Seq(7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U,
    5.U, 9.U, 14.U, 20.U, 5.U, 9.U, 14.U, 20.U, 5.U, 9.U, 14.U, 20.U, 5.U, 9.U, 14.U, 20.U,
    4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U,
    6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U)

  val s = Wire(UInt(5.W))
  val s_1 = Wire(UInt(5.W))
  s := si_ori(((NO_PE - 1) % 32) * 2)
  s_1 := si_ori(((NO_PE - 1) % 32) * 2 + 1)

  val Ti_ori = Seq(
    "hd76aa478".U, "he8c7b756".U, "h242070db".U, "hc1bdceee".U, "hf57c0faf".U, "h4787c62a".U, "ha8304613".U, "hfd469501".U,
    "h698098d8".U, "h8b44f7af".U, "hffff5bb1".U, "h895cd7be".U, "h6b901122".U, "hfd987193".U, "ha679438e".U, "h49b40821".U,
    "hf61e2562".U, "hc040b340".U, "h265e5a51".U, "he9b6c7aa".U, "hd62f105d".U, "h02441453".U, "hd8a1e681".U, "he7d3fbc8".U,
    "h21e1cde6".U, "hc33707d6".U, "hf4d50d87".U, "h455a14ed".U, "ha9e3e905".U, "hfcefa3f8".U, "h676f02d9".U, "h8d2a4c8a".U,
    "hfffa3942".U, "h8771f681".U, "h6d9d6122".U, "hfde5380c".U, "ha4beea44".U, "h4bdecfa9".U, "hf6bb4b60".U, "hbebfbc70".U,
    "h289b7ec6".U, "heaa127fa".U, "hd4ef3085".U, "h04881d05".U, "hd9d4d039".U, "he6db99e5".U, "h1fa27cf8".U, "hc4ac5665".U,
    "hf4292244".U, "h432aff97".U, "hab9423a7".U, "hfc93a039".U, "h655b59c3".U, "h8f0ccc92".U, "hffeff47d".U, "h85845dd1".U,
    "h6fa87e4f".U, "hfe2ce6e0".U, "ha3014314".U, "h4e0811a1".U, "hf7537e82".U, "hbd3af235".U, "h2ad7d2bb".U, "heb86d391".U)

  val T = Wire(UInt(32.W))
  val T_1 = Wire(UInt(32.W))
  T := Ti_ori(((NO_PE - 1) % 32) * 2)
  T_1 := Ti_ori(((NO_PE - 1) % 32) * 2 + 1)
  val md5func_res0 = Wire(UInt(width.W))
  val md5func_res1 = Wire(UInt(width.W))
  val md5func_res2 = Wire(UInt(width.W))
  val md5func_res3 = Wire(UInt(width.W))
  val md5fun_res = Wire(UInt(width.W))

  val md5func_res0_1 = Wire(UInt(width.W))
  val md5func_res1_1 = Wire(UInt(width.W))
  val md5func_res2_1 = Wire(UInt(width.W))
  val md5func_res3_1 = Wire(UInt(width.W))
  val md5fun_res_1 = Wire(UInt(width.W))

  val tmp_B = Wire(UInt(width.W))
  val tmp_B_shift = Wire(UInt(width.W))
  val B_out = Wire(UInt(width.W))


  if ((NO_PE - 1)% 32 < 8) {
    md5fun_res := md5func_res0
    md5fun_res_1 := md5func_res0_1
  } else if ((8 <= (NO_PE - 1) % 32) && ((NO_PE - 1) % 32) < 16) {
    md5fun_res := md5func_res1
    md5fun_res_1 := md5func_res1_1
  } else if ((16 <= (NO_PE - 1) % 32) && ((NO_PE - 1) % 32 < 24)) {
    md5fun_res := md5func_res2
    md5fun_res_1 := md5func_res2_1
  } else {
    md5fun_res := md5func_res3
    md5fun_res_1 := md5func_res3_1
  }


  //(b&c) | (~b&d)
  md5func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))

  //(b&d) | (c&~d)
  md5func_res1 := (inputsWire(1) & inputsWire(3)) | ((~inputsWire(3)) & (inputsWire(2)))

  //b^c^d
  md5func_res2 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)

  //c^(b|~d)
  md5func_res3 := inputsWire(2) ^ (~inputsWire(3) | inputsWire(1))
  tmp_B := md5fun_res + inputsWire(0) + T + inputsWire(8)
  tmp_B_shift := (tmp_B << s) | (tmp_B >> (32.U - s))
  B_out := tmp_B_shift + inputsWire(1)

  val md5_tmp_res0 = inputsWire(3)
  val md5_tmp_res1 = B_out
  val md5_tmp_res2 = inputsWire(1)
  val md5_tmp_res3 = inputsWire(2)


  val tmp_B_1 = md5fun_res_1 + md5_tmp_res0 + T_1 + inputsWire(9)
  val tmp_B_shift_1 = (tmp_B_1 << s_1) | (tmp_B_1 >> (32.U - s_1))
  val B_out_1 = tmp_B_shift_1 + md5_tmp_res1


  //(b&c) | (~b&d)
  md5func_res0_1 := (md5_tmp_res1 & md5_tmp_res2) | ((~md5_tmp_res1) & md5_tmp_res3)
  //(b&d) | (c&~d)
  md5func_res1_1 := (md5_tmp_res1 & md5_tmp_res3) | ((~md5_tmp_res3) & (md5_tmp_res2))
  //b^c^d
  md5func_res2_1 := md5_tmp_res1 ^ md5_tmp_res2 ^ md5_tmp_res3
  //c^(b|~d)
  md5func_res3_1 := md5_tmp_res2 ^ (~md5_tmp_res3 | md5_tmp_res1)

  if(NO_PE % 32 == 0) {
    val res1 = md5_tmp_res3 + "h67452301".U
    val res2 = B_out_1 + "hefcdab89".U
    val res3 = md5_tmp_res1 + "h98badcfe".U
    val res4 = md5_tmp_res2 + "h10325476".U

    io.outputs(0) := Cat(res1(7, 0), res1(15, 8), res1(23, 16), res1(31, 24))
    io.outputs(1) := Cat(res2(7, 0), res2(15, 8), res2(23, 16), res2(31, 24))
    io.outputs(2) := Cat(res3(7, 0), res3(15, 8), res3(23, 16), res3(31, 24))
    io.outputs(3) := Cat(res4(7, 0), res4(15, 8), res4(23, 16), res4(31, 24))
  } else {
    io.outputs(0) := md5_tmp_res3
    io.outputs(1) := B_out_1
    io.outputs(2) := md5_tmp_res1
    io.outputs(3) := md5_tmp_res2
  }

}
