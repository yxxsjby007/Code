package dsa.element.ALU

import chisel3._
import chisel3.util._

class sha384_64_alu(elename: String, width: Int, pe_n: Int,
                    k0: Int, k1: Int, k2: Int, k3: Int, k4: Int, k5: Int, k6: Int, k7: Int, k8: Int, k9: Int,
                    k10: Int, k11: Int, k12: Int, k13: Int, k14: Int, k15: Int, k16: Int, k17: Int, k18: Int, k19: Int,
                    k20: Int, k21: Int, k22: Int, k23: Int, k24: Int, k25: Int, k26: Int, k27: Int, k28: Int, k29: Int,
                    k30: Int, k31: Int, k32: Int, k33: Int, k34: Int, k35: Int, k36: Int, k37: Int, k38: Int, k39: Int,
                    k40: Int, k41: Int, k42: Int, k43: Int, k44: Int, k45: Int, k46: Int, k47: Int, k48: Int, k49: Int,
                    k50: Int, k51: Int, k52: Int, k53: Int, k54: Int, k55: Int, k56: Int, k57: Int, k58: Int, k59: Int,
                    k60: Int, k61: Int, k62: Int, k63: Int, k64: Int, k65: Int, k66: Int, k67: Int, k68: Int, k69: Int,
                    k70: Int, k71: Int, k72: Int, k73: Int, k74: Int, k75: Int, k76: Int, k77: Int, k78: Int, k79: Int) extends Module{
  override val desiredName = elename
  val io = IO(new Bundle {
    val cfg = Input(UInt(3.W)) //通过cfg判断为循环的起始位置
    val inputs = Input(Vec(10, UInt(width.W))) //数据分为高低位输入a,b,c,d,e,f,g,h,cycle,w 9*2+1 = 19
    val outputs = Output(Vec(9, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(19, UInt(width.W)))

  when(io.cfg === 1.U) {
    inputsWire(0) := "hCBBB9D5DC1059ED8".U
    inputsWire(1) := "h629A292A367CD507".U
    inputsWire(2) := "h9159015A3070DD17".U
    inputsWire(3) := "h152FECD8F70E5939".U
    inputsWire(4) := "h67332667FFC00B31".U
    inputsWire(5) := "h8EB44A8768581511".U
    inputsWire(6) := "hDB0C2E0D64F98FA7".U
    inputsWire(7) := "h47B5481DBEFA4FA4".U
    inputsWire(8) := 0.U
    inputsWire(9) := RegEnable(io.inputs(9), 0.U, true.asBool())
  }.otherwise {
    for (i <- 0 until 10) {
      inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
    }
  }
  val pe_num = pe_n.U
  val kt = Wire(UInt(64.W))
  val k_ori = Seq(
  "h428A2F98D728AE22".U, "h7137449123EF65CD".U, "hB5C0FBCFEC4D3B2F".U, "hE9B5DBA58189DBBC".U,
  "h3956C25BF348B538".U, "h59F111F1B605D019".U, "h923F82A4AF194F9B".U, "hAB1C5ED5DA6D8118".U,
  "hD807AA98A3030242".U, "h12835B0145706FBE".U, "h243185BE4EE4B28C".U, "h550C7DC3D5FFB4E2".U,
  "h72BE5D74F27B896F".U, "h80DEB1FE3B1696B1".U, "h9BDC06A725C71235".U, "hC19BF174CF692694".U,
  "hE49B69C19EF14AD2".U, "hEFBE4786384F25E3".U, "h0FC19DC68B8CD5B5".U, "h240CA1CC77AC9C65".U,
  "h2DE92C6F592B0275".U, "h4A7484AA6EA6E483".U, "h5CB0A9DCBD41FBD4".U, "h76F988DA831153B5".U,
  "h983E5152EE66DFAB".U, "hA831C66D2DB43210".U, "hB00327C898FB213F".U, "hBF597FC7BEEF0EE4".U,
  "hC6E00BF33DA88FC2".U, "hD5A79147930AA725".U, "h06CA6351E003826F".U, "h142929670A0E6E70".U,
  "h27B70A8546D22FFC".U, "h2E1B21385C26C926".U, "h4D2C6DFC5AC42AED".U, "h53380D139D95B3DF".U,
  "h650A73548BAF63DE".U, "h766A0ABB3C77B2A8".U, "h81C2C92E47EDAEE6".U, "h92722C851482353B".U,
  "hA2BFE8A14CF10364".U, "hA81A664BBC423001".U, "hC24B8B70D0F89791".U, "hC76C51A30654BE30".U,
  "hD192E819D6EF5218".U, "hD69906245565A910".U, "hF40E35855771202A".U, "h106AA07032BBD1B8".U,
  "h19A4C116B8D2D0C8".U, "h1E376C085141AB53".U, "h2748774CDF8EEB99".U, "h34B0BCB5E19B48A8".U,
  "h391C0CB3C5C95A63".U, "h4ED8AA4AE3418ACB".U, "h5B9CCA4F7763E373".U, "h682E6FF3D6B2B8A3".U,
  "h748F82EE5DEFB2FC".U, "h78A5636F43172F60".U, "h84C87814A1F0AB72".U, "h8CC702081A6439EC".U,
  "h90BEFFFA23631E28".U, "hA4506CEBDE82BDE9".U, "hBEF9A3F7B2C67915".U, "hC67178F2E372532B".U,
  "hCA273ECEEA26619C".U, "hD186B8C721C0C207".U, "hEADA7DD6CDE0EB1E".U, "hF57D4F7FEE6ED178".U,
  "h06F067AA72176FBA".U, "h0A637DC5A2C898A6".U, "h113F9804BEF90DAE".U, "h1B710B35131C471B".U,
  "h28DB77F523047D84".U, "h32CAAB7B40C72493".U, "h3C9EBE0A15C9BEBC".U, "h431D67C49C100D4C".U,
  "h4CC5D4BECB3E42B6".U, "h597F299CFC657E2A".U, "h5FCB6FAB3AD6FAEC".U, "h6C44198C4A475817".U)
  val k = Seq(k_ori(k0), k_ori(k1), k_ori(k2), k_ori(k3), k_ori(k4), k_ori(k5), k_ori(k6), k_ori(k7), k_ori(k8), k_ori(k9),
    k_ori(k10), k_ori(k11), k_ori(k12), k_ori(k13), k_ori(k14), k_ori(k15), k_ori(k16), k_ori(k17), k_ori(k18), k_ori(k19),
    k_ori(k20), k_ori(k21), k_ori(k22), k_ori(k23), k_ori(k24), k_ori(k25), k_ori(k26), k_ori(k27), k_ori(k28), k_ori(k29),
    k_ori(k30), k_ori(k31), k_ori(k32), k_ori(k33), k_ori(k34), k_ori(k35), k_ori(k36), k_ori(k37), k_ori(k38), k_ori(k39),
    k_ori(k40), k_ori(k41), k_ori(k42), k_ori(k43), k_ori(k44), k_ori(k45), k_ori(k46), k_ori(k47), k_ori(k48), k_ori(k49),
    k_ori(k50), k_ori(k51), k_ori(k52), k_ori(k53), k_ori(k54), k_ori(k55), k_ori(k56), k_ori(k57), k_ori(k58), k_ori(k59),
    k_ori(k60), k_ori(k61), k_ori(k62), k_ori(k63), k_ori(k64), k_ori(k65), k_ori(k66), k_ori(k67), k_ori(k68), k_ori(k69),
    k_ori(k70), k_ori(k71), k_ori(k72), k_ori(k73), k_ori(k74), k_ori(k75), k_ori(k76), k_ori(k77), k_ori(k78), k_ori(k79))
  //根据pe的数选择k
  when(pe_num === 80.U) { //一选一
    kt := k(0)
  } .elsewhen(pe_num === 40.U) {
    kt := Mux(inputsWire(8) < 40.U, k(0), k(1))
  } .elsewhen(pe_num === 20.U) {
    kt := MuxCase(0.U, Array(
      (inputsWire(8) <= 19.U) -> k(0),
      (20.U < inputsWire(8) & inputsWire(8) <= 39.U) -> k(1),
      (40.U < inputsWire(8) & inputsWire(8) <= 59.U) -> k(2),
      (60.U < inputsWire(8) & inputsWire(8) <= 79.U) -> k(3)))
  } .elsewhen(pe_num === 16.U) {
    kt := MuxCase(0.U, Array(
      (inputsWire(8)(6,4) === 0.U) -> k(0),
      (inputsWire(8)(6,4) === 1.U) -> k(1),
      (inputsWire(8)(6,4) === 2.U) -> k(2),
      (inputsWire(8)(6,4) === 3.U) -> k(3),
      (inputsWire(8)(6,4) === 4.U) -> k(4)))
  } .elsewhen(pe_num === 4.U) {
    kt := MuxCase(0.U, Array(
      (inputsWire(8)(6,2) === 0.U) -> k(0),
      (inputsWire(8)(6,2) === 1.U) -> k(1),
      (inputsWire(8)(6,2) === 2.U) -> k(2),
      (inputsWire(8)(6,2) === 3.U) -> k(3),
      (inputsWire(8)(6,2) === 4.U) -> k(4),
      (inputsWire(8)(6,2) === 5.U) -> k(5),
      (inputsWire(8)(6,2) === 6.U) -> k(6),
      (inputsWire(8)(6,2) === 7.U) -> k(7),
      (inputsWire(8)(6,2) === 8.U) -> k(8),
      (inputsWire(8)(6,2) === 9.U) -> k(9),
      (inputsWire(8)(6,2) === 10.U) -> k(10),
      (inputsWire(8)(6,2) === 11.U) -> k(11),
      (inputsWire(8)(6,2) === 12.U) -> k(12),
      (inputsWire(8)(6,2) === 13.U) -> k(13),
      (inputsWire(8)(6,2) === 14.U) -> k(14),
      (inputsWire(8)(6,2) === 15.U) -> k(15),
      (inputsWire(8)(6,2) === 16.U) -> k(16),
      (inputsWire(8)(6,2) === 17.U) -> k(17),
      (inputsWire(8)(6,2) === 18.U) -> k(18),
      (inputsWire(8)(6,2) === 19.U) -> k(19)))
  }. otherwise {
    kt := k(0)
}

  val a = inputsWire(0)
  val b = inputsWire(1)
  val c = inputsWire(2)
  val d = inputsWire(3)
  val e = inputsWire(4)
  val f = inputsWire(5)
  val g = inputsWire(6)
  val h = inputsWire(7)

  val S1 = Cat(e(13, 0), e(63, 14)) ^ Cat(e(17, 0), e(63, 18)) ^ Cat(e(40, 0), e(63, 41))
  val ch = (e & f) ^ (~e & g)
  val tmp1 = h + S1 + ch + kt + Cat(inputsWire(17), inputsWire(18))
  val S0 = Cat(a(27, 0), a(63, 28)) ^ Cat(a(33, 0), a(63, 34)) ^ Cat(a(38, 0), a(63, 39))
  val maj = (a & b) ^ (a & c) ^ (b & c)
  val tmp2 = S0 + maj
  when(inputsWire(4)(7, 0) === 79.U) {
    io.outputs(0) := tmp1 + tmp2 + "hCBBB9D5DC1059ED8".U      //a

    io.outputs(1) := a + "h629A292A367CD507".U                //b = a

    io.outputs(2) := b + "h9159015A3070DD17".U               //c = b

    io.outputs(3) := c + "h152FECD8F70E5939".U                //d = c

    io.outputs(4) := d + tmp1 + "h67332667FFC00B31".U            //e = d + tmp1

    io.outputs(5) := e + "h8EB44A8768581511".U                //f = e

    io.outputs(6) := f + "hDB0C2E0D64F98FA7".U             //g = f

    io.outputs(7) := g + "h47B5481DBEFA4FA4".U             //h = g

    inputsWire(8) := inputsWire(8) + 1.U
  } .otherwise{
    io.outputs(0) := tmp1 + tmp2       //a

    io.outputs(1) := a               //b = a

    io.outputs(2) := b              //c = b

    io.outputs(3) := c               //d = c

    io.outputs(4) := d + tmp1            //e = d + tmp1

    io.outputs(5) := e             //f = e

    io.outputs(6) := f             //g = f

    io.outputs(7) := g            //h = g

    inputsWire(8) := inputsWire(8) + 1.U


  }

}
