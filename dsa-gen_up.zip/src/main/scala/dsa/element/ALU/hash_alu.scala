package dsa.element.ALU

import chisel3._
import chisel3.util._
import dsa.element.ALU.OpInfo.getALUinNum
import dsa.element.ALU.OpInfo.getALUoutNum
import dsa.element.ALU.alu_Info.{md5_penumMap, sha1_penumMap, sha256_penumMap, sha224_penumMap, sha384_32_penumMap}

class hash_alu(elename: String, op_type: Int, width: Int, pe_num: Int, NO_PE: Int) extends Module {
  override val desiredName = elename
  val alu_type = OpInfo.fuget(op_type)
  println("alu_type : " + alu_type)
  val innum_max = alu_type.map(getALUinNum(_)).max
  println("innum_max : " + innum_max)
  val outnum_max = alu_type.map(getALUoutNum(_)).max
  println("outnum_max : " + outnum_max)
  val io = IO(new Bundle {
    val cfg = Input(UInt(5.W)) //LM: 通过cfg选择运算的类型，从0开始，对应OPC = Value的值
    val inputs = Input(Vec(innum_max, UInt(width.W)))     //a,b,c,d,cycle,text
    val outputs = Output(Vec(outnum_max, UInt(width.W))) //LM: 输出端口应该改成Vec(输出数，)
  })

  val outbuffer = Wire(Vec(outnum_max, UInt(width.W)))
  val tmpbuffer = Wire(Vec(outnum_max, UInt(width.W)))
  tmpbuffer.foreach(_ := 0.U)

  val out_tmp = Seq.empty[(UInt, Vec[Vec[UInt]])] ++ alu_type.map { alu =>
    alu.id.U -> (alu match {
      case OPC.md5 => {
        val out_buffer0 = Wire(Vec(outnum_max, UInt(width.W)))
        when(io.cfg(4, 1) === "b0000".U) {
          println("alu_type" + alu)
          val inputsWire = Wire(Vec(innum_max, UInt(width.W)))
          when(NO_PE.U % 64.U === 1.U && io.cfg(0) === 1.U) { //只有在第一个PE中添加这个判断
            inputsWire(0) := "h67452301".U
            inputsWire(1) := "hefcdab89".U
            inputsWire(2) := "h98badcfe".U
            inputsWire(3) := "h10325476".U
            inputsWire(4) := 0.U
            inputsWire(5) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for (i <- 6 until innum_max) {
              inputsWire(i) := 0.U
            }
          }.otherwise {
            for (i <- 0 until 5) {
              inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
            }
            inputsWire(5) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for (i <- 6 until innum_max) {
              inputsWire(i) := 0.U
            }
          }
          val si_ori = Seq(7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U,
            5.U, 9.U, 14.U, 20.U, 5.U, 9.U, 14.U, 20.U, 5.U, 9.U, 14.U, 20.U, 5.U, 9.U, 14.U, 20.U,
            4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U,
            6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U)
          //构建si的选择序列
          val si = VecInit(Seq.fill(md5_penumMap(pe_num)(0))(0.U(5.W)))
          //如果是64个pe，直接
          if(pe_num > 64) {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori((NO_PE - 1) % 64)
            }
          }
          else if (pe_num == 64) {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori(NO_PE - 1)
            }
          } else if (pe_num == 32) {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori((i * pe_num) + NO_PE - 1)
            }
          } else if (pe_num == 16) {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori((i * 16) + NO_PE - 1)
            }
          } else if (pe_num == 8) {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori((i * 16) + NO_PE - 1)
            }
          } else if (pe_num == 4) {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori((i * 16) + NO_PE - 1)
            }
          } else if (pe_num == 2) {
            if (NO_PE == 1) {
              si := Seq(7.U, 17.U, 5.U, 14.U, 4.U, 16.U, 6.U, 15.U)
            }
            else {
              si := Seq(12.U, 22.U, 9.U, 20.U, 11.U, 23.U, 10.U, 21.U)
            }
          }
          else if (pe_num == 1) {
            si := Seq(7.U, 12.U, 17.U, 22.U, 5.U, 9.U, 14.U, 20.U, 4.U, 11.U, 16.U, 23.U, 6.U, 10.U, 15.U, 21.U)
          } else {
            for (i <- 0 until md5_penumMap(pe_num)(0)) {
              si(i) := si_ori(NO_PE - 1)
            }
          }

          val Ti_ori = Seq(
            "hd76aa478".U, "he8c7b756".U, "h242070db".U, "hc1bdceee".U, "hf57c0faf".U, "h4787c62a".U, "ha8304613".U, "hfd469501".U,
            "h698098d8".U, "h8b44f7af".U, "hffff5bb1".U, "h895cd7be".U, "h6b901122".U, "hfd987193".U, "ha679438e".U, "h49b40821".U,
            "hf61e2562".U, "hc040b340".U, "h265e5a51".U, "he9b6c7aa".U, "hd62f105d".U, "h02441453".U, "hd8a1e681".U, "he7d3fbc8".U,
            "h21e1cde6".U, "hc33707d6".U, "hf4d50d87".U, "h455a14ed".U, "ha9e3e905".U, "hfcefa3f8".U, "h676f02d9".U, "h8d2a4c8a".U,
            "hfffa3942".U, "h8771f681".U, "h6d9d6122".U, "hfde5380c".U, "ha4beea44".U, "h4bdecfa9".U, "hf6bb4b60".U, "hbebfbc70".U,
            "h289b7ec6".U, "heaa127fa".U, "hd4ef3085".U, "h04881d05".U, "hd9d4d039".U, "he6db99e5".U, "h1fa27cf8".U, "hc4ac5665".U,
            "hf4292244".U, "h432aff97".U, "hab9423a7".U, "hfc93a039".U, "h655b59c3".U, "h8f0ccc92".U, "hffeff47d".U, "h85845dd1".U,
            "h6fa87e4f".U, "hfe2ce6e0".U, "ha3014314".U, "h4e0811a1".U, "hf7537e82".U, "hbd3af235".U, "h2ad7d2bb".U, "heb86d391".U)

          //构建Ti的选择序列
          val Ti = VecInit(Seq.fill(md5_penumMap(pe_num)(1))(0.U(32.W)))
          for (i <- 0 until md5_penumMap(pe_num)(1)) {
            if(pe_num > 64) {
              Ti(i) := Ti_ori((NO_PE - 1) % 64)
            }
            else {
              Ti(i) := Ti_ori((i * pe_num) + NO_PE - 1)
            }

          }
          val T = Wire(UInt(32.W))

          //根据pe和cycle的数选择Ti
          if(pe_num > 64) {
            T := Ti(0)
          }
          else if (pe_num == 64) { //一选一
            T := Ti(0)
          } else if (pe_num == 32) { //二选一
            T := Mux(inputsWire(4)(5), Ti(1), Ti(0))
          } else if (pe_num == 16) { //四选一
            T := MuxCase(0.U, Array(
              (inputsWire(4)(5, 4) === 0.U) -> Ti(0),
              (inputsWire(4)(5, 4) === 1.U) -> Ti(1),
              (inputsWire(4)(5, 4) === 2.U) -> Ti(2),
              (inputsWire(4)(5, 4) === 3.U) -> Ti(3)
            ))
          } else if (pe_num == 8.U) { //八选一
            T := MuxCase(0.U, Array(
              (inputsWire(4)(5, 3) === 0.U) -> Ti(0),
              (inputsWire(4)(5, 3) === 1.U) -> Ti(1),
              (inputsWire(4)(5, 3) === 2.U) -> Ti(2),
              (inputsWire(4)(5, 3) === 3.U) -> Ti(3),
              (inputsWire(4)(5, 3) === 4.U) -> Ti(4),
              (inputsWire(4)(5, 3) === 5.U) -> Ti(5),
              (inputsWire(4)(5, 3) === 6.U) -> Ti(6),
              (inputsWire(4)(5, 3) === 7.U) -> Ti(7)
            ))
          } else if (pe_num == 4) { //十六选一
            T := MuxCase(0.U, Array(
              (inputsWire(4)(5, 2) === 0.U) -> Ti(0),
              (inputsWire(4)(5, 2) === 1.U) -> Ti(1),
              (inputsWire(4)(5, 2) === 2.U) -> Ti(2),
              (inputsWire(4)(5, 2) === 3.U) -> Ti(3),
              (inputsWire(4)(5, 2) === 4.U) -> Ti(4),
              (inputsWire(4)(5, 2) === 5.U) -> Ti(5),
              (inputsWire(4)(5, 2) === 6.U) -> Ti(6),
              (inputsWire(4)(5, 2) === 7.U) -> Ti(7),
              (inputsWire(4)(5, 2) === 8.U) -> Ti(8),
              (inputsWire(4)(5, 2) === 9.U) -> Ti(9),
              (inputsWire(4)(5, 2) === 10.U) -> Ti(10),
              (inputsWire(4)(5, 2) === 11.U) -> Ti(11),
              (inputsWire(4)(5, 2) === 12.U) -> Ti(12),
              (inputsWire(4)(5, 2) === 13.U) -> Ti(13),
              (inputsWire(4)(5, 2) === 14.U) -> Ti(14),
              (inputsWire(4)(5, 2) === 15.U) -> Ti(15)
            ))
          } else if (pe_num == 2) { //三十二选一
            T := MuxCase(0.U, Array(
              (inputsWire(4)(5, 1) === 0.U) -> Ti(0),
              (inputsWire(4)(5, 1) === 1.U) -> Ti(1),
              (inputsWire(4)(5, 1) === 2.U) -> Ti(2),
              (inputsWire(4)(5, 1) === 3.U) -> Ti(3),
              (inputsWire(4)(5, 1) === 4.U) -> Ti(4),
              (inputsWire(4)(5, 1) === 5.U) -> Ti(5),
              (inputsWire(4)(5, 1) === 6.U) -> Ti(6),
              (inputsWire(4)(5, 1) === 7.U) -> Ti(7),
              (inputsWire(4)(5, 1) === 8.U) -> Ti(8),
              (inputsWire(4)(5, 1) === 9.U) -> Ti(9),
              (inputsWire(4)(5, 1) === 10.U) -> Ti(10),
              (inputsWire(4)(5, 1) === 11.U) -> Ti(11),
              (inputsWire(4)(5, 1) === 12.U) -> Ti(12),
              (inputsWire(4)(5, 1) === 13.U) -> Ti(13),
              (inputsWire(4)(5, 1) === 14.U) -> Ti(14),
              (inputsWire(4)(5, 1) === 15.U) -> Ti(15),
              (inputsWire(4)(5, 1) === 16.U) -> Ti(16),
              (inputsWire(4)(5, 1) === 17.U) -> Ti(17),
              (inputsWire(4)(5, 1) === 18.U) -> Ti(18),
              (inputsWire(4)(5, 1) === 19.U) -> Ti(19),
              (inputsWire(4)(5, 1) === 20.U) -> Ti(20),
              (inputsWire(4)(5, 1) === 21.U) -> Ti(21),
              (inputsWire(4)(5, 1) === 22.U) -> Ti(22),
              (inputsWire(4)(5, 1) === 23.U) -> Ti(23),
              (inputsWire(4)(5, 1) === 24.U) -> Ti(24),
              (inputsWire(4)(5, 1) === 25.U) -> Ti(25),
              (inputsWire(4)(5, 1) === 26.U) -> Ti(26),
              (inputsWire(4)(5, 1) === 27.U) -> Ti(27),
              (inputsWire(4)(5, 1) === 28.U) -> Ti(28),
              (inputsWire(4)(5, 1) === 29.U) -> Ti(29),
              (inputsWire(4)(5, 1) === 30.U) -> Ti(30),
              (inputsWire(4)(5, 1) === 31.U) -> Ti(31)
            ))
          } else if (pe_num == 1) { //六十四选一
            T := MuxCase(0.U, Array(
              (inputsWire(4)(5, 0) === 0.U) -> Ti(0),
              (inputsWire(4)(5, 0) === 1.U) -> Ti(1),
              (inputsWire(4)(5, 0) === 2.U) -> Ti(2),
              (inputsWire(4)(5, 0) === 3.U) -> Ti(3),
              (inputsWire(4)(5, 0) === 4.U) -> Ti(4),
              (inputsWire(4)(5, 0) === 5.U) -> Ti(5),
              (inputsWire(4)(5, 0) === 6.U) -> Ti(6),
              (inputsWire(4)(5, 0) === 7.U) -> Ti(7),
              (inputsWire(4)(5, 0) === 8.U) -> Ti(8),
              (inputsWire(4)(5, 0) === 9.U) -> Ti(9),
              (inputsWire(4)(5, 0) === 10.U) -> Ti(10),
              (inputsWire(4)(5, 0) === 11.U) -> Ti(11),
              (inputsWire(4)(5, 0) === 12.U) -> Ti(12),
              (inputsWire(4)(5, 0) === 13.U) -> Ti(13),
              (inputsWire(4)(5, 0) === 14.U) -> Ti(14),
              (inputsWire(4)(5, 0) === 15.U) -> Ti(15),
              (inputsWire(4)(5, 0) === 16.U) -> Ti(16),
              (inputsWire(4)(5, 0) === 17.U) -> Ti(17),
              (inputsWire(4)(5, 0) === 18.U) -> Ti(18),
              (inputsWire(4)(5, 0) === 19.U) -> Ti(19),
              (inputsWire(4)(5, 0) === 20.U) -> Ti(20),
              (inputsWire(4)(5, 0) === 21.U) -> Ti(21),
              (inputsWire(4)(5, 0) === 22.U) -> Ti(22),
              (inputsWire(4)(5, 0) === 23.U) -> Ti(23),
              (inputsWire(4)(5, 0) === 24.U) -> Ti(24),
              (inputsWire(4)(5, 0) === 25.U) -> Ti(25),
              (inputsWire(4)(5, 0) === 26.U) -> Ti(26),
              (inputsWire(4)(5, 0) === 27.U) -> Ti(27),
              (inputsWire(4)(5, 0) === 28.U) -> Ti(28),
              (inputsWire(4)(5, 0) === 29.U) -> Ti(29),
              (inputsWire(4)(5, 0) === 30.U) -> Ti(30),
              (inputsWire(4)(5, 0) === 31.U) -> Ti(31),
              (inputsWire(4)(5, 0) === 32.U) -> Ti(32),
              (inputsWire(4)(5, 0) === 33.U) -> Ti(33),
              (inputsWire(4)(5, 0) === 34.U) -> Ti(34),
              (inputsWire(4)(5, 0) === 35.U) -> Ti(35),
              (inputsWire(4)(5, 0) === 36.U) -> Ti(36),
              (inputsWire(4)(5, 0) === 37.U) -> Ti(37),
              (inputsWire(4)(5, 0) === 38.U) -> Ti(38),
              (inputsWire(4)(5, 0) === 39.U) -> Ti(39),
              (inputsWire(4)(5, 0) === 40.U) -> Ti(40),
              (inputsWire(4)(5, 0) === 41.U) -> Ti(41),
              (inputsWire(4)(5, 0) === 42.U) -> Ti(42),
              (inputsWire(4)(5, 0) === 43.U) -> Ti(43),
              (inputsWire(4)(5, 0) === 44.U) -> Ti(44),
              (inputsWire(4)(5, 0) === 45.U) -> Ti(45),
              (inputsWire(4)(5, 0) === 46.U) -> Ti(46),
              (inputsWire(4)(5, 0) === 47.U) -> Ti(47),
              (inputsWire(4)(5, 0) === 48.U) -> Ti(48),
              (inputsWire(4)(5, 0) === 49.U) -> Ti(49),
              (inputsWire(4)(5, 0) === 50.U) -> Ti(50),
              (inputsWire(4)(5, 0) === 51.U) -> Ti(51),
              (inputsWire(4)(5, 0) === 52.U) -> Ti(52),
              (inputsWire(4)(5, 0) === 53.U) -> Ti(53),
              (inputsWire(4)(5, 0) === 54.U) -> Ti(54),
              (inputsWire(4)(5, 0) === 55.U) -> Ti(55),
              (inputsWire(4)(5, 0) === 56.U) -> Ti(56),
              (inputsWire(4)(5, 0) === 57.U) -> Ti(57),
              (inputsWire(4)(5, 0) === 58.U) -> Ti(58),
              (inputsWire(4)(5, 0) === 59.U) -> Ti(59),
              (inputsWire(4)(5, 0) === 60.U) -> Ti(60),
              (inputsWire(4)(5, 0) === 61.U) -> Ti(61),
              (inputsWire(4)(5, 0) === 62.U) -> Ti(62),
              (inputsWire(4)(5, 0) === 63.U) -> Ti(63)
            ))
          } else {
            T := Ti(0)
          }

          val s = Wire(UInt(5.W))
          //根据pe数选择s
          if(pe_num > 64) {
            s := si(0)
          }
          else if (pe_num == 64) { //一选一
            s := si(0)
          } else if (pe_num == 32) { //二选一
            s := Mux(inputsWire(4)(5), si(1), si(0))
          } else if (pe_num == 16) { //四选一
            s := MuxCase(0.U, Array(
              (inputsWire(4)(5, 4) === 0.U) -> si(0),
              (inputsWire(4)(5, 4) === 1.U) -> si(1),
              (inputsWire(4)(5, 4) === 2.U) -> si(2),
              (inputsWire(4)(5, 4) === 3.U) -> si(3)
            ))
          } else if (pe_num == 8) { //四选一，每个重复两次（八选一）
            s := MuxCase(0.U, Array(
              (inputsWire(4)(5, 4) === 0.U) -> si(0),
              (inputsWire(4)(5, 4) === 1.U) -> si(1),
              (inputsWire(4)(5, 4) === 2.U) -> si(2),
              (inputsWire(4)(5, 4) === 3.U) -> si(3)
            ))
          } else if (pe_num == 4) { //四选一，每个重复四次（十六选一）
            s := MuxCase(0.U, Array(
              (inputsWire(4)(5, 4) === 0.U) -> si(0),
              (inputsWire(4)(5, 4) === 1.U) -> si(1),
              (inputsWire(4)(5, 4) === 2.U) -> si(2),
              (inputsWire(4)(5, 4) === 3.U) -> si(3)
            ))
          } else if (pe_num == 2) { //八选一，每个重复四次（三十二选一）
            s := MuxCase(0.U, Array(
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 0.U) -> si(0),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 1.U) -> si(1),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 2.U) -> si(2),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 3.U) -> si(3),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 4.U) -> si(4),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 5.U) -> si(5),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 6.U) -> si(6),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1)) === 7.U) -> si(7),
            ))
          } else if (pe_num == 1) { //十六选一，每个重复四次（六十四选一）
            s := MuxCase(0.U, Array(
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 0.U) -> si(0),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 1.U) -> si(1),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 2.U) -> si(2),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 3.U) -> si(3),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 4.U) -> si(4),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 5.U) -> si(5),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 6.U) -> si(6),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 7.U) -> si(7),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 8.U) -> si(8),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 9.U) -> si(9),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 10.U) -> si(10),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 11.U) -> si(11),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 12.U) -> si(12),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 13.U) -> si(13),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 14.U) -> si(14),
              (Cat(inputsWire(4)(5, 4), inputsWire(4)(1, 0)) === 15.U) -> si(15)
            ))
          } else {
            s := si(0)
          }

          val md5func_res0 = Wire(UInt(width.W))
          val md5func_res1 = Wire(UInt(width.W))
          val md5func_res2 = Wire(UInt(width.W))
          val md5func_res3 = Wire(UInt(width.W))
          val md5fun_res = Wire(UInt(width.W))
          val tmp_B = Wire(UInt(width.W))
          val tmp_B_shift = Wire(UInt(width.W))
          val B_out = Wire(UInt(width.W))

          val func_sel0 = Wire(UInt(2.W))
          val func_sel1 = Wire(UInt(2.W))
          if(pe_num > 64) {
            func_sel0 := ((NO_PE - 1) % 64).U / 16.U
            func_sel1 := 0.U
          }
          else if(pe_num == 64){
            func_sel0 := (NO_PE - 1).U / 16.U
            func_sel1 := 0.U
          } else if (pe_num == 32) {
            if (NO_PE < 17) {
              func_sel0 := 0.U
              func_sel1 := 2.U
            } else {
              func_sel0 := 1.U
              func_sel1 := 3.U
            }
          } else {
            func_sel0 := 0.U
            func_sel1 := 0.U
          }

          //根据PE数选择压缩函数
          if (pe_num >= 64) { //一选一
            md5fun_res := MuxLookup(func_sel0, 0.U, Array(0.U -> md5func_res0, 1.U -> md5func_res1, 2.U -> md5func_res2, 3.U -> md5func_res3))
          } else if (pe_num == 32) { //二选一，先确定PE内的func
            val md5_r1 = MuxLookup(func_sel0, 0.U, Array(0.U -> md5func_res0, 1.U -> md5func_res1))
            val md5_r2 = MuxLookup(func_sel1, 0.U, Array(2.U -> md5func_res2, 3.U -> md5func_res3))
            md5fun_res := Mux(inputsWire(4)(5), md5_r2, md5_r1)
          } else if (pe_num == 16 | pe_num == 8 | pe_num == 4 | pe_num == 2 | pe_num == 1) { //四选一，PE内四个func
            md5fun_res := MuxCase(0.U, Array(
              (Cat(inputsWire(4)(5, 4)) === 0.U) -> md5func_res0,
              (Cat(inputsWire(4)(5, 4)) === 1.U) -> md5func_res1,
              (Cat(inputsWire(4)(5, 4)) === 2.U) -> md5func_res2,
              (Cat(inputsWire(4)(5, 4)) === 3.U) -> md5func_res3
            ))
          } else {
            md5fun_res := MuxLookup(func_sel0, 0.U, Array(0.U -> md5func_res0, 1.U -> md5func_res1, 2.U -> md5func_res2, 3.U -> md5func_res3))
          }

          //(b&c) | (~b&d)
          md5func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
          //(b&d) | (c&~d)
          md5func_res1 := (inputsWire(1) & inputsWire(3)) | ((~inputsWire(3)) & (inputsWire(2)))
          //b^c^d
          md5func_res2 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
          //c^(b|~d)
          md5func_res3 := inputsWire(2) ^ (~inputsWire(3) | inputsWire(1))
          tmp_B := md5fun_res + inputsWire(0) + T + inputsWire(5)
          tmp_B_shift := (tmp_B << s) | (tmp_B >> (32.U - s))
          B_out := tmp_B_shift + inputsWire(1)
          if (NO_PE == pe_num || (NO_PE % 64) == 0) {
            when(inputsWire(4)(5, 0) === 63.U) {
              out_buffer0(0) := inputsWire(3) + "h67452301".U
              out_buffer0(1) := B_out + "hefcdab89".U
              out_buffer0(2) := inputsWire(1) + "h98badcfe".U
              out_buffer0(3) := inputsWire(2) + "h10325476".U
              out_buffer0(4) := inputsWire(4) + 1.U
            }.otherwise {
              out_buffer0(0) := inputsWire(3)
              out_buffer0(1) := B_out
              out_buffer0(2) := inputsWire(1)
              out_buffer0(3) := inputsWire(2)
              out_buffer0(4) := inputsWire(4) + 1.U
            }
          } else {
            out_buffer0(0) := inputsWire(3)
            out_buffer0(1) := B_out
            out_buffer0(2) := inputsWire(1)
            out_buffer0(3) := inputsWire(2)
            out_buffer0(4) := inputsWire(4) + 1.U
          }
          for (i <- 5 until outnum_max) {
            out_buffer0(i) := 0.U
          }

        }.otherwise {
          for (i <- 0 until outnum_max) {
            out_buffer0(i) := 0.U
          }
        }
        out_buffer0
      }
      case OPC.sha1 => {
        val out_buffer1 = Wire(Vec(outnum_max, UInt(width.W)))
        when(io.cfg(4, 1) === "b0001".U) {
          val inputsWire = Wire(Vec(innum_max, UInt(width.W)))
          when(NO_PE.U === 1.U && io.cfg(0) === 1.U) {
            inputsWire(0) := "h67452301".U
            inputsWire(1) := "hEFCDAB89".U
            inputsWire(2) := "h98badcfe".U
            inputsWire(3) := "h10325476".U
            inputsWire(4) := "hC3D2E1F0".U
            inputsWire(5) := 0.U
            inputsWire(6) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for (i <- 7 until innum_max) {
              inputsWire(i) := 0.U
            }
          }.otherwise {
            for (i <- 0 until 6) {
              inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
            }
            inputsWire(6) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for (i <- 7 until innum_max) {
              inputsWire(i) := 0.U
            }
          }

          val kt = Wire(UInt(32.W))
          val k_ori = Seq("h5A827999".U, "h6ED9EBA1".U, "h8F1BBCDC".U, "hCA62C1D6".U)
          val k = VecInit(Seq.fill(sha1_penumMap(pe_num)(0))(0.U(32.W)))
          if(pe_num > 80){
            for (i <- 0 until sha1_penumMap(pe_num)(0)) {
              k(i) := k_ori((NO_PE % 80) / 20)
            }
          }
          if (pe_num == 80) {
            for (i <- 0 until sha1_penumMap(pe_num)(0)) {
              k(i) := k_ori((NO_PE - 1) / 20)
            }
          } else if (pe_num == 40) {
            if (NO_PE < 21) {
              k := Seq(k_ori(0), k_ori(2))
            } else {
              k := Seq(k_ori(1), k_ori(3))
            }
          } else {
            k := k_ori
          }
          //根据PE_numum选择kt
          if (pe_num == 80) {
            kt := k(0)
          } else if (pe_num == 40) { // 二选一
            kt := Mux(inputsWire(5) < 40.U, k(0), k(1))
          } else { //四选一
            kt := MuxCase(0.U, Array(
              (inputsWire(5) < 20.U) -> k(0),
              (20.U <= inputsWire(5) && inputsWire(5) < 40.U) -> k(1),
              (40.U <= inputsWire(5) && inputsWire(5) < 60.U) -> k(2),
              (60.U <= inputsWire(5) && inputsWire(5) < 80.U) -> k(3)))
          }

          val sha1func_res = Wire(UInt(width.W))
          val sha1func_res0 = Wire(UInt(width.W))
          val sha1func_res1 = Wire(UInt(width.W))
          val sha1func_res2 = Wire(UInt(width.W))

          val func_sel0 = Wire(UInt(2.W))
          val func_sel1 = Wire(UInt(2.W))

          if (pe_num == 80) {
            func_sel0 := NO_PE.U / 20.U
            func_sel1 := 0.U
          } else if (pe_num == 40) {
            if (NO_PE < 21) {
              func_sel0 := 0.U
              func_sel1 := 2.U
            } else {
              func_sel0 := 1.U
              func_sel1 := 3.U
            }
          } else {
            func_sel0 := 0.U
            func_sel1 := 0.U
          }

          //根据PE数选择压缩函数
          if (pe_num == 80) {
            sha1func_res := MuxLookup(func_sel0, 0.U, Array(0.U -> sha1func_res0, 1.U -> sha1func_res1, 2.U -> sha1func_res2, 3.U -> sha1func_res1))
          } else if (pe_num == 40) {
            val sha1_r1 = MuxLookup(func_sel0, 0.U, Array(0.U -> sha1func_res0, 1.U -> sha1func_res1))
            val sha1_r2 = MuxLookup(func_sel1, 0.U, Array(2.U -> sha1func_res2, 3.U -> sha1func_res1))
            sha1func_res := Mux(inputsWire(5) > 39.U, sha1_r2, sha1_r1)
          } else {
            sha1func_res := MuxCase(0.U, Array(
              (inputsWire(5) <= 19.U) -> sha1func_res0,
              (19.U < inputsWire(5) & inputsWire(5) <= 39.U) -> sha1func_res1,
              (39.U < inputsWire(5) & inputsWire(5) <= 59.U) -> sha1func_res2,
              (59.U < inputsWire(5) & inputsWire(5) <= 79.U) -> sha1func_res1))
          }

          //(b&c) | (~b&d)
          sha1func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
          //b^c^d
          sha1func_res1 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
          //(b&c) | (b&d) | (c&d)
          sha1func_res2 := (inputsWire(1) & inputsWire(2)) | (inputsWire(1) & inputsWire(3)) | (inputsWire(2) & inputsWire(3))

          val shift_a = Wire(UInt(width.W))
          val shift_b = Wire(UInt(width.W))
          val tmp_A = Wire(UInt(width.W))
          shift_a := Cat(inputsWire(0)(26, 0), inputsWire(0)(31, 27))
          shift_b := Cat(inputsWire(1)(1, 0), inputsWire(1)(31, 2))
          tmp_A := shift_a + sha1func_res + inputsWire(4) + kt + inputsWire(6)
          if (NO_PE == pe_num) {
            when(inputsWire(5) === 79.U) {
              out_buffer1(0) := tmp_A + "h67452301".U
              out_buffer1(1) := inputsWire(0) + "hEFCDAB89".U
              out_buffer1(2) := shift_b + "h98badcfe".U
              out_buffer1(3) := inputsWire(2) + "h10325476".U
              out_buffer1(4) := inputsWire(3) + "hC3D2E1F0".U
              out_buffer1(5) := inputsWire(5) + 1.U
            }.otherwise {
              out_buffer1(0) := tmp_A
              out_buffer1(1) := inputsWire(0)
              out_buffer1(2) := shift_b
              out_buffer1(3) := inputsWire(2)
              out_buffer1(4) := inputsWire(3)
              out_buffer1(5) := inputsWire(5) + 1.U
            }
          } else {
            out_buffer1(0) := tmp_A
            out_buffer1(1) := inputsWire(0)
            out_buffer1(2) := shift_b
            out_buffer1(3) := inputsWire(2)
            out_buffer1(4) := inputsWire(3)
            out_buffer1(5) := inputsWire(5) + 1.U
          }
          for (i <- 6 until outnum_max) {
            out_buffer1(i) := 0.U
          }

        }.otherwise {
          for (i <- 0 until outnum_max) {
            out_buffer1(i) := 0.U
          }
        }
        out_buffer1
      }
      case OPC.sha256 => {
        val out_buffer2 = Wire(Vec(outnum_max, UInt(width.W)))
        when(io.cfg(4, 1) === "b0010".U) {
          val inputsWire = Wire(Vec(innum_max, UInt(width.W)))
          when(NO_PE.U === 1.U && io.cfg(0) === 1.U) {
            inputsWire(0) := "h6A09E667".U
            inputsWire(1) := "hBB67AE85".U
            inputsWire(2) := "h3C6EF372".U
            inputsWire(3) := "hA54FF53A".U
            inputsWire(4) := "h510E527F".U
            inputsWire(5) := "h9B05688C".U
            inputsWire(6) := "h1F83D9AB".U
            inputsWire(7) := "h5BE0CD19".U
            inputsWire(8) := 0.U
            inputsWire(9) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for(i <- 10 until innum_max) {
              inputsWire(i) := 0.U
            }
          }.otherwise {
            for (i <- 0 until 9) {
              inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
            }
            inputsWire(9) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for(i <- 10 until innum_max) {
              inputsWire(i) := 0.U
            }
          }

          val kt_ori = Seq(
            "h428A2F98".U, "h71374491".U, "hB5C0FBCF".U, "hE9B5DBA5".U, "h3956C25B".U, "h59F111F1".U, "h923F82A4".U, "hAB1C5ED5".U,
            "hD807AA98".U, "h12835B01".U, "h243185BE".U, "h550C7DC3".U, "h72BE5D74".U, "h80DEB1FE".U, "h9BDC06A7".U, "hC19BF174".U,
            "hE49B69C1".U, "hEFBE4786".U, "h0FC19DC6".U, "h240CA1CC".U, "h2DE92C6F".U, "h4A7484AA".U, "h5CB0A9DC".U, "h76F988DA".U,
            "h983E5152".U, "hA831C66D".U, "hB00327C8".U, "hBF597FC7".U, "hC6E00BF3".U, "hD5A79147".U, "h06CA6351".U, "h14292967".U,
            "h27B70A85".U, "h2E1B2138".U, "h4D2C6DFC".U, "h53380D13".U, "h650A7354".U, "h766A0ABB".U, "h81C2C92E".U, "h92722C85".U,
            "hA2BFE8A1".U, "hA81A664B".U, "hC24B8B70".U, "hC76C51A3".U, "hD192E819".U, "hD6990624".U, "hF40E3585".U, "h106AA070".U,
            "h19A4C116".U, "h1E376C08".U, "h2748774C".U, "h34B0BCB5".U, "h391C0CB3".U, "h4ED8AA4A".U, "h5B9CCA4F".U, "h682E6FF3".U,
            "h748F82EE".U, "h78A5636F".U, "h84C87814".U, "h8CC70208".U, "h90BEFFFA".U, "hA4506CEB".U, "hBEF9A3F7".U, "hC67178F2".U)

          val k = Wire(UInt(width.W))
          val kt = VecInit(Seq.fill(sha256_penumMap(pe_num)(0))(0.U(32.W)))
          for(i <- 0 until sha256_penumMap(pe_num)(0)) {
            if (pe_num > 64) {
              kt(i) := kt_ori((i * 64) + NO_PE % 64)
            }
            else {
              kt(i) := kt_ori((i * pe_num) + NO_PE - 1)
            }
          }


          //根据pe的数选择kt
          //根据pe数和cycle的数选择kt
          if(pe_num >= 64) {
            k := kt(0)
          } else if(pe_num == 32) {
            k := Mux(inputsWire(4)(5), kt(1), kt(0))
          } else if(pe_num == 16) { //四选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5,4) === 0.U) -> kt(0),
              (inputsWire(8)(5,4) === 1.U) -> kt(1),
              (inputsWire(8)(5,4) === 2.U) -> kt(2),
              (inputsWire(8)(5,4) === 3.U) -> kt(3)
            ))
          } else if(pe_num == 8.U) {     //八选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5,3) === 0.U) -> kt(0),
              (inputsWire(8)(5,3) === 1.U) -> kt(1),
              (inputsWire(8)(5,3) === 2.U) -> kt(2),
              (inputsWire(8)(5,3) === 3.U) -> kt(3),
              (inputsWire(8)(5,3) === 4.U) -> kt(4),
              (inputsWire(8)(5,3) === 5.U) -> kt(5),
              (inputsWire(8)(5,3) === 6.U) -> kt(6),
              (inputsWire(8)(5,3) === 7.U) -> kt(7)
            ))
          } else if(pe_num == 4) {     //十六选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5,2) === 0.U) -> kt(0),
              (inputsWire(8)(5,2) === 1.U) -> kt(1),
              (inputsWire(8)(5,2) === 2.U) -> kt(2),
              (inputsWire(8)(5,2) === 3.U) -> kt(3),
              (inputsWire(8)(5,2) === 4.U) -> kt(4),
              (inputsWire(8)(5,2) === 5.U) -> kt(5),
              (inputsWire(8)(5,2) === 6.U) -> kt(6),
              (inputsWire(8)(5,2) === 7.U) -> kt(7),
              (inputsWire(8)(5,2) === 8.U) -> kt(8),
              (inputsWire(8)(5,2) === 9.U) -> kt(9),
              (inputsWire(8)(5,2) === 10.U) -> kt(10),
              (inputsWire(8)(5,2) === 11.U) -> kt(11),
              (inputsWire(8)(5,2) === 12.U) -> kt(12),
              (inputsWire(8)(5,2) === 13.U) -> kt(13),
              (inputsWire(8)(5,2) === 14.U) -> kt(14),
              (inputsWire(8)(5,2) === 15.U) -> kt(15)
            ))
          } else if(pe_num == 2) {    //三十二选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 1) === 0.U) -> kt(0),
              (inputsWire(8)(5, 1) === 1.U) -> kt(1),
              (inputsWire(8)(5, 1) === 2.U) -> kt(2),
              (inputsWire(8)(5, 1) === 3.U) -> kt(3),
              (inputsWire(8)(5, 1) === 4.U) -> kt(4),
              (inputsWire(8)(5, 1) === 5.U) -> kt(5),
              (inputsWire(8)(5, 1) === 6.U) -> kt(6),
              (inputsWire(8)(5, 1) === 7.U) -> kt(7),
              (inputsWire(8)(5, 1) === 8.U) -> kt(8),
              (inputsWire(8)(5, 1) === 9.U) -> kt(9),
              (inputsWire(8)(5, 1) === 10.U) -> kt(10),
              (inputsWire(8)(5, 1) === 11.U) -> kt(11),
              (inputsWire(8)(5, 1) === 12.U) -> kt(12),
              (inputsWire(8)(5, 1) === 13.U) -> kt(13),
              (inputsWire(8)(5, 1) === 14.U) -> kt(14),
              (inputsWire(8)(5, 1) === 15.U) -> kt(15),
              (inputsWire(8)(5, 1) === 16.U) -> kt(16),
              (inputsWire(8)(5, 1) === 17.U) -> kt(17),
              (inputsWire(8)(5, 1) === 18.U) -> kt(18),
              (inputsWire(8)(5, 1) === 19.U) -> kt(19),
              (inputsWire(8)(5, 1) === 20.U) -> kt(20),
              (inputsWire(8)(5, 1) === 21.U) -> kt(21),
              (inputsWire(8)(5, 1) === 22.U) -> kt(22),
              (inputsWire(8)(5, 1) === 23.U) -> kt(23),
              (inputsWire(8)(5, 1) === 24.U) -> kt(24),
              (inputsWire(8)(5, 1) === 25.U) -> kt(25),
              (inputsWire(8)(5, 1) === 26.U) -> kt(26),
              (inputsWire(8)(5, 1) === 27.U) -> kt(27),
              (inputsWire(8)(5, 1) === 28.U) -> kt(28),
              (inputsWire(8)(5, 1) === 29.U) -> kt(29),
              (inputsWire(8)(5, 1) === 30.U) -> kt(30),
              (inputsWire(8)(5, 1) === 31.U) -> kt(31)
            ))
          } else if(pe_num == 1) { //六十四选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 0) === 0.U) -> kt(0),
              (inputsWire(8)(5, 0) === 1.U) -> kt(1),
              (inputsWire(8)(5, 0) === 2.U) -> kt(2),
              (inputsWire(8)(5, 0) === 3.U) -> kt(3),
              (inputsWire(8)(5, 0) === 4.U) -> kt(4),
              (inputsWire(8)(5, 0) === 5.U) -> kt(5),
              (inputsWire(8)(5, 0) === 6.U) -> kt(6),
              (inputsWire(8)(5, 0) === 7.U) -> kt(7),
              (inputsWire(8)(5, 0) === 8.U) -> kt(8),
              (inputsWire(8)(5, 0) === 9.U) -> kt(9),
              (inputsWire(8)(5, 0) === 10.U) -> kt(10),
              (inputsWire(8)(5, 0) === 11.U) -> kt(11),
              (inputsWire(8)(5, 0) === 12.U) -> kt(12),
              (inputsWire(8)(5, 0) === 13.U) -> kt(13),
              (inputsWire(8)(5, 0) === 14.U) -> kt(14),
              (inputsWire(8)(5, 0) === 15.U) -> kt(15),
              (inputsWire(8)(5, 0) === 16.U) -> kt(16),
              (inputsWire(8)(5, 0) === 17.U) -> kt(17),
              (inputsWire(8)(5, 0) === 18.U) -> kt(18),
              (inputsWire(8)(5, 0) === 19.U) -> kt(19),
              (inputsWire(8)(5, 0) === 20.U) -> kt(20),
              (inputsWire(8)(5, 0) === 21.U) -> kt(21),
              (inputsWire(8)(5, 0) === 22.U) -> kt(22),
              (inputsWire(8)(5, 0) === 23.U) -> kt(23),
              (inputsWire(8)(5, 0) === 24.U) -> kt(24),
              (inputsWire(8)(5, 0) === 25.U) -> kt(25),
              (inputsWire(8)(5, 0) === 26.U) -> kt(26),
              (inputsWire(8)(5, 0) === 27.U) -> kt(27),
              (inputsWire(8)(5, 0) === 28.U) -> kt(28),
              (inputsWire(8)(5, 0) === 29.U) -> kt(29),
              (inputsWire(8)(5, 0) === 30.U) -> kt(30),
              (inputsWire(8)(5, 0) === 31.U) -> kt(31),
              (inputsWire(8)(5, 0) === 32.U) -> kt(32),
              (inputsWire(8)(5, 0) === 33.U) -> kt(33),
              (inputsWire(8)(5, 0) === 34.U) -> kt(34),
              (inputsWire(8)(5, 0) === 35.U) -> kt(35),
              (inputsWire(8)(5, 0) === 36.U) -> kt(36),
              (inputsWire(8)(5, 0) === 37.U) -> kt(37),
              (inputsWire(8)(5, 0) === 38.U) -> kt(38),
              (inputsWire(8)(5, 0) === 39.U) -> kt(39),
              (inputsWire(8)(5, 0) === 40.U) -> kt(40),
              (inputsWire(8)(5, 0) === 41.U) -> kt(41),
              (inputsWire(8)(5, 0) === 42.U) -> kt(42),
              (inputsWire(8)(5, 0) === 43.U) -> kt(43),
              (inputsWire(8)(5, 0) === 44.U) -> kt(44),
              (inputsWire(8)(5, 0) === 45.U) -> kt(45),
              (inputsWire(8)(5, 0) === 46.U) -> kt(46),
              (inputsWire(8)(5, 0) === 47.U) -> kt(47),
              (inputsWire(8)(5, 0) === 48.U) -> kt(48),
              (inputsWire(8)(5, 0) === 49.U) -> kt(49),
              (inputsWire(8)(5, 0) === 50.U) -> kt(50),
              (inputsWire(8)(5, 0) === 51.U) -> kt(51),
              (inputsWire(8)(5, 0) === 52.U) -> kt(52),
              (inputsWire(8)(5, 0) === 53.U) -> kt(53),
              (inputsWire(8)(5, 0) === 54.U) -> kt(54),
              (inputsWire(8)(5, 0) === 55.U) -> kt(55),
              (inputsWire(8)(5, 0) === 56.U) -> kt(56),
              (inputsWire(8)(5, 0) === 57.U) -> kt(57),
              (inputsWire(8)(5, 0) === 58.U) -> kt(58),
              (inputsWire(8)(5, 0) === 59.U) -> kt(59),
              (inputsWire(8)(5, 0) === 60.U) -> kt(60),
              (inputsWire(8)(5, 0) === 61.U) -> kt(61),
              (inputsWire(8)(5, 0) === 62.U) -> kt(62),
              (inputsWire(8)(5, 0) === 63.U) -> kt(63)
            ))
          } else {
            k := kt(0)
          }
          val SIGMA0 = Wire(UInt(width.W))
          val SIGMA1 = Wire(UInt(width.W))
          val ROTR2 = Wire(UInt(width.W))
          val ROTR13 = Wire(UInt(width.W))
          val ROTR22 = Wire(UInt(width.W))
          val ROTR6 = Wire(UInt(width.W))
          val ROTR11 = Wire(UInt(width.W))
          val ROTR25 = Wire(UInt(width.W))
          val Ch = Wire(UInt(width.W))
          val Maj = Wire(UInt(width.W))
          val T1 = Wire(UInt(width.W))
          val T2 = Wire(UInt(width.W))
          ROTR6 := Cat(inputsWire(4)(5,0), inputsWire(4)(31,6))
          ROTR11 := Cat(inputsWire(4)(10,0), inputsWire(4)(31,11))
          ROTR25 := Cat(inputsWire(4)(24,0), inputsWire(4)(31,25))
          ROTR2 := Cat(inputsWire(0)(1,0), inputsWire(0)(31,2))
          ROTR13 := Cat(inputsWire(0)(12,0), inputsWire(0)(31,13))
          ROTR22 := Cat(inputsWire(0)(21,0), inputsWire(0)(31,22))
          //(e&f) ^ (~e&g)
          Ch := (inputsWire(4) & inputsWire(5)) ^ (~inputsWire(4) & inputsWire(6))
          //(a&b) | (a&c) | (b&c)
          Maj := (inputsWire(0) & inputsWire(1)) ^ (inputsWire(0) & inputsWire(2)) ^ (inputsWire(1) & inputsWire(2))
          SIGMA0 := ROTR2 ^ ROTR13 ^ ROTR22
          SIGMA1 := ROTR6 ^ ROTR11 ^ ROTR25
          T1 := inputsWire(7) + SIGMA1 + Ch + k + inputsWire(9)
          T2 := SIGMA0 + Maj
          if(NO_PE == pe_num || (NO_PE % 64) == 0) {
            when(inputsWire(8)(5, 0) === 63.U) {
              out_buffer2(0) := T1 + T2 + "h6A09E667".U
              out_buffer2(1) := inputsWire(0) + "hBB67AE85".U
              out_buffer2(2) := inputsWire(1) + "h3C6EF372".U
              out_buffer2(3) := inputsWire(2) + "hA54FF53A".U
              out_buffer2(4) := T1 + inputsWire(3) + "h510E527F".U
              out_buffer2(5) := inputsWire(4) + "h9B05688C".U
              out_buffer2(6) := inputsWire(5) + "h1F83D9AB".U
              out_buffer2(7) := inputsWire(6) + "h5BE0CD19".U
              out_buffer2(8) := inputsWire(8) + 1.U
            }.otherwise {
              out_buffer2(0) := T1 + T2
              out_buffer2(1) := inputsWire(0)
              out_buffer2(2) := inputsWire(1)
              out_buffer2(3) := inputsWire(2)
              out_buffer2(4) := T1 + inputsWire(3)
              out_buffer2(5) := inputsWire(4)
              out_buffer2(6) := inputsWire(5)
              out_buffer2(7) := inputsWire(6)
              out_buffer2(8) := inputsWire(8) + 1.U
            }
          }else {
            out_buffer2(0) := T1 + T2
            out_buffer2(1) := inputsWire(0)
            out_buffer2(2) := inputsWire(1)
            out_buffer2(3) := inputsWire(2)
            out_buffer2(4) := T1 + inputsWire(3)
            out_buffer2(5) := inputsWire(4)
            out_buffer2(6) := inputsWire(5)
            out_buffer2(7) := inputsWire(6)
            out_buffer2(8) := inputsWire(8) + 1.U
          }
          for(i <- 9 until outnum_max) {
            out_buffer2(i) := 0.U
          }
        } .otherwise {
          for(i <- 0 until outnum_max) {
            out_buffer2(i) := 0.U
          }
        }
        out_buffer2
      }
      case OPC.sha224 => {
        val out_buffer3 = Wire(Vec(outnum_max, UInt(width.W)))
        when(io.cfg(4, 1) === "b0100".U) {
          val inputsWire = Wire(Vec(innum_max, UInt(width.W)))
          when(NO_PE.U === 1.U && io.cfg(0) === 1.U) {
            inputsWire(0) := "hC1059ED8".U
            inputsWire(1) := "h367CD507".U
            inputsWire(2) := "h3070DD17".U
            inputsWire(3) := "hF70E5939".U
            inputsWire(4) := "hFFC00B31".U
            inputsWire(5) := "h68581511".U
            inputsWire(6) := "h64F98FA7".U
            inputsWire(7) := "hBEFA4FA4".U
            inputsWire(8) := 0.U
            inputsWire(9) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for (i <- 10 until innum_max) {
              inputsWire(i) := 0.U
            }
          }.otherwise {
            for (i <- 0 until 9) {
              inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
            }
            inputsWire(9) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            for (i <- 10 until innum_max) {
              inputsWire(i) := 0.U
            }
          }

          val kt_ori = Seq(
            "h428A2F98".U, "h71374491".U, "hB5C0FBCF".U, "hE9B5DBA5".U, "h3956C25B".U, "h59F111F1".U, "h923F82A4".U, "hAB1C5ED5".U,
            "hD807AA98".U, "h12835B01".U, "h243185BE".U, "h550C7DC3".U, "h72BE5D74".U, "h80DEB1FE".U, "h9BDC06A7".U, "hC19BF174".U,
            "hE49B69C1".U, "hEFBE4786".U, "h0FC19DC6".U, "h240CA1CC".U, "h2DE92C6F".U, "h4A7484AA".U, "h5CB0A9DC".U, "h76F988DA".U,
            "h983E5152".U, "hA831C66D".U, "hB00327C8".U, "hBF597FC7".U, "hC6E00BF3".U, "hD5A79147".U, "h06CA6351".U, "h14292967".U,
            "h27B70A85".U, "h2E1B2138".U, "h4D2C6DFC".U, "h53380D13".U, "h650A7354".U, "h766A0ABB".U, "h81C2C92E".U, "h92722C85".U,
            "hA2BFE8A1".U, "hA81A664B".U, "hC24B8B70".U, "hC76C51A3".U, "hD192E819".U, "hD6990624".U, "hF40E3585".U, "h106AA070".U,
            "h19A4C116".U, "h1E376C08".U, "h2748774C".U, "h34B0BCB5".U, "h391C0CB3".U, "h4ED8AA4A".U, "h5B9CCA4F".U, "h682E6FF3".U,
            "h748F82EE".U, "h78A5636F".U, "h84C87814".U, "h8CC70208".U, "h90BEFFFA".U, "hA4506CEB".U, "hBEF9A3F7".U, "hC67178F2".U)
          val k = Wire(UInt(width.W))
          val kt = VecInit(Seq.fill(sha224_penumMap(pe_num)(0))(0.U(32.W)))
          for (i <- 0 until sha256_penumMap(pe_num)(0)) {
            kt(i) := kt_ori((i * pe_num) + NO_PE - 1)
          }
          //根据pe的数选择kt
          //根据pe数和cycle的数选择kt
          if (pe_num == 64) {
            k := kt(0)
          } else if (pe_num == 32) {
            k := Mux(inputsWire(4)(5), kt(1), kt(0))
          } else if (pe_num == 16) { //四选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 4) === 0.U) -> kt(0),
              (inputsWire(8)(5, 4) === 1.U) -> kt(1),
              (inputsWire(8)(5, 4) === 2.U) -> kt(2),
              (inputsWire(8)(5, 4) === 3.U) -> kt(3)
            ))
          } else if (pe_num == 8.U) { //八选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 3) === 0.U) -> kt(0),
              (inputsWire(8)(5, 3) === 1.U) -> kt(1),
              (inputsWire(8)(5, 3) === 2.U) -> kt(2),
              (inputsWire(8)(5, 3) === 3.U) -> kt(3),
              (inputsWire(8)(5, 3) === 4.U) -> kt(4),
              (inputsWire(8)(5, 3) === 5.U) -> kt(5),
              (inputsWire(8)(5, 3) === 6.U) -> kt(6),
              (inputsWire(8)(5, 3) === 7.U) -> kt(7)
            ))
          } else if (pe_num == 4) { //十六选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 2) === 0.U) -> kt(0),
              (inputsWire(8)(5, 2) === 1.U) -> kt(1),
              (inputsWire(8)(5, 2) === 2.U) -> kt(2),
              (inputsWire(8)(5, 2) === 3.U) -> kt(3),
              (inputsWire(8)(5, 2) === 4.U) -> kt(4),
              (inputsWire(8)(5, 2) === 5.U) -> kt(5),
              (inputsWire(8)(5, 2) === 6.U) -> kt(6),
              (inputsWire(8)(5, 2) === 7.U) -> kt(7),
              (inputsWire(8)(5, 2) === 8.U) -> kt(8),
              (inputsWire(8)(5, 2) === 9.U) -> kt(9),
              (inputsWire(8)(5, 2) === 10.U) -> kt(10),
              (inputsWire(8)(5, 2) === 11.U) -> kt(11),
              (inputsWire(8)(5, 2) === 12.U) -> kt(12),
              (inputsWire(8)(5, 2) === 13.U) -> kt(13),
              (inputsWire(8)(5, 2) === 14.U) -> kt(14),
              (inputsWire(8)(5, 2) === 15.U) -> kt(15)
            ))
          } else if (pe_num == 2) { //三十二选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 1) === 0.U) -> kt(0),
              (inputsWire(8)(5, 1) === 1.U) -> kt(1),
              (inputsWire(8)(5, 1) === 2.U) -> kt(2),
              (inputsWire(8)(5, 1) === 3.U) -> kt(3),
              (inputsWire(8)(5, 1) === 4.U) -> kt(4),
              (inputsWire(8)(5, 1) === 5.U) -> kt(5),
              (inputsWire(8)(5, 1) === 6.U) -> kt(6),
              (inputsWire(8)(5, 1) === 7.U) -> kt(7),
              (inputsWire(8)(5, 1) === 8.U) -> kt(8),
              (inputsWire(8)(5, 1) === 9.U) -> kt(9),
              (inputsWire(8)(5, 1) === 10.U) -> kt(10),
              (inputsWire(8)(5, 1) === 11.U) -> kt(11),
              (inputsWire(8)(5, 1) === 12.U) -> kt(12),
              (inputsWire(8)(5, 1) === 13.U) -> kt(13),
              (inputsWire(8)(5, 1) === 14.U) -> kt(14),
              (inputsWire(8)(5, 1) === 15.U) -> kt(15),
              (inputsWire(8)(5, 1) === 16.U) -> kt(16),
              (inputsWire(8)(5, 1) === 17.U) -> kt(17),
              (inputsWire(8)(5, 1) === 18.U) -> kt(18),
              (inputsWire(8)(5, 1) === 19.U) -> kt(19),
              (inputsWire(8)(5, 1) === 20.U) -> kt(20),
              (inputsWire(8)(5, 1) === 21.U) -> kt(21),
              (inputsWire(8)(5, 1) === 22.U) -> kt(22),
              (inputsWire(8)(5, 1) === 23.U) -> kt(23),
              (inputsWire(8)(5, 1) === 24.U) -> kt(24),
              (inputsWire(8)(5, 1) === 25.U) -> kt(25),
              (inputsWire(8)(5, 1) === 26.U) -> kt(26),
              (inputsWire(8)(5, 1) === 27.U) -> kt(27),
              (inputsWire(8)(5, 1) === 28.U) -> kt(28),
              (inputsWire(8)(5, 1) === 29.U) -> kt(29),
              (inputsWire(8)(5, 1) === 30.U) -> kt(30),
              (inputsWire(8)(5, 1) === 31.U) -> kt(31)
            ))
          } else if (pe_num == 1) { //六十四选一
            k := MuxCase(0.U, Array(
              (inputsWire(8)(5, 0) === 0.U) -> kt(0),
              (inputsWire(8)(5, 0) === 1.U) -> kt(1),
              (inputsWire(8)(5, 0) === 2.U) -> kt(2),
              (inputsWire(8)(5, 0) === 3.U) -> kt(3),
              (inputsWire(8)(5, 0) === 4.U) -> kt(4),
              (inputsWire(8)(5, 0) === 5.U) -> kt(5),
              (inputsWire(8)(5, 0) === 6.U) -> kt(6),
              (inputsWire(8)(5, 0) === 7.U) -> kt(7),
              (inputsWire(8)(5, 0) === 8.U) -> kt(8),
              (inputsWire(8)(5, 0) === 9.U) -> kt(9),
              (inputsWire(8)(5, 0) === 10.U) -> kt(10),
              (inputsWire(8)(5, 0) === 11.U) -> kt(11),
              (inputsWire(8)(5, 0) === 12.U) -> kt(12),
              (inputsWire(8)(5, 0) === 13.U) -> kt(13),
              (inputsWire(8)(5, 0) === 14.U) -> kt(14),
              (inputsWire(8)(5, 0) === 15.U) -> kt(15),
              (inputsWire(8)(5, 0) === 16.U) -> kt(16),
              (inputsWire(8)(5, 0) === 17.U) -> kt(17),
              (inputsWire(8)(5, 0) === 18.U) -> kt(18),
              (inputsWire(8)(5, 0) === 19.U) -> kt(19),
              (inputsWire(8)(5, 0) === 20.U) -> kt(20),
              (inputsWire(8)(5, 0) === 21.U) -> kt(21),
              (inputsWire(8)(5, 0) === 22.U) -> kt(22),
              (inputsWire(8)(5, 0) === 23.U) -> kt(23),
              (inputsWire(8)(5, 0) === 24.U) -> kt(24),
              (inputsWire(8)(5, 0) === 25.U) -> kt(25),
              (inputsWire(8)(5, 0) === 26.U) -> kt(26),
              (inputsWire(8)(5, 0) === 27.U) -> kt(27),
              (inputsWire(8)(5, 0) === 28.U) -> kt(28),
              (inputsWire(8)(5, 0) === 29.U) -> kt(29),
              (inputsWire(8)(5, 0) === 30.U) -> kt(30),
              (inputsWire(8)(5, 0) === 31.U) -> kt(31),
              (inputsWire(8)(5, 0) === 32.U) -> kt(32),
              (inputsWire(8)(5, 0) === 33.U) -> kt(33),
              (inputsWire(8)(5, 0) === 34.U) -> kt(34),
              (inputsWire(8)(5, 0) === 35.U) -> kt(35),
              (inputsWire(8)(5, 0) === 36.U) -> kt(36),
              (inputsWire(8)(5, 0) === 37.U) -> kt(37),
              (inputsWire(8)(5, 0) === 38.U) -> kt(38),
              (inputsWire(8)(5, 0) === 39.U) -> kt(39),
              (inputsWire(8)(5, 0) === 40.U) -> kt(40),
              (inputsWire(8)(5, 0) === 41.U) -> kt(41),
              (inputsWire(8)(5, 0) === 42.U) -> kt(42),
              (inputsWire(8)(5, 0) === 43.U) -> kt(43),
              (inputsWire(8)(5, 0) === 44.U) -> kt(44),
              (inputsWire(8)(5, 0) === 45.U) -> kt(45),
              (inputsWire(8)(5, 0) === 46.U) -> kt(46),
              (inputsWire(8)(5, 0) === 47.U) -> kt(47),
              (inputsWire(8)(5, 0) === 48.U) -> kt(48),
              (inputsWire(8)(5, 0) === 49.U) -> kt(49),
              (inputsWire(8)(5, 0) === 50.U) -> kt(50),
              (inputsWire(8)(5, 0) === 51.U) -> kt(51),
              (inputsWire(8)(5, 0) === 52.U) -> kt(52),
              (inputsWire(8)(5, 0) === 53.U) -> kt(53),
              (inputsWire(8)(5, 0) === 54.U) -> kt(54),
              (inputsWire(8)(5, 0) === 55.U) -> kt(55),
              (inputsWire(8)(5, 0) === 56.U) -> kt(56),
              (inputsWire(8)(5, 0) === 57.U) -> kt(57),
              (inputsWire(8)(5, 0) === 58.U) -> kt(58),
              (inputsWire(8)(5, 0) === 59.U) -> kt(59),
              (inputsWire(8)(5, 0) === 60.U) -> kt(60),
              (inputsWire(8)(5, 0) === 61.U) -> kt(61),
              (inputsWire(8)(5, 0) === 62.U) -> kt(62),
              (inputsWire(8)(5, 0) === 63.U) -> kt(63)
            ))
          } else {
            k := kt(0)
          }
          val SIGMA0 = Wire(UInt(width.W))
          val SIGMA1 = Wire(UInt(width.W))
          val ROTR2 = Wire(UInt(width.W))
          val ROTR13 = Wire(UInt(width.W))
          val ROTR22 = Wire(UInt(width.W))
          val ROTR6 = Wire(UInt(width.W))
          val ROTR11 = Wire(UInt(width.W))
          val ROTR25 = Wire(UInt(width.W))
          val Ch = Wire(UInt(width.W))
          val Maj = Wire(UInt(width.W))
          val T1 = Wire(UInt(width.W))
          val T2 = Wire(UInt(width.W))
          ROTR6 := Cat(inputsWire(4)(5, 0), inputsWire(4)(31, 6))
          ROTR11 := Cat(inputsWire(4)(10, 0), inputsWire(4)(31, 11))
          ROTR25 := Cat(inputsWire(4)(24, 0), inputsWire(4)(31, 25))
          ROTR2 := Cat(inputsWire(0)(1, 0), inputsWire(0)(31, 2))
          ROTR13 := Cat(inputsWire(0)(12, 0), inputsWire(0)(31, 13))
          ROTR22 := Cat(inputsWire(0)(21, 0), inputsWire(0)(31, 22))
          //(e&f) ^ (~e&g)
          Ch := (inputsWire(4) & inputsWire(5)) ^ (~inputsWire(4) & inputsWire(6))
          //(a&b) | (a&c) | (b&c)
          Maj := (inputsWire(0) & inputsWire(1)) ^ (inputsWire(0) & inputsWire(2)) ^ (inputsWire(1) & inputsWire(2))
          SIGMA0 := ROTR2 ^ ROTR13 ^ ROTR22
          SIGMA1 := ROTR6 ^ ROTR11 ^ ROTR25
          T1 := inputsWire(7) + SIGMA1 + Ch + k + inputsWire(9)
          T2 := SIGMA0 + Maj
          if (NO_PE == pe_num) {
            when(inputsWire(8)(5, 0) === 63.U) {
              out_buffer3(0) := T1 + T2 + "hC1059ED8".U
              out_buffer3(1) := inputsWire(0) + "h367CD507".U
              out_buffer3(2) := inputsWire(1) + "h3070DD17".U
              out_buffer3(3) := inputsWire(2) + "hF70E5939".U
              out_buffer3(4) := T1 + inputsWire(3) + "hFFC00B31".U
              out_buffer3(5) := inputsWire(4) + "h68581511".U
              out_buffer3(6) := inputsWire(5) + "h64F98FA7".U
              out_buffer3(7) := inputsWire(6) + "hBEFA4FA4".U
              out_buffer3(8) := inputsWire(8) + 1.U
            }.otherwise {
              out_buffer3(0) := T1 + T2
              out_buffer3(1) := inputsWire(0)
              out_buffer3(2) := inputsWire(1)
              out_buffer3(3) := inputsWire(2)
              out_buffer3(4) := T1 + inputsWire(3)
              out_buffer3(5) := inputsWire(4)
              out_buffer3(6) := inputsWire(5)
              out_buffer3(7) := inputsWire(6)
              out_buffer3(8) := inputsWire(8) + 1.U
            }
          } else {
            out_buffer3(0) := T1 + T2
            out_buffer3(1) := inputsWire(0)
            out_buffer3(2) := inputsWire(1)
            out_buffer3(3) := inputsWire(2)
            out_buffer3(4) := T1 + inputsWire(3)
            out_buffer3(5) := inputsWire(4)
            out_buffer3(6) := inputsWire(5)
            out_buffer3(7) := inputsWire(6)
            out_buffer3(8) := inputsWire(8) + 1.U
          }
          for (i <- 9 until outnum_max) {
            out_buffer3(i) := 0.U
          }
        }.otherwise {
          for (i <- 0 until outnum_max) {
            out_buffer3(i) := 0.U
          }
        }
        out_buffer3
      }
      case OPC.sm3 => {
        val out_buffer4 = Wire(Vec(outnum_max, UInt(width.W)))
        when(io.cfg(4, 1) === "b0011".U) {
          val inputsWire = Wire(Vec(innum_max, UInt(width.W)))
          when(NO_PE.U === 1.U && io.cfg(0) === 1.U) {
            inputsWire(0) := "h7380166F".U
            inputsWire(1) := "h4914B2B9".U
            inputsWire(2) := "h172442D7".U
            inputsWire(3) := "hDA8A0600".U
            inputsWire(4) := "hA96F30BC".U
            inputsWire(5) := "h163138AA".U
            inputsWire(6) := "hE38DEE4D".U
            inputsWire(7) := "hB0FB0E4E".U
            inputsWire(8) := 0.U
            inputsWire(9) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            inputsWire(10) := RegEnable(io.inputs(innum_max - 2), 0.U, true.asBool())
            for (i <- 11 until innum_max) {
              inputsWire(i) := 0.U
            }
          }.otherwise {
            for (i <- 0 until 9) {
              inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
            }
            inputsWire(9) := RegEnable(io.inputs(innum_max - 1), 0.U, true.asBool())
            inputsWire(10) := RegEnable(io.inputs(innum_max - 2), 0.U, true.asBool())
            for (i <- 11 until innum_max) {
              inputsWire(i) := 0.U
            }
          }
          val A_shift = Wire(UInt(width.W))
          val T_shift = Wire(UInt(width.W))
          val tmp_shift = Wire(UInt(width.W))
          val SS1 = Wire(UInt(width.W))
          val SS2 = Wire(UInt(width.W))
          val TT1 = Wire(UInt(width.W))
          val TT2 = Wire(UInt(width.W))
          val j = Wire(UInt(5.W))
          val fg_sel = Wire(UInt(1.W))
          val ff1 = Wire(UInt(width.W))
          val ff2 = Wire(UInt(width.W))
          val ff_res = Wire(UInt(width.W))
          val gg1 = Wire(UInt(width.W))
          val gg2 = Wire(UInt(width.W))
          val gg_res = Wire(UInt(width.W))
          val B_shift = Wire(UInt(width.W))
          val F_shift = Wire(UInt(width.W))
          val P = Wire(UInt(width.W))
          val Tj = Wire(UInt(width.W))

          Tj := Mux(fg_sel === 0.U, "h79cc4519".U, "h7a879d8a".U)

          A_shift := Cat(inputsWire(0)(19, 0), inputsWire(0)(31, 20))
          j := inputsWire(8)(4, 0)
          T_shift := (Tj << j) | (Tj >> (32.U - j))
          tmp_shift := A_shift + inputsWire(4) + T_shift
          SS1 := Cat(tmp_shift(24, 0), tmp_shift(31, 25))
          SS2 := SS1 ^ A_shift
          fg_sel := inputsWire(8)(5) | inputsWire(8)(4)

          //a^b^c
          ff1 := inputsWire(0) ^ inputsWire(1) ^ inputsWire(2)
          //(a&b) | (a&c) | (b&v)
          ff2 := (inputsWire(0) & inputsWire(1)) | (inputsWire(0) & inputsWire(2)) | (inputsWire(1) & inputsWire(2))
          ff_res := Mux(fg_sel === 0.U, ff1, ff2)

          //e^f^g
          gg1 := inputsWire(4) ^ inputsWire(5) ^ inputsWire(6)
          //(e&f) | (~e&g)
          gg2 := (inputsWire(4) & inputsWire(5)) | ((~inputsWire(4)) & inputsWire(6))
          gg_res := Mux(fg_sel === 0.U, gg1, gg2)

          TT1 := ff_res + inputsWire(3) + SS2 + inputsWire(10)
          TT2 := gg_res + inputsWire(7) + SS1 + inputsWire(9)

          B_shift := Cat(inputsWire(1)(22, 0), inputsWire(1)(31, 23))
          F_shift := Cat(inputsWire(5)(12, 0), inputsWire(5)(31, 13))

          P := TT2 ^ Cat(TT2(22, 0), TT2(31, 23)) ^ Cat(TT2(14, 0), TT2(31, 15))
          if (NO_PE == pe_num) {
            when(inputsWire(8)(5, 0) === 63.U) {
              out_buffer4(0) := TT1 ^ "h7380166F".U
              out_buffer4(1) := inputsWire(0) ^ "h4914B2B9".U
              out_buffer4(2) := B_shift ^ "h172442D7".U
              out_buffer4(3) := inputsWire(2) ^ "hDA8A0600".U
              out_buffer4(4) := P ^ "hA96F30BC".U
              out_buffer4(5) := inputsWire(4) ^ "h163138AA".U
              out_buffer4(6) := F_shift ^ "hE38DEE4D".U
              out_buffer4(7) := inputsWire(6) ^ "hB0FB0E4E".U
              out_buffer4(8) := inputsWire(8) + 1.U
            }.otherwise {
              out_buffer4(0) := TT1
              out_buffer4(1) := inputsWire(0)
              out_buffer4(2) := B_shift
              out_buffer4(3) := inputsWire(2)
              out_buffer4(4) := P
              out_buffer4(5) := inputsWire(4)
              out_buffer4(6) := F_shift
              out_buffer4(7) := inputsWire(6)
              out_buffer4(8) := inputsWire(8) + 1.U
            }
          } else {
            out_buffer4(0) := TT1
            out_buffer4(1) := inputsWire(0)
            out_buffer4(2) := B_shift
            out_buffer4(3) := inputsWire(2)
            out_buffer4(4) := P
            out_buffer4(5) := inputsWire(4)
            out_buffer4(6) := F_shift
            out_buffer4(7) := inputsWire(6)
            out_buffer4(8) := inputsWire(8) + 1.U
          }
          for(i <- 9 until outnum_max) {
            out_buffer4(i) := 0.U
          }
        }.otherwise {
          for (i <- 0 until outnum_max) {
            out_buffer4(i) := 0.U
          }
        }
        out_buffer4
      }
      case OPC.sha384_32 => {
        val out_buffer5 = Wire(Vec(outnum_max, UInt(width.W)))
        when(io.cfg(4, 1) === "b0101".U) {
          val inputsWire = Wire(Vec(innum_max, UInt(width.W)))
          when(NO_PE.U === 1.U && io.cfg(0) === 1.U) {
            inputsWire(0) := "hCBBB9D5D".U
            inputsWire(1) := "hC1059ED8".U
            inputsWire(2) := "h629A292A".U
            inputsWire(3) := "h367CD507".U
            inputsWire(4) := "h9159015A".U
            inputsWire(5) := "h3070DD17".U
            inputsWire(6) := "h152FECD8".U
            inputsWire(7) := "hF70E5939".U
            inputsWire(8) := "h67332667".U
            inputsWire(9) := "hFFC00B31".U
            inputsWire(10) := "h8EB44A87".U
            inputsWire(11) := "h68581511".U
            inputsWire(12) := "hDB0C2E0D".U
            inputsWire(13) := "h64F98FA7".U
            inputsWire(14) := "h47B5481D".U
            inputsWire(15) := "hBEFA4FA4".U
            inputsWire(16) := 0.U
            inputsWire(17) := RegEnable(io.inputs(17), 0.U, true.asBool())
            inputsWire(18) := RegEnable(io.inputs(18), 0.U, true.asBool())
          }.otherwise {
            for (i <- 0 until 19) {
              inputsWire(i) := RegEnable(io.inputs(i), 0.U, true.asBool())
            }
          }
          val k_ori = Seq(
            "h428A2F98D728AE22".U, "h7137449123EF65CD".U, "hB5C0FBCFEC4D3B2F".U, "hE9B5DBA58189DBBC".U,
            "h3956C25BF348B538".U, "h59F111F1B605D019".U, "h923F82A4AF194F9B".U, "hAB1C5ED5DA6D8118".U,
            "hD807AA98A3030242".U, "h12835B0145706FBE".U, "h243185BE4EE4B28C".U, "h550C7DC3D5FFB4E2".U,
            "h72BE5D74F27B896F".U, "h80DEB1FE3B1696B1".U, "h9BDC06A725C71235".U, "hC19BF174CF692694".U,
            "hE49B69C19EF14AD2".U, "hEFBE4786384F25E3".U, "h0FC19DC68B8CD5B5".U, "h240CA1CC77AC9C65".U,
            "h2DE92C6F592B0275".U, "h4A7484AA6EA6E483".U, "h5CB0A9DCBD41FBD4".U, "h76F988DA831153B5".U,
            "h983E5152EE66DFAB".U, "hA831C66D2DB43210".U, "hB00327C898FB213F".U, "hBF597FC7BEEF0EE4".U,
            "hC6E00BF33DA88FC2".U, "hD5A79147930AA725".U, "h06CA6351E003826F".U, "h142929670A0E6E70".U,
            "h27B70A8546D22FFC".U, "h2E1B21385C26C926".U, "h4D2C6DFC5AC42AED".U, "h53380D139D95B3DF".U,
            "h650A73548BAF63DE".U, "h766A0ABB3C77B2A8".U, "h81C2C92E47EDAEE6".U, "h92722C851482353B".U,
            "hA2BFE8A14CF10364".U, "hA81A664BBC423001".U, "hC24B8B70D0F89791".U, "hC76C51A30654BE30".U,
            "hD192E819D6EF5218".U, "hD69906245565A910".U, "hF40E35855771202A".U, "h106AA07032BBD1B8".U,
            "h19A4C116B8D2D0C8".U, "h1E376C085141AB53".U, "h2748774CDF8EEB99".U, "h34B0BCB5E19B48A8".U,
            "h391C0CB3C5C95A63".U, "h4ED8AA4AE3418ACB".U, "h5B9CCA4F7763E373".U, "h682E6FF3D6B2B8A3".U,
            "h748F82EE5DEFB2FC".U, "h78A5636F43172F60".U, "h84C87814A1F0AB72".U, "h8CC702081A6439EC".U,
            "h90BEFFFA23631E28".U, "hA4506CEBDE82BDE9".U, "hBEF9A3F7B2C67915".U, "hC67178F2E372532B".U,
            "hCA273ECEEA26619C".U, "hD186B8C721C0C207".U, "hEADA7DD6CDE0EB1E".U, "hF57D4F7FEE6ED178".U,
            "h06F067AA72176FBA".U, "h0A637DC5A2C898A6".U, "h113F9804BEF90DAE".U, "h1B710B35131C471B".U,
            "h28DB77F523047D84".U, "h32CAAB7B40C72493".U, "h3C9EBE0A15C9BEBC".U, "h431D67C49C100D4C".U,
            "h4CC5D4BECB3E42B6".U, "h597F299CFC657E2A".U, "h5FCB6FAB3AD6FAEC".U, "h6C44198C4A475817".U)
          val k = VecInit(Seq.fill(sha384_32_penumMap(pe_num)(0))(0.U(64.W)))
          for (i <- 0 until sha384_32_penumMap(pe_num)(0)) {
            k(i) := k_ori((i * pe_num) + NO_PE - 1)
          }
          val kt = Wire(UInt(64.W))
          //根据pe_num和cycle数选择k
          if (pe_num == 80) { //一选一
            kt := k(0)
          } else if (pe_num == 40) {
            kt := Mux(inputsWire(16) < 40.U, k(0), k(1))
          } else if (pe_num == 20) {
            kt := MuxCase(0.U, Array(
              (inputsWire(16) <= 19.U) -> k(0),
              (20.U < inputsWire(16) & inputsWire(16) <= 39.U) -> k(1),
              (40.U < inputsWire(16) & inputsWire(16) <= 59.U) -> k(2),
              (60.U < inputsWire(16) & inputsWire(16) <= 79.U) -> k(3)))
          } else if (pe_num == 16) {
            kt := MuxCase(0.U, Array(
              (inputsWire(16)(6, 4) === 0.U) -> k(0),
              (inputsWire(16)(6, 4) === 1.U) -> k(1),
              (inputsWire(16)(6, 4) === 2.U) -> k(2),
              (inputsWire(16)(6, 4) === 3.U) -> k(3),
              (inputsWire(16)(6, 4) === 4.U) -> k(4)))
          } else if (pe_num == 4) {
            kt := MuxCase(0.U, Array(
              (inputsWire(16)(6, 2) === 0.U) -> k(0),
              (inputsWire(16)(6, 2) === 1.U) -> k(1),
              (inputsWire(16)(6, 2) === 2.U) -> k(2),
              (inputsWire(16)(6, 2) === 3.U) -> k(3),
              (inputsWire(16)(6, 2) === 4.U) -> k(4),
              (inputsWire(16)(6, 2) === 5.U) -> k(5),
              (inputsWire(16)(6, 2) === 6.U) -> k(6),
              (inputsWire(16)(6, 2) === 7.U) -> k(7),
              (inputsWire(16)(6, 2) === 8.U) -> k(8),
              (inputsWire(16)(6, 2) === 9.U) -> k(9),
              (inputsWire(16)(6, 2) === 10.U) -> k(10),
              (inputsWire(16)(6, 2) === 11.U) -> k(11),
              (inputsWire(16)(6, 2) === 12.U) -> k(12),
              (inputsWire(16)(6, 2) === 13.U) -> k(13),
              (inputsWire(16)(6, 2) === 14.U) -> k(14),
              (inputsWire(16)(6, 2) === 15.U) -> k(15),
              (inputsWire(16)(6, 2) === 16.U) -> k(16),
              (inputsWire(16)(6, 2) === 17.U) -> k(17),
              (inputsWire(16)(6, 2) === 18.U) -> k(18),
              (inputsWire(16)(6, 2) === 19.U) -> k(19)))
          } else {
            kt := k(0)
          }
          val a = Cat(inputsWire(0), inputsWire(1))
          val b = Cat(inputsWire(2), inputsWire(3))
          val c = Cat(inputsWire(4), inputsWire(5))
          val d = Cat(inputsWire(6), inputsWire(7))
          val e = Cat(inputsWire(8), inputsWire(9))
          val f = Cat(inputsWire(10), inputsWire(11))
          val g = Cat(inputsWire(12), inputsWire(13))
          val h = Cat(inputsWire(14), inputsWire(15))

          val S1 = Cat(e(13, 0), e(63, 14)) ^ Cat(e(17, 0), e(63, 18)) ^ Cat(e(40, 0), e(63, 41))
          val ch = (e & f) ^ (~e & g)
          val tmp1 = h + S1 + ch + kt + Cat(inputsWire(17), inputsWire(18))
          val S0 = Cat(a(27, 0), a(63, 28)) ^ Cat(a(33, 0), a(63, 34)) ^ Cat(a(38, 0), a(63, 39))
          val maj = (a & b) ^ (a & c) ^ (b & c)
          val tmp2 = S0 + maj
          if (NO_PE == pe_num) {
            when(inputsWire(16)(7, 0) === 79.U) {
              out_buffer5(0) := (tmp1 + tmp2 + "hCBBB9D5DC1059ED8".U) (63, 32) //a
              out_buffer5(1) := (tmp1 + tmp2 + "hCBBB9D5DC1059ED8".U) (31, 0)
              out_buffer5(2) := (a + "h629A292A367CD507".U) (63, 32) //b = a
              out_buffer5(3) := (a + "h629A292A367CD507".U) (31, 0)
              out_buffer5(4) := (b + "h9159015A3070DD17".U) (63, 32) //c = b
              out_buffer5(5) := (b + "h9159015A3070DD17".U) (31, 0)
              out_buffer5(6) := (c + "h152FECD8F70E5939".U) (63, 32) //d = c
              out_buffer5(7) := (c + "h152FECD8F70E5939".U) (31, 0)
              out_buffer5(8) := (d + tmp1 + "h67332667FFC00B31".U) (63, 32) //e = d + tmp1
              out_buffer5(9) := (d + tmp1 + "h67332667FFC00B31".U) (31, 0)
              out_buffer5(10) := (e + "h8EB44A8768581511".U) (63, 32) //f = e
              out_buffer5(11) := (e + "h8EB44A8768581511".U) (31, 0)
              out_buffer5(12) := (f + "hDB0C2E0D64F98FA7".U) (63, 32) //g = f
              out_buffer5(13) := (f + "hDB0C2E0D64F98FA7".U) (31, 0)
              out_buffer5(14) := (g + "h47B5481DBEFA4FA4".U) (63, 32) //h = g
              out_buffer5(15) := (g + "h47B5481DBEFA4FA4".U) (31, 0)
              out_buffer5(16) := inputsWire(16) + 1.U
            }.otherwise {
              out_buffer5(0) := (tmp1 + tmp2) (63, 32) //a
              out_buffer5(1) := (tmp1 + tmp2) (31, 0)
              out_buffer5(2) := inputsWire(0) //b = a
              out_buffer5(3) := inputsWire(1)
              out_buffer5(4) := inputsWire(2) //c = b
              out_buffer5(5) := inputsWire(3)
              out_buffer5(6) := inputsWire(4) //d = c
              out_buffer5(7) := inputsWire(5)
              out_buffer5(8) := (d + tmp1) (63, 32) //e = d + tmp1
              out_buffer5(9) := (d + tmp1) (31, 0)
              out_buffer5(10) := inputsWire(8) //f = e
              out_buffer5(11) := inputsWire(9)
              out_buffer5(12) := inputsWire(10) //g = f
              out_buffer5(13) := inputsWire(11)
              out_buffer5(14) := inputsWire(12) //h = g
              out_buffer5(15) := inputsWire(13)
              out_buffer5(16) := inputsWire(16) + 1.U
            }
            for (i <- 17 until outnum_max) {
              out_buffer5(i) := 0.U
            }
          } else {
            out_buffer5(0) := (tmp1 + tmp2) (63, 32) //a
            out_buffer5(1) := (tmp1 + tmp2) (31, 0)
            out_buffer5(2) := inputsWire(0) //b = a
            out_buffer5(3) := inputsWire(1)
            out_buffer5(4) := inputsWire(2) //c = b
            out_buffer5(5) := inputsWire(3)
            out_buffer5(6) := inputsWire(4) //d = c
            out_buffer5(7) := inputsWire(5)
            out_buffer5(8) := (d + tmp1) (63, 32) //e = d + tmp1
            out_buffer5(9) := (d + tmp1) (31, 0)
            out_buffer5(10) := inputsWire(8) //f = e
            out_buffer5(11) := inputsWire(9)
            out_buffer5(12) := inputsWire(10) //g = f
            out_buffer5(13) := inputsWire(11)
            out_buffer5(14) := inputsWire(12) //h = g
            out_buffer5(15) := inputsWire(13)
            out_buffer5(16) := inputsWire(16) + 1.U
            for (i <- 17 until outnum_max) {
              out_buffer5(i) := 0.U
            }
          }
        }.otherwise {
            for (i <- 0 until outnum_max) {
              out_buffer5(i) := 0.U
            }
          }
          out_buffer5
        }
    }
    )
  }
  outbuffer := MuxLookup(io.cfg(4,1), tmpbuffer, out_tmp)

  for(i <- 0 until outnum_max) {
    io.outputs(i) := outbuffer(i)
  }

}

//object hashGen extends App {
//  chisel3.Driver.execute(args, () => new hash_alu("hash2", 8, 32, 4, 2))
//}

