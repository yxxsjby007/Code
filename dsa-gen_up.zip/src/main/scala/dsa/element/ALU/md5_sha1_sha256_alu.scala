package dsa.element.ALU
import chisel3._
import chisel3.util._

class md5_sha1_sha256_alu (elename: String, width: Int, pe_num: Int, NO_PE: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(9, UInt(width.W))) //a,b,c,d,e,w
    val outputs = Output(Vec(8, UInt(width.W)))
    val cfg = Input(UInt(2.W)) //0,1->md5, 2->sha1, 3->sha256
  })
  val inputsWire = Wire(Vec(9, UInt(width.W)))
  if (NO_PE == 1) {
    when(io.cfg === 3.U) {
      inputsWire(0) := "h6A09E667".U
      inputsWire(1) := "hBB67AE85".U
      inputsWire(2) := "h3C6EF372".U
      inputsWire(3) := "hA54FF53A".U
      inputsWire(4) := "h510E527F".U
      inputsWire(5) := "h9B05688C".U
      inputsWire(6) := "h1F83D9AB".U
      inputsWire(7) := "h5BE0CD19".U
      inputsWire(8) := RegNext(io.inputs(8))
    }.elsewhen(io.cfg === 2.U) {
      inputsWire(0) := "h67452301".U
      inputsWire(1) := "hEFCDAB89".U
      inputsWire(2) := "h98badcfe".U
      inputsWire(3) := "h10325476".U
      inputsWire(4) := "hC3D2E1F0".U
      inputsWire(5) := 0.U
      inputsWire(6) := 0.U
      inputsWire(7) := 0.U
      inputsWire(8) := RegNext(io.inputs(8))
    }.otherwise {
      inputsWire(0) := "h67452301".U
      inputsWire(1) := "hefcdab89".U
      inputsWire(2) := "h98badcfe".U
      inputsWire(3) := "h10325476".U
      inputsWire(4) := 0.U
      inputsWire(5) := 0.U
      inputsWire(6) := 0.U
      inputsWire(7) := 0.U
      inputsWire(8) := RegNext(io.inputs(8))
    }
  } else if(NO_PE == 65) {
    when(io.cfg === 1.U){
      inputsWire(0) := "h67452301".U
      inputsWire(1) := "hefcdab89".U
      inputsWire(2) := "h98badcfe".U
      inputsWire(3) := "h10325476".U
      inputsWire(4) := 0.U
      inputsWire(5) := 0.U
      inputsWire(6) := 0.U
      inputsWire(7) := 0.U
      inputsWire(8) := RegNext(io.inputs(8))
    } .elsewhen(io.cfg === 3.U){
      inputsWire(0) := "h6A09E667".U
      inputsWire(1) := "hBB67AE85".U
      inputsWire(2) := "h3C6EF372".U
      inputsWire(3) := "hA54FF53A".U
      inputsWire(4) := "h510E527F".U
      inputsWire(5) := "h9B05688C".U
      inputsWire(6) := "h1F83D9AB".U
      inputsWire(7) := "h5BE0CD19".U
      inputsWire(8) := RegNext(io.inputs(8))
    } .otherwise {
      for (i <- 0 until 9) {
        inputsWire(i) := RegNext(io.inputs(i))
      }
    }
  }else {
    for (i <- 0 until 9) {
      inputsWire(i) := RegNext(io.inputs(i))
    }
  }

  //定义函数
  def func1(b:UInt, c:UInt, d:UInt): UInt = {
    val result = Wire(UInt(width.W))
    result := (b & c) | ((~b) & d)
    result
  }

  def func2(b:UInt, c:UInt, d:UInt): UInt = {
    val result = Wire(UInt(width.W))
    result := b ^ c ^ d
    result
  }

  def func3(b:UInt, c:UInt, d:UInt): UInt = {
    val result = Wire(UInt(width.W))
    result := c ^ ((~d) | b)
    result
  }

  def func4(b:UInt, c:UInt, d:UInt): UInt = {
    val result = Wire(UInt(width.W))
    result := (b & c) | (b & d) | (c & d)
    result
  }

  def func5(x:UInt, y:UInt, z:UInt): UInt = {
    val result = Wire(UInt(width.W))
    result := (x & y) ^ (~x & z)
    result
  }




  //md5逻辑
  val si_ori = Seq(7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U, 7.U, 12.U, 17.U, 22.U,
    5.U,  9.U, 14.U, 20.U, 5.U,  9.U, 14.U, 20.U, 5.U,  9.U, 14.U, 20.U, 5.U,  9.U, 14.U, 20.U,
    4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U, 4.U, 11.U, 16.U, 23.U,
    6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U, 6.U, 10.U, 15.U, 21.U)

  val s = Wire(UInt(5.W))
  s := si_ori((NO_PE - 1) % 64)

  val Ti_ori = Seq(
    "hd76aa478".U, "he8c7b756".U, "h242070db".U, "hc1bdceee".U, "hf57c0faf".U, "h4787c62a".U, "ha8304613".U, "hfd469501".U,
    "h698098d8".U,"h8b44f7af".U, "hffff5bb1".U, "h895cd7be".U, "h6b901122".U, "hfd987193".U, "ha679438e".U, "h49b40821".U,
    "hf61e2562".U, "hc040b340".U, "h265e5a51".U, "he9b6c7aa".U, "hd62f105d".U, "h02441453".U, "hd8a1e681".U, "he7d3fbc8".U,
    "h21e1cde6".U, "hc33707d6".U, "hf4d50d87".U, "h455a14ed".U, "ha9e3e905".U, "hfcefa3f8".U, "h676f02d9".U, "h8d2a4c8a".U,
    "hfffa3942".U, "h8771f681".U, "h6d9d6122".U, "hfde5380c".U, "ha4beea44".U, "h4bdecfa9".U, "hf6bb4b60".U, "hbebfbc70".U,
    "h289b7ec6".U, "heaa127fa".U, "hd4ef3085".U, "h04881d05".U, "hd9d4d039".U, "he6db99e5".U, "h1fa27cf8".U, "hc4ac5665".U,
    "hf4292244".U, "h432aff97".U, "hab9423a7".U, "hfc93a039".U, "h655b59c3".U, "h8f0ccc92".U, "hffeff47d".U, "h85845dd1".U,
    "h6fa87e4f".U, "hfe2ce6e0".U, "ha3014314".U, "h4e0811a1".U, "hf7537e82".U, "hbd3af235".U, "h2ad7d2bb".U, "heb86d391".U)

  val T = Wire(UInt(32.W))
  T := Ti_ori((NO_PE - 1) % 64)
  val md5func_res0 = Wire(UInt(width.W))
  val md5func_res1 = Wire(UInt(width.W))
  val md5func_res2 = Wire(UInt(width.W))
  val md5func_res3 = Wire(UInt(width.W))
  val md5fun_res = Wire(UInt(width.W))
  val tmp_B = Wire(UInt(width.W))
  val tmp_B_shift = Wire(UInt(width.W))
  val B_out = Wire(UInt(width.W))

  if((NO_PE - 1) % 64 < 16) {
    md5fun_res := md5func_res0
  } else if((16 <= (NO_PE - 1) % 64) && ((NO_PE - 1) % 64) < 32) {
    md5fun_res := md5func_res1
  } else if((32 <= (NO_PE - 1) % 64) && ((NO_PE - 1) % 64 < 48)) {
    md5fun_res := md5func_res2
  } else {
    md5fun_res := md5func_res3
  }



  //(b&c) | (~b&d)
  md5func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
  //(b&d) | (c&~d)
  md5func_res1 := (inputsWire(1) & inputsWire(3)) | ((~inputsWire(3)) & (inputsWire(2)))
  //b^c^d
  md5func_res2 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
  //c^(b|~d)
  md5func_res3 := inputsWire(2) ^ (~inputsWire(3) | inputsWire(1))
  tmp_B := md5fun_res + inputsWire(0) + T + inputsWire(8)
  tmp_B_shift := (tmp_B << s) | (tmp_B >> (32.U - s))
  B_out := tmp_B_shift + inputsWire(1)



  //sha1逻辑
  val kt = Wire(UInt(32.W))
  val sha1func_res = Wire(UInt(width.W))
  val sha1func_res0 = Wire(UInt(width.W))
  val sha1func_res1 = Wire(UInt(width.W))
  val sha1func_res2 = Wire(UInt(width.W))
  val k_ori = Seq("h5A827999".U, "h6ED9EBA1".U, "h8F1BBCDC".U, "hCA62C1D6".U)
  if(NO_PE <= 20) {
    kt := k_ori(0)
    sha1func_res := sha1func_res0
  } else if (20 < NO_PE &&  NO_PE <= 40) {
    kt := k_ori(1)
    sha1func_res := sha1func_res1
  } else if (40 < NO_PE &&  NO_PE <= 60) {
    kt := k_ori(2)
    sha1func_res := sha1func_res2
  } else {
    kt := k_ori(3)
    sha1func_res := sha1func_res1
  }

  //(b&c) | (~b&d)
  sha1func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))

  //b^c^d
  sha1func_res1 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)

  //(b&c) | (b&d) | (c&d)
  sha1func_res2 := (inputsWire(1) & inputsWire(2)) | (inputsWire(1) & inputsWire(3)) | (inputsWire(2) & inputsWire(3))


  val shift_a = Wire(UInt(width.W))
  val shift_b = Wire(UInt(width.W))
  val tmp_A = Wire(UInt(width.W))
  shift_a := Cat(inputsWire(0)(26, 0), inputsWire(0)(31, 27))
  shift_b := Cat(inputsWire(1)(1, 0), inputsWire(1)(31, 2))
  tmp_A := shift_a + sha1func_res + inputsWire(4) + kt + inputsWire(8)




  //sha256逻辑
  val kt_ori = Seq(
    "h428A2F98".U, "h71374491".U, "hB5C0FBCF".U, "hE9B5DBA5".U, "h3956C25B".U, "h59F111F1".U, "h923F82A4".U, "hAB1C5ED5".U,
    "hD807AA98".U, "h12835B01".U, "h243185BE".U, "h550C7DC3".U, "h72BE5D74".U, "h80DEB1FE".U, "h9BDC06A7".U, "hC19BF174".U,
    "hE49B69C1".U, "hEFBE4786".U, "h0FC19DC6".U, "h240CA1CC".U, "h2DE92C6F".U, "h4A7484AA".U, "h5CB0A9DC".U, "h76F988DA".U,
    "h983E5152".U, "hA831C66D".U, "hB00327C8".U, "hBF597FC7".U, "hC6E00BF3".U, "hD5A79147".U, "h06CA6351".U, "h14292967".U,
    "h27B70A85".U, "h2E1B2138".U, "h4D2C6DFC".U, "h53380D13".U, "h650A7354".U, "h766A0ABB".U, "h81C2C92E".U, "h92722C85".U,
    "hA2BFE8A1".U, "hA81A664B".U, "hC24B8B70".U, "hC76C51A3".U, "hD192E819".U, "hD6990624".U, "hF40E3585".U, "h106AA070".U,
    "h19A4C116".U, "h1E376C08".U, "h2748774C".U, "h34B0BCB5".U, "h391C0CB3".U, "h4ED8AA4A".U, "h5B9CCA4F".U, "h682E6FF3".U,
    "h748F82EE".U, "h78A5636F".U, "h84C87814".U, "h8CC70208".U, "h90BEFFFA".U, "hA4506CEB".U, "hBEF9A3F7".U, "hC67178F2".U)
  val k = Wire(UInt(32.W))
  k := kt_ori((NO_PE - 1) % 64)

  val SIGMA0 = Wire(UInt(width.W))
  val SIGMA1 = Wire(UInt(width.W))
  val ROTR2 = Wire(UInt(width.W))
  val ROTR13 = Wire(UInt(width.W))
  val ROTR22 = Wire(UInt(width.W))
  val ROTR6 = Wire(UInt(width.W))
  val ROTR11 = Wire(UInt(width.W))
  val ROTR25 = Wire(UInt(width.W))
  val Ch = Wire(UInt(width.W))
  val Maj = Wire(UInt(width.W))
  val T1 = Wire(UInt(width.W))
  val T2 = Wire(UInt(width.W))
  ROTR6 := Cat(inputsWire(4)(5,0), inputsWire(4)(31,6))
  ROTR11 := Cat(inputsWire(4)(10,0), inputsWire(4)(31,11))
  ROTR25 := Cat(inputsWire(4)(24,0), inputsWire(4)(31,25))
  ROTR2 := Cat(inputsWire(0)(1,0), inputsWire(0)(31,2))
  ROTR13 := Cat(inputsWire(0)(12,0), inputsWire(0)(31,13))
  ROTR22 := Cat(inputsWire(0)(21,0), inputsWire(0)(31,22))
  //(e&f) ^ (~e&g)
  Ch := (inputsWire(4) & inputsWire(5)) ^ (~inputsWire(4) & inputsWire(6))
  //(a&b) | (a&c) | (b&c)
  Maj := (inputsWire(0) & inputsWire(1)) ^ (inputsWire(0) & inputsWire(2)) ^ (inputsWire(1) & inputsWire(2))
  SIGMA0 := ROTR2 ^ ROTR13 ^ ROTR22
  SIGMA1 := ROTR6 ^ ROTR11 ^ ROTR25
  T1 := inputsWire(7) + SIGMA1 + Ch + k + inputsWire(8)
  T2 := SIGMA0 + Maj

  if(NO_PE == 64) {
    when(io.cfg === 3.U) {
      io.outputs(0) := T1 + T2 + "h6A09E667".U
      io.outputs(1) := inputsWire(0) + "hBB67AE85".U
      io.outputs(2) := inputsWire(1) + "h3C6EF372".U
      io.outputs(3) := inputsWire(2) + "hA54FF53A".U
      io.outputs(4) := T1 + inputsWire(3) + "h510E527F".U
      io.outputs(5) := inputsWire(4) + "h9B05688C".U
      io.outputs(6) := inputsWire(5) + "h1F83D9AB".U
      io.outputs(7) := inputsWire(6) + "h5BE0CD19".U

    } .elsewhen(io.cfg === 1.U) {
      val res1 = inputsWire(3) + "h67452301".U
      val res2 = B_out + "hefcdab89".U
      val res3 = inputsWire(1) + "h98badcfe".U
      val res4 = inputsWire(2) + "h10325476".U

      io.outputs(0) := Cat(res1(7, 0), res1(15, 8), res1(23, 16), res1(31, 24))
      io.outputs(1) := Cat(res2(7, 0), res2(15, 8), res2(23, 16), res2(31, 24))
      io.outputs(2) := Cat(res3(7, 0), res3(15, 8), res3(23, 16), res3(31, 24))
      io.outputs(3) := Cat(res4(7, 0), res4(15, 8), res4(23, 16), res4(31, 24))

      io.outputs(4) := T1 + inputsWire(3) + "h510E527F".U
      io.outputs(5) := inputsWire(4) + "h9B05688C".U
      io.outputs(6) := inputsWire(5) + "h1F83D9AB".U
      io.outputs(7) := inputsWire(6) + "h5BE0CD19".U


    } otherwise {
      io.outputs(0) := tmp_A
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := shift_b
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := inputsWire(3)

      io.outputs(5) := inputsWire(4) + "h9B05688C".U
      io.outputs(6) := inputsWire(5) + "h1F83D9AB".U
      io.outputs(7) := inputsWire(6) + "h5BE0CD19".U

    }
  } else if(NO_PE == 80) {
    when(io.cfg === 2.U) {
      io.outputs(0) := tmp_A + "h67452301".U
      io.outputs(1) := inputsWire(0) + "hEFCDAB89".U
      io.outputs(2) := shift_b + "h98badcfe".U
      io.outputs(3) := inputsWire(2) + "h10325476".U
      io.outputs(4) := inputsWire(3) + "hC3D2E1F0".U

      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)
    } .elsewhen(io.cfg === 3.U) {
      io.outputs(0) := T1 + T2
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)

    } .otherwise {
      io.outputs(0) := inputsWire(3)
      io.outputs(1) := B_out
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)

      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)

    }
  } else {
    when(io.cfg === 2.U) {
      io.outputs(0) := tmp_A
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := shift_b
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := inputsWire(3)

      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)

    } .elsewhen(io.cfg === 3.U) {
      io.outputs(0) := T1 + T2
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)

    } .otherwise {
      io.outputs(0) := inputsWire(3)
      io.outputs(1) := B_out
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)

      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)

    }
  }

}


