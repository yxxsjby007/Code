package dsa.element.ALU

import chisel3._
import chisel3.util._


class des_alu(elename: String, width: Int, NO_PE: Int) extends Module {
  println("des NO_PE" + "NO_PE")
  override val desiredName = elename
  val io = IO(new Bundle {
    val inputs = Input(Vec(4, UInt(width.W)))
    val outputs = Output(Vec(2, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(4, UInt(width.W)))

//  if(NO_PE % 2 == 0 && NO_PE != 0) {
//    inputsWire(0) := RegNext(io.inputs(1))
//    inputsWire(1) := RegNext(io.inputs(0))
//    inputsWire(2) := RegNext(io.inputs(2))
//    inputsWire(3) := RegNext(io.inputs(3))
//  }else {
//    for (i <- 0 until 4) {
//      inputsWire(i) := RegNext(io.inputs(i))
//    }
//  }

  for (i <- 0 until 4) {
    inputsWire(i) := RegNext(io.inputs(i))
  }

  val IP = Seq(
    58, 50, 42, 34, 26, 18, 10, 2,
    60, 52, 44, 36, 28, 20, 12, 4,
    62, 54, 46, 38, 30, 22, 14, 6,
    64, 56, 48, 40, 32, 24, 16, 8,
    57, 49, 41, 33, 25, 17, 9, 1,
    59, 51, 43, 35, 27, 19, 11, 3,
    61, 53, 45, 37, 29, 21, 13, 5,
    63, 55, 47, 39, 31, 23, 15, 7
  )

  val E = Seq(
    32, 1, 2, 3, 4, 5,
    4, 5, 6, 7, 8, 9,
    8, 9, 10, 11, 12, 13,
    12, 13, 14, 15, 16, 17,
    16, 17, 18, 19, 20, 21,
    20, 21, 22, 23, 24, 25,
    24, 25, 26, 27, 28, 29,
    28, 29, 30, 31, 32, 1
  )

  val sbox1 = VecInit(
    14.U, 4.U, 13.U, 1.U, 2.U, 15.U, 11.U, 8.U, 3.U, 10.U, 6.U, 12.U, 5.U, 9.U, 0.U, 7.U,
    0.U, 15.U, 7.U, 4.U, 14.U, 2.U, 13.U, 1.U, 10.U, 6.U, 12.U, 11.U, 9.U, 5.U, 3.U, 8.U,
    4.U, 1.U, 14.U, 8.U, 13.U, 6.U, 2.U, 11.U, 15.U, 12.U, 9.U, 7.U, 3.U, 10.U, 5.U, 0.U,
    15.U, 12.U, 8.U, 2.U, 4.U, 9.U, 1.U, 7.U, 5.U, 11.U, 3.U, 14.U, 10.U, 0.U, 6.U, 13.U
  )

  val sbox2 = VecInit(
    15.U, 1.U, 8.U, 14.U, 6.U, 11.U, 3.U, 4.U, 9.U, 7.U, 2.U, 13.U, 12.U, 0.U, 5.U, 10.U,
    3.U, 13.U, 4.U, 7.U, 15.U, 2.U, 8.U, 14.U, 12.U, 0.U, 1.U, 10.U, 6.U, 9.U, 11.U, 5.U,
    0.U, 14.U, 7.U, 11.U, 10.U, 4.U, 13.U, 1.U, 5.U, 8.U, 12.U, 6.U, 9.U, 3.U, 2.U, 15.U,
    13.U, 8.U, 10.U, 1.U, 3.U, 15.U, 4.U, 2.U, 11.U, 6.U, 7.U, 12.U, 0.U, 5.U, 14.U, 9.U
  )

  val sbox3 = VecInit(
    10.U, 0.U, 9.U, 14.U, 6.U, 3.U, 15.U, 5.U, 1.U, 13.U, 12.U, 7.U, 11.U, 4.U, 2.U, 8.U,
    13.U, 7.U, 0.U, 9.U, 3.U, 4.U, 6.U, 10.U, 2.U, 8.U, 5.U, 14.U, 12.U, 11.U, 15.U, 1.U,
    13.U, 6.U, 4.U, 9.U, 8.U, 15.U, 3.U, 0.U, 11.U, 1.U, 2.U, 12.U, 5.U, 10.U, 14.U, 7.U,
    1.U, 10.U, 13.U, 0.U, 6.U, 9.U, 8.U, 7.U, 4.U, 15.U, 14.U, 3.U, 11.U, 5.U, 2.U, 12.U
  )

  val sbox4 = VecInit(
    7.U, 13.U, 14.U, 3.U, 0.U, 6.U, 9.U, 10.U, 1.U, 2.U, 8.U, 5.U, 11.U, 12.U, 4.U, 15.U,
    13.U, 8.U, 11.U, 5.U, 6.U, 15.U, 0.U, 3.U, 4.U, 7.U, 2.U, 12.U, 1.U, 10.U, 14.U, 9.U,
    10.U, 6.U, 9.U, 0.U, 12.U, 11.U, 7.U, 13.U, 15.U, 1.U, 3.U, 14.U, 5.U, 2.U, 8.U, 4.U,
    3.U, 15.U, 0.U, 6.U, 10.U, 1.U, 13.U, 8.U, 9.U, 4.U, 5.U, 11.U, 12.U, 7.U, 2.U, 14.U
  )
  val sbox5 = VecInit(
    2.U, 12.U, 4.U, 1.U, 7.U, 10.U, 11.U, 6.U, 8.U, 5.U, 3.U, 15.U, 13.U, 0.U, 14.U, 9.U,
    14.U, 11.U, 2.U, 12.U, 4.U, 7.U, 13.U, 1.U, 5.U, 0.U, 15.U, 10.U, 3.U, 9.U, 8.U, 6.U,
    4.U, 2.U, 1.U, 11.U, 10.U, 13.U, 7.U, 8.U, 15.U, 9.U, 12.U, 5.U, 6.U, 3.U, 0.U, 14.U,
    11.U, 8.U, 12.U, 7.U, 1.U, 14.U, 2.U, 13.U, 6.U, 15.U, 0.U, 9.U, 10.U, 4.U, 5.U, 3.U
  )
  val sbox6 = VecInit(
    12.U, 1.U, 10.U, 15.U, 9.U, 2.U, 6.U, 8.U, 0.U, 13.U, 3.U, 4.U, 14.U, 7.U, 5.U, 11.U,
    10.U, 15.U, 4.U, 2.U, 7.U, 12.U, 9.U, 5.U, 6.U, 1.U, 13.U, 14.U, 0.U, 11.U, 3.U, 8.U,
    9.U, 14.U, 15.U, 5.U, 2.U, 8.U, 12.U, 3.U, 7.U, 0.U, 4.U, 10.U, 1.U, 13.U, 11.U, 6.U,
    4.U, 3.U, 2.U, 12.U, 9.U, 5.U, 15.U, 10.U, 11.U, 14.U, 1.U, 7.U, 6.U, 0.U, 8.U, 13.U
  )
  val sbox7 = VecInit(
    4.U, 11.U, 2.U, 14.U, 15.U, 0.U, 8.U, 13.U, 3.U, 12.U, 9.U, 7.U, 5.U, 10.U, 6.U, 1.U,
    13.U, 0.U, 11.U, 7.U, 4.U, 9.U, 1.U, 10.U, 14.U, 3.U, 5.U, 12.U, 2.U, 15.U, 8.U, 6.U,
    1.U, 4.U, 11.U, 13.U, 12.U, 3.U, 7.U, 14.U, 10.U, 15.U, 6.U, 8.U, 0.U, 5.U, 9.U, 2.U,
    6.U, 11.U, 13.U, 8.U, 1.U, 4.U, 10.U, 7.U, 9.U, 5.U, 0.U, 15.U, 14.U, 2.U, 3.U, 12.U
  )
  val sbox8 = VecInit(
    13.U, 2.U, 8.U, 4.U, 6.U, 15.U, 11.U, 1.U, 10.U, 9.U, 3.U, 14.U, 5.U, 0.U, 12.U, 7.U,
    1.U, 15.U, 13.U, 8.U, 10.U, 3.U, 7.U, 4.U, 12.U, 5.U, 6.U, 11.U, 0.U, 14.U, 9.U, 2.U,
    7.U, 11.U, 4.U, 1.U, 9.U, 12.U, 14.U, 2.U, 0.U, 6.U, 10.U, 13.U, 15.U, 3.U, 5.U, 8.U,
    2.U, 1.U, 14.U, 7.U, 4.U, 10.U, 8.U, 13.U, 15.U, 12.U, 9.U, 0.U, 3.U, 5.U, 6.U, 11.U
  )

  val P = Seq(
    16, 7, 20, 21,
    29, 12, 28, 17,
    1, 15, 23, 26,
    5, 18, 31, 10,
    2, 8, 24, 14,
    32, 27, 3, 9,
    19, 13, 30, 6,
    22, 11, 4, 25
  )

  val PI = Seq(
    40, 8, 48, 16, 56, 24, 64, 32,
    39, 7, 47, 15, 55, 23, 63, 31,
    38, 6, 46, 14, 54, 22, 62, 30,
    37, 5, 45, 13, 53, 21, 61, 29,
    36, 4, 44, 12, 52, 20, 60, 28,
    35, 3, 43, 11, 51, 19, 59, 27,
    34, 2, 42, 10, 50, 18, 58, 26,
    33, 1, 41, 9, 49, 17, 57, 25
  )


  val in_tmp = Cat(inputsWire(0)(31, 0), inputsWire(1)(31, 0))
  val L0 = Wire(Vec(32, Bool()))
  val R0 = Wire(Vec(32, Bool()))
  for (i <- 0 until 32) {
    L0(i) := in_tmp(64 - IP(31 - i))
    R0(i) := in_tmp(64 - IP(63 - i))
  }
  //
  //  io.outputs(0) := L0.asUInt()
  //  io.outputs(1) := R0.asUInt()


  val R_E = Wire(Vec(48, Bool()))
  val R_tmp = inputsWire(1)(31, 0)
  for (i <- 0 until 48) {
    R_E(i) := R_tmp(32 - E(47 - i))
  }

  val R_xor_key = R_E.asUInt() ^ Cat(inputsWire(2)(15, 0), inputsWire(3)(31, 0))

  val f_res = Wire(UInt(32.W))
  f_res := Cat(sbox1(Cat(R_xor_key(47, 42)(5), R_xor_key(47, 42)(0), R_xor_key(47, 42)(4, 1))),
    sbox2(Cat(R_xor_key(41, 36)(5), R_xor_key(41, 36)(0), R_xor_key(41, 36)(4, 1))),
    sbox3(Cat(R_xor_key(35, 30)(5), R_xor_key(35, 30)(0), R_xor_key(35, 30)(4, 1))),
    sbox4(Cat(R_xor_key(29, 24)(5), R_xor_key(29, 24)(0), R_xor_key(29, 24)(4, 1))),
    sbox5(Cat(R_xor_key(23, 18)(5), R_xor_key(23, 18)(0), R_xor_key(23, 18)(4, 1))),
    sbox6(Cat(R_xor_key(17, 12)(5), R_xor_key(17, 12)(0), R_xor_key(17, 12)(4, 1))),
    sbox7(Cat(R_xor_key(11, 6)(5), R_xor_key(11, 6)(0), R_xor_key(11, 6)(4, 1))),
    sbox8(Cat(R_xor_key(5, 0)(5), R_xor_key(5, 0)(0), R_xor_key(5, 0)(4, 1))))

  //  f_res(31, 28) := sbox1(R_xor_key(47, 42))
  //  f_res(27, 24) := sbox2(R_xor_key(41, 36))
  //  f_res(23, 20) := sbox3(R_xor_key(35, 30))
  //  f_res(19, 16) := sbox4(R_xor_key(29, 24))
  //  f_res(15, 12) := sbox5(R_xor_key(23, 18))
  //  f_res(11,  8) := sbox6(R_xor_key(17, 12))
  //  f_res(7,  4) := sbox7(R_xor_key(11, 6))
  //  f_res(3,  0) := sbox8(R_xor_key(5, 0))

  val P_res = Wire(Vec(32, Bool()))
  for (i <- 0 until 32) {
    P_res(i) := f_res(32 - P(31 - i))
  }

  val out = Wire(UInt(32.W))
  out := P_res.asUInt() ^ inputsWire(0)(31, 0)

  val res_tmp = Wire(UInt(64.W))
  res_tmp := Cat(out, inputsWire(1)(31, 0))
  val res = Wire(Vec(64, Bool()))
  for (i <- 0 until 64) {
    res(i) := res_tmp(64 - PI(63 - i))
  }
  //  io.outputs(0) := R_xor_key
  //  io.outputs(1) := f_res
  //  io.outputs(0) := res_tmp
  //  io.outputs(1) :=  inputsWire(1)(31, 0)


  if (NO_PE == 0) {
    io.outputs(0) := L0.asUInt()
    io.outputs(1) := R0.asUInt()
  } else if (NO_PE == 16) {
    io.outputs(0) := res.asUInt()(63, 32)
    io.outputs(1) := res.asUInt()(31, 0)
//  } else if(NO_PE % 2 == 1){
//    io.outputs(0) := out
//    io.outputs(1) := inputsWire(1)(31, 0)
  } else {
    io.outputs(0) := inputsWire(1)(31, 0)
    io.outputs(1) := out
  }
}
