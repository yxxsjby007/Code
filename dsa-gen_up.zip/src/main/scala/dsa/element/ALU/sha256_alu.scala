package dsa.element.ALU

import chisel3._
import chisel3.util._
import dsa.element.ALU.alu_Info.sha256_penumMap

class sha256_alu(elename: String, width: Int, pe_num: Int, NO_PE: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle {
    val cfg = Input(UInt(1.W)) //通过cfg判断为循环的起始位置
    val inputs = Input(Vec(10, UInt(width.W))) //a,b,c,d,e,f,g,h,cycle,w
    val outputs = Output(Vec(9, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(9, UInt(width.W)))
  val cycle = Wire(UInt(6.W))
  if(pe_num == 64) {
    if(NO_PE == 1) {
      inputsWire(0) := "h6A09E667".U
      inputsWire(1) := "hBB67AE85".U
      inputsWire(2) := "h3C6EF372".U
      inputsWire(3) := "hA54FF53A".U
      inputsWire(4) := "h510E527F".U
      inputsWire(5) := "h9B05688C".U
      inputsWire(6) := "h1F83D9AB".U
      inputsWire(7) := "h5BE0CD19".U
      cycle := 0.U
      inputsWire(8) := RegNext(io.inputs(9))
    } else {
      for (i <- 0 until 8) {
        inputsWire(i) := RegNext(io.inputs(i))
      }
      cycle := RegNext(io.inputs(8)(5, 0))
      inputsWire(8) := RegNext(io.inputs(9))
    }
  }
  else if(NO_PE == 1) {
    when(io.cfg === 1.U) {
      inputsWire(0) := "h6A09E667".U
      inputsWire(1) := "hBB67AE85".U
      inputsWire(2) := "h3C6EF372".U
      inputsWire(3) := "hA54FF53A".U
      inputsWire(4) := "h510E527F".U
      inputsWire(5) := "h9B05688C".U
      inputsWire(6) := "h1F83D9AB".U
      inputsWire(7) := "h5BE0CD19".U
      cycle := 0.U
      inputsWire(8) := RegNext(io.inputs(9))
    }.otherwise {
      for (i <- 0 until 8) {
        inputsWire(i) := RegNext(io.inputs(i))
      }
      cycle := RegNext(io.inputs(8)(5, 0))
      inputsWire(8) := RegNext(io.inputs(9))
    }
  } else {
    for (i <- 0 until 8) {
      inputsWire(i) := RegNext(io.inputs(i))
    }
    cycle := RegNext(io.inputs(8)(5, 0))
    inputsWire(8) := RegNext(io.inputs(9))
  }


  val kt_ori = Seq(
    "h428A2F98".U, "h71374491".U, "hB5C0FBCF".U, "hE9B5DBA5".U, "h3956C25B".U, "h59F111F1".U, "h923F82A4".U, "hAB1C5ED5".U,
    "hD807AA98".U, "h12835B01".U, "h243185BE".U, "h550C7DC3".U, "h72BE5D74".U, "h80DEB1FE".U, "h9BDC06A7".U, "hC19BF174".U,
    "hE49B69C1".U, "hEFBE4786".U, "h0FC19DC6".U, "h240CA1CC".U, "h2DE92C6F".U, "h4A7484AA".U, "h5CB0A9DC".U, "h76F988DA".U,
    "h983E5152".U, "hA831C66D".U, "hB00327C8".U, "hBF597FC7".U, "hC6E00BF3".U, "hD5A79147".U, "h06CA6351".U, "h14292967".U,
    "h27B70A85".U, "h2E1B2138".U, "h4D2C6DFC".U, "h53380D13".U, "h650A7354".U, "h766A0ABB".U, "h81C2C92E".U, "h92722C85".U,
    "hA2BFE8A1".U, "hA81A664B".U, "hC24B8B70".U, "hC76C51A3".U, "hD192E819".U, "hD6990624".U, "hF40E3585".U, "h106AA070".U,
    "h19A4C116".U, "h1E376C08".U, "h2748774C".U, "h34B0BCB5".U, "h391C0CB3".U, "h4ED8AA4A".U, "h5B9CCA4F".U, "h682E6FF3".U,
    "h748F82EE".U, "h78A5636F".U, "h84C87814".U, "h8CC70208".U, "h90BEFFFA".U, "hA4506CEB".U, "hBEF9A3F7".U, "hC67178F2".U)

  val k = Wire(UInt(width.W))
  val kt = VecInit(Seq.fill(sha256_penumMap(pe_num)(0))(0.U(32.W)))
  for(i <- 0 until sha256_penumMap(pe_num)(0)) {
    if(pe_num > 64) {
      kt(i) := kt_ori((NO_PE - 1) % 64)
    }
    else {
      kt(i) := kt_ori((i * pe_num) + NO_PE - 1)
    }

  }
  //根据pe的数选择kt
  //根据pe数和cycle的数选择kt
  if(pe_num >= 64) {
    k := kt(0)
  } else if(pe_num == 32) {
    k := Mux(cycle(5), kt(1), kt(0))
  } else if(pe_num == 16) { //四选一
    k := MuxCase(0.U, Array(
      (cycle(5,4) === 0.U) -> kt(0),
      (cycle(5,4) === 1.U) -> kt(1),
      (cycle(5,4) === 2.U) -> kt(2),
      (cycle(5,4) === 3.U) -> kt(3)
    ))
  } else if(pe_num == 8.U) {     //八选一
    k := MuxCase(0.U, Array(
      (cycle(5,3) === 0.U) -> kt(0),
      (cycle(5,3) === 1.U) -> kt(1),
      (cycle(5,3) === 2.U) -> kt(2),
      (cycle(5,3) === 3.U) -> kt(3),
      (cycle(5,3) === 4.U) -> kt(4),
      (cycle(5,3) === 5.U) -> kt(5),
      (cycle(5,3) === 6.U) -> kt(6),
      (cycle(5,3) === 7.U) -> kt(7)
    ))
  } else if(pe_num == 4) {     //十六选一
    k := MuxCase(0.U, Array(
      (cycle(5,2) === 0.U) -> kt(0),
      (cycle(5,2) === 1.U) -> kt(1),
      (cycle(5,2) === 2.U) -> kt(2),
      (cycle(5,2) === 3.U) -> kt(3),
      (cycle(5,2) === 4.U) -> kt(4),
      (cycle(5,2) === 5.U) -> kt(5),
      (cycle(5,2) === 6.U) -> kt(6),
      (cycle(5,2) === 7.U) -> kt(7),
      (cycle(5,2) === 8.U) -> kt(8),
      (cycle(5,2) === 9.U) -> kt(9),
      (cycle(5,2) === 10.U) -> kt(10),
      (cycle(5,2) === 11.U) -> kt(11),
      (cycle(5,2) === 12.U) -> kt(12),
      (cycle(5,2) === 13.U) -> kt(13),
      (cycle(5,2) === 14.U) -> kt(14),
      (cycle(5,2) === 15.U) -> kt(15)
    ))
  } else if(pe_num == 2) {    //三十二选一
    k := MuxCase(0.U, Array(
      (cycle(5, 1) === 0.U) -> kt(0),
      (cycle(5, 1) === 1.U) -> kt(1),
      (cycle(5, 1) === 2.U) -> kt(2),
      (cycle(5, 1) === 3.U) -> kt(3),
      (cycle(5, 1) === 4.U) -> kt(4),
      (cycle(5, 1) === 5.U) -> kt(5),
      (cycle(5, 1) === 6.U) -> kt(6),
      (cycle(5, 1) === 7.U) -> kt(7),
      (cycle(5, 1) === 8.U) -> kt(8),
      (cycle(5, 1) === 9.U) -> kt(9),
      (cycle(5, 1) === 10.U) -> kt(10),
      (cycle(5, 1) === 11.U) -> kt(11),
      (cycle(5, 1) === 12.U) -> kt(12),
      (cycle(5, 1) === 13.U) -> kt(13),
      (cycle(5, 1) === 14.U) -> kt(14),
      (cycle(5, 1) === 15.U) -> kt(15),
      (cycle(5, 1) === 16.U) -> kt(16),
      (cycle(5, 1) === 17.U) -> kt(17),
      (cycle(5, 1) === 18.U) -> kt(18),
      (cycle(5, 1) === 19.U) -> kt(19),
      (cycle(5, 1) === 20.U) -> kt(20),
      (cycle(5, 1) === 21.U) -> kt(21),
      (cycle(5, 1) === 22.U) -> kt(22),
      (cycle(5, 1) === 23.U) -> kt(23),
      (cycle(5, 1) === 24.U) -> kt(24),
      (cycle(5, 1) === 25.U) -> kt(25),
      (cycle(5, 1) === 26.U) -> kt(26),
      (cycle(5, 1) === 27.U) -> kt(27),
      (cycle(5, 1) === 28.U) -> kt(28),
      (cycle(5, 1) === 29.U) -> kt(29),
      (cycle(5, 1) === 30.U) -> kt(30),
      (cycle(5, 1) === 31.U) -> kt(31)
    ))
  } else if(pe_num == 1) { //六十四选一
    k := MuxCase(0.U, Array(
      (cycle === 0.U) -> kt(0),
      (cycle === 1.U) -> kt(1),
      (cycle === 2.U) -> kt(2),
      (cycle === 3.U) -> kt(3),
      (cycle === 4.U) -> kt(4),
      (cycle === 5.U) -> kt(5),
      (cycle === 6.U) -> kt(6),
      (cycle === 7.U) -> kt(7),
      (cycle === 8.U) -> kt(8),
      (cycle === 9.U) -> kt(9),
      (cycle === 10.U) -> kt(10),
      (cycle === 11.U) -> kt(11),
      (cycle === 12.U) -> kt(12),
      (cycle === 13.U) -> kt(13),
      (cycle === 14.U) -> kt(14),
      (cycle === 15.U) -> kt(15),
      (cycle === 16.U) -> kt(16),
      (cycle === 17.U) -> kt(17),
      (cycle === 18.U) -> kt(18),
      (cycle === 19.U) -> kt(19),
      (cycle === 20.U) -> kt(20),
      (cycle === 21.U) -> kt(21),
      (cycle === 22.U) -> kt(22),
      (cycle === 23.U) -> kt(23),
      (cycle === 24.U) -> kt(24),
      (cycle === 25.U) -> kt(25),
      (cycle === 26.U) -> kt(26),
      (cycle === 27.U) -> kt(27),
      (cycle === 28.U) -> kt(28),
      (cycle === 29.U) -> kt(29),
      (cycle === 30.U) -> kt(30),
      (cycle === 31.U) -> kt(31),
      (cycle === 32.U) -> kt(32),
      (cycle === 33.U) -> kt(33),
      (cycle === 34.U) -> kt(34),
      (cycle === 35.U) -> kt(35),
      (cycle === 36.U) -> kt(36),
      (cycle === 37.U) -> kt(37),
      (cycle === 38.U) -> kt(38),
      (cycle === 39.U) -> kt(39),
      (cycle === 40.U) -> kt(40),
      (cycle === 41.U) -> kt(41),
      (cycle === 42.U) -> kt(42),
      (cycle === 43.U) -> kt(43),
      (cycle === 44.U) -> kt(44),
      (cycle === 45.U) -> kt(45),
      (cycle === 46.U) -> kt(46),
      (cycle === 47.U) -> kt(47),
      (cycle === 48.U) -> kt(48),
      (cycle === 49.U) -> kt(49),
      (cycle === 50.U) -> kt(50),
      (cycle === 51.U) -> kt(51),
      (cycle === 52.U) -> kt(52),
      (cycle === 53.U) -> kt(53),
      (cycle === 54.U) -> kt(54),
      (cycle === 55.U) -> kt(55),
      (cycle === 56.U) -> kt(56),
      (cycle === 57.U) -> kt(57),
      (cycle === 58.U) -> kt(58),
      (cycle === 59.U) -> kt(59),
      (cycle === 60.U) -> kt(60),
      (cycle === 61.U) -> kt(61),
      (cycle === 62.U) -> kt(62),
      (cycle === 63.U) -> kt(63)
    ))
  } else {
    k := kt(0)
  }

  val SIGMA0 = Wire(UInt(width.W))
  val SIGMA1 = Wire(UInt(width.W))
  val ROTR2 = Wire(UInt(width.W))
  val ROTR13 = Wire(UInt(width.W))
  val ROTR22 = Wire(UInt(width.W))
  val ROTR6 = Wire(UInt(width.W))
  val ROTR11 = Wire(UInt(width.W))
  val ROTR25 = Wire(UInt(width.W))
  val Ch = Wire(UInt(width.W))
  val Maj = Wire(UInt(width.W))
  val T1 = Wire(UInt(width.W))
  val T2 = Wire(UInt(width.W))
  ROTR6 := Cat(inputsWire(4)(5,0), inputsWire(4)(31,6))
  ROTR11 := Cat(inputsWire(4)(10,0), inputsWire(4)(31,11))
  ROTR25 := Cat(inputsWire(4)(24,0), inputsWire(4)(31,25))
  ROTR2 := Cat(inputsWire(0)(1,0), inputsWire(0)(31,2))
  ROTR13 := Cat(inputsWire(0)(12,0), inputsWire(0)(31,13))
  ROTR22 := Cat(inputsWire(0)(21,0), inputsWire(0)(31,22))
  //(e&f) ^ (~e&g)
  Ch := (inputsWire(4) & inputsWire(5)) ^ (~inputsWire(4) & inputsWire(6))
  //(a&b) | (a&c) | (b&c)
  Maj := (inputsWire(0) & inputsWire(1)) ^ (inputsWire(0) & inputsWire(2)) ^ (inputsWire(1) & inputsWire(2))
  SIGMA0 := ROTR2 ^ ROTR13 ^ ROTR22
  SIGMA1 := ROTR6 ^ ROTR11 ^ ROTR25
  T1 := inputsWire(7) + SIGMA1 + Ch + k + inputsWire(8)
  T2 := SIGMA0 + Maj
  if(NO_PE == 64) {
    io.outputs(0) := T1 + T2 + "h6A09E667".U
    io.outputs(1) := inputsWire(0) + "hBB67AE85".U
    io.outputs(2) := inputsWire(1) + "h3C6EF372".U
    io.outputs(3) := inputsWire(2) + "hA54FF53A".U
    io.outputs(4) := T1 + inputsWire(3) + "h510E527F".U
    io.outputs(5) := inputsWire(4) + "h9B05688C".U
    io.outputs(6) := inputsWire(5) + "h1F83D9AB".U
    io.outputs(7) := inputsWire(6) + "h5BE0CD19".U
    io.outputs(8) := 0.U
  }
  else if(NO_PE == pe_num)  {
    when(cycle === 63.U) {
      io.outputs(0) := T1 + T2 + "h6A09E667".U
      io.outputs(1) := inputsWire(0) + "hBB67AE85".U
      io.outputs(2) := inputsWire(1) + "h3C6EF372".U
      io.outputs(3) := inputsWire(2) + "hA54FF53A".U
      io.outputs(4) := T1 + inputsWire(3) + "h510E527F".U
      io.outputs(5) := inputsWire(4) + "h9B05688C".U
      io.outputs(6) := inputsWire(5) + "h1F83D9AB".U
      io.outputs(7) := inputsWire(6) + "h5BE0CD19".U
      io.outputs(8) := 0.U
    }.otherwise {
      io.outputs(0) := T1 + T2
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)
      io.outputs(8) := cycle + 1.U
    }
  }else {
      io.outputs(0) := T1 + T2
      io.outputs(1) := inputsWire(0)
      io.outputs(2) := inputsWire(1)
      io.outputs(3) := inputsWire(2)
      io.outputs(4) := T1 + inputsWire(3)
      io.outputs(5) := inputsWire(4)
      io.outputs(6) := inputsWire(5)
      io.outputs(7) := inputsWire(6)
      io.outputs(8) := cycle + 1.U
    }
}

//object sha256Gen extends App {
//  chisel3.Driver.execute(args, () => new sha256_alu("sha256", 32, 16, 1))
//
//}