package dsa.element

import chisel3._
import chisel3.util._
import dsa.parameter.Param.cfgDataW
import dsa.parameter.Param.pe_cfgwidth
import dsa.parameter.Param.pe_cyclewidth

class CfgMem(regW:Int) extends Module {
  val cfgAddrWidth = log2Ceil((regW + cfgDataW - 1) / cfgDataW) //LM: cfg的地址位宽
  val io = IO(
    new Bundle() {
      val cfgEn = Input(Bool())
      val dpm_ctrlin = Input(UInt(2.W))       //单一算法给1
      val cfgAddr = Input(UInt(cfgAddrWidth.W))
      val cfgData = Input(UInt(cfgDataW.W))
      val cfgOut = Output(UInt(regW.W))
      val dpm_ctrlout = Output(UInt(2.W))
      val ob_ctrlin = Input(UInt(1.W))
      val ob_ctrlout = Output(UInt(1.W))
      val pe_cfgin = Input(UInt(pe_cfgwidth.W))
      val pe_cfgout = Output(UInt(pe_cfgwidth.W))
    }
  )

  io.pe_cfgout := RegNext(io.pe_cfgin)
  val num = (regW + cfgDataW - 1) / cfgDataW
  val outWire = Wire(Vec(num, UInt(cfgDataW.W)))
  for (i <- 0 until num) {
    //outWire(i) := Mux(io.cfgAddr === i.U, io.cfgData , 0.U)
    outWire(i) := RegEnable(io.cfgData, 0.U, io.cfgEn && io.cfgAddr === i.U)
    io.cfgOut := Cat(outWire.reverse)
    io.dpm_ctrlout := io.dpm_ctrlin
    io.ob_ctrlout := io.ob_ctrlin


  }
}

//object CfgGen extends App {
//  chisel3.Driver.execute(args,() => new CfgMem(48) )
//
//
//}
