package dsa.element

import chisel3._
import chisel3.util._


class IB (name :String , width : Int) extends Module {
  override val desiredName = name
  val io = IO(
    new Bundle {
      val inputs = Input(Vec(1, UInt(width.W)))
      val outputs = Output(Vec(1, UInt(width.W)))
    }
  )
  io.outputs(0) := io.inputs(0)
}

class OB ( name : String, inNum : Int , width :Int) extends Module{
  override val desiredName = name
  val io = IO(
    new Bundle() {
      val cfg = Input (UInt(log2Up(inNum).W))
      val inputs = Input(Vec(inNum, UInt(width.W)))
      val outputs = Output(Vec(1, UInt(width.W)))
    }
  )
  val inbuffer = (0 until inNum ).map(i => i.U -> io.inputs(i))
  io.outputs(0) := MuxLookup(io.cfg, 0.U(width.W), inbuffer)
}
