package dsa.element

import chisel3._
import chisel3.util._
import dsa.element.ALU.alu_Info.md5_penumMap


class DPM_md5(elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num, UInt(width.W)))
    val cfg = Input(UInt(2.W))
  })
  val DPM_md5_Ins = Seq.tabulate(PE_num)(i => Module(new md5_dpm(32,  i + 1, PE_num)))

  DPM_md5_Ins(0).io.cfg := io.cfg(0)
  if(PE_num == 64) {
    DPM_md5_Ins(0).io.inputs := io.inputs
    DPM_md5_Ins(0).io.cycle_in := 0.U
  } else {
    when(io.cfg(1) === 1.U) {
      DPM_md5_Ins(0).io.inputs := io.inputs
      DPM_md5_Ins(0).io.cycle_in := 0.U
    } .otherwise {
      for (j <- 0 until 16) {
        DPM_md5_Ins(0).io.inputs(j) := DPM_md5_Ins(PE_num - 1).io.outputs(j + 1)
        DPM_md5_Ins(0).io.cycle_in := DPM_md5_Ins(PE_num - 1).io.cycle_out
      }
    }
  }
  for (i <- 1 until PE_num) {
    for (j <- 0 until 16) {
      DPM_md5_Ins(i).io.inputs(j) := DPM_md5_Ins(i - 1).io.outputs(j + 1)
    }
    DPM_md5_Ins(i).io.cfg := io.cfg
    DPM_md5_Ins(i).io.cycle_in := DPM_md5_Ins(i - 1).io.cycle_out
  }
  for (i <- 0 until PE_num) {
    io.outputs(i) := DPM_md5_Ins(i).io.outputs(0)
  }

}

class md5_dpm(width: Int, NO_PE: Int, PE_num: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W))) //最后一位作为计数器，前16位作为数据输入
    val outputs = Output(Vec(17, UInt(width.W)))
    val cycle_in = Input(UInt(6.W))
    val cycle_out = Output(UInt(6.W))
    val cfg = Input(UInt(1.W))

  })
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for (i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }

  val cycle_in_Wire = Wire(UInt(7.W))
  if (NO_PE == 1) {
    when(io.cfg === 1.U) {
      cycle_in_Wire := 0.U
    }.otherwise {
      cycle_in_Wire := RegNext(io.cycle_in)
    }
  } else {
    cycle_in_Wire := RegNext(io.cycle_in)
  }

  //只有md5
  val oreder_ori = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)

  val order_set = VecInit(Seq.fill(md5_penumMap(PE_num)(1))(0.U(4.W)))


  for(i <- 0 until md5_penumMap(PE_num)(1)) {
    if(PE_num > 64) {
      order_set(i) := oreder_ori((NO_PE - 1) % 64).U
    }
    else {
      order_set(i) := oreder_ori((i * PE_num) + NO_PE - 1).U
    }

  }

  val order = Wire(UInt(4.W))

  if(PE_num == 64) {
    order := order_set(0)
  } else if(PE_num == 32) {
    when(cycle_in_Wire < 32.U) {
      order := order_set(0)
    } .otherwise {
      order := order_set(1)
    }
  } else if (PE_num == 16) {
    order := MuxCase(0.U, Array(
      (cycle_in_Wire(5,4) === 0.U) -> order_set(0),
      (cycle_in_Wire(5,4) === 1.U) -> order_set(1),
      (cycle_in_Wire(5,4) === 2.U) -> order_set(2),
      (cycle_in_Wire(5,4) === 3.U) -> order_set(3)
    ))
  }  else if(PE_num == 8.U) {     //八选一
    order := MuxCase(0.U, Array(
      (cycle_in_Wire(5,3) === 0.U) -> order_set(0),
      (cycle_in_Wire(5,3) === 1.U) -> order_set(1),
      (cycle_in_Wire(5,3) === 2.U) -> order_set(2),
      (cycle_in_Wire(5,3) === 3.U) -> order_set(3),
      (cycle_in_Wire(5,3) === 4.U) -> order_set(4),
      (cycle_in_Wire(5,3) === 5.U) -> order_set(5),
      (cycle_in_Wire(5,3) === 6.U) -> order_set(6),
      (cycle_in_Wire(5,3) === 7.U) -> order_set(7)
    ))
  } else if(PE_num == 4) {     //十六选一
    order := MuxCase(0.U, Array(
      (cycle_in_Wire(5,2) === 0.U) -> order_set(0),
      (cycle_in_Wire(5,2) === 1.U) -> order_set(1),
      (cycle_in_Wire(5,2) === 2.U) -> order_set(2),
      (cycle_in_Wire(5,2) === 3.U) -> order_set(3),
      (cycle_in_Wire(5,2) === 4.U) -> order_set,
      (cycle_in_Wire(5,2) === 5.U) -> order_set(5),
      (cycle_in_Wire(5,2) === 6.U) -> order_set(6),
      (cycle_in_Wire(5,2) === 7.U) -> order_set(7),
      (cycle_in_Wire(5,2) === 8.U) -> order_set(8),
      (cycle_in_Wire(5,2) === 9.U) -> order_set(9),
      (cycle_in_Wire(5,2) === 10.U) -> order_set(10),
      (cycle_in_Wire(5,2) === 11.U) -> order_set(11),
      (cycle_in_Wire(5,2) === 12.U) -> order_set(12),
      (cycle_in_Wire(5,2) === 13.U) -> order_set(13),
      (cycle_in_Wire(5,2) === 14.U) -> order_set(14),
      (cycle_in_Wire(5,2) === 15.U) -> order_set(15)
    ))
  } else if(PE_num == 2) {    //三十二选一
    order := MuxCase(0.U, Array(
      (cycle_in_Wire(5, 1) === 0.U) -> order_set(0),
      (cycle_in_Wire(5, 1) === 1.U) -> order_set(1),
      (cycle_in_Wire(5, 1) === 2.U) -> order_set(2),
      (cycle_in_Wire(5, 1) === 3.U) -> order_set(3),
      (cycle_in_Wire(5, 1) === 4.U) -> order_set,
      (cycle_in_Wire(5, 1) === 5.U) -> order_set(5),
      (cycle_in_Wire(5, 1) === 6.U) -> order_set(6),
      (cycle_in_Wire(5, 1) === 7.U) -> order_set(7),
      (cycle_in_Wire(5, 1) === 8.U) -> order_set(8),
      (cycle_in_Wire(5, 1) === 9.U) -> order_set(9),
      (cycle_in_Wire(5, 1) === 10.U) -> order_set(10),
      (cycle_in_Wire(5, 1) === 11.U) -> order_set(11),
      (cycle_in_Wire(5, 1) === 12.U) -> order_set(12),
      (cycle_in_Wire(5, 1) === 13.U) -> order_set(13),
      (cycle_in_Wire(5, 1) === 14.U) -> order_set(14),
      (cycle_in_Wire(5, 1) === 15.U) -> order_set(15),
      (cycle_in_Wire(5, 1) === 16.U) -> order_set(16),
      (cycle_in_Wire(5, 1) === 17.U) -> order_set(17),
      (cycle_in_Wire(5, 1) === 18.U) -> order_set(18),
      (cycle_in_Wire(5, 1) === 19.U) -> order_set(19),
      (cycle_in_Wire(5, 1) === 20.U) -> order_set(20),
      (cycle_in_Wire(5, 1) === 21.U) -> order_set(21),
      (cycle_in_Wire(5, 1) === 22.U) -> order_set(22),
      (cycle_in_Wire(5, 1) === 23.U) -> order_set(23),
      (cycle_in_Wire(5, 1) === 24.U) -> order_set(24),
      (cycle_in_Wire(5, 1) === 25.U) -> order_set(25),
      (cycle_in_Wire(5, 1) === 26.U) -> order_set(26),
      (cycle_in_Wire(5, 1) === 27.U) -> order_set(27),
      (cycle_in_Wire(5, 1) === 28.U) -> order_set(28),
      (cycle_in_Wire(5, 1) === 29.U) -> order_set(29),
      (cycle_in_Wire(5, 1) === 30.U) -> order_set(30),
      (cycle_in_Wire(5, 1) === 31.U) -> order_set(31)
    ))
  } else if(PE_num == 1) { //六十四选一
    order := MuxCase(0.U, Array(
      (cycle_in_Wire(5, 0) === 0.U) -> order_set(0),
      (cycle_in_Wire(5, 0) === 1.U) -> order_set(1),
      (cycle_in_Wire(5, 0) === 2.U) -> order_set(2),
      (cycle_in_Wire(5, 0) === 3.U) -> order_set(3),
      (cycle_in_Wire(5, 0) === 4.U) -> order_set(4),
      (cycle_in_Wire(5, 0) === 5.U) -> order_set(5),
      (cycle_in_Wire(5, 0) === 6.U) -> order_set(6),
      (cycle_in_Wire(5, 0) === 7.U) -> order_set(7),
      (cycle_in_Wire(5, 0) === 8.U) -> order_set(8),
      (cycle_in_Wire(5, 0) === 9.U) -> order_set(9),
      (cycle_in_Wire(5, 0) === 10.U) -> order_set(10),
      (cycle_in_Wire(5, 0) === 11.U) -> order_set(11),
      (cycle_in_Wire(5, 0) === 12.U) -> order_set(12),
      (cycle_in_Wire(5, 0) === 13.U) -> order_set(13),
      (cycle_in_Wire(5, 0) === 14.U) -> order_set(14),
      (cycle_in_Wire(5, 0) === 15.U) -> order_set(15),
      (cycle_in_Wire(5, 0) === 16.U) -> order_set(16),
      (cycle_in_Wire(5, 0) === 17.U) -> order_set(17),
      (cycle_in_Wire(5, 0) === 18.U) -> order_set(18),
      (cycle_in_Wire(5, 0) === 19.U) -> order_set(19),
      (cycle_in_Wire(5, 0) === 20.U) -> order_set(20),
      (cycle_in_Wire(5, 0) === 21.U) -> order_set(21),
      (cycle_in_Wire(5, 0) === 22.U) -> order_set(22),
      (cycle_in_Wire(5, 0) === 23.U) -> order_set(23),
      (cycle_in_Wire(5, 0) === 24.U) -> order_set(24),
      (cycle_in_Wire(5, 0) === 25.U) -> order_set(25),
      (cycle_in_Wire(5, 0) === 26.U) -> order_set(26),
      (cycle_in_Wire(5, 0) === 27.U) -> order_set(27),
      (cycle_in_Wire(5, 0) === 28.U) -> order_set(28),
      (cycle_in_Wire(5, 0) === 29.U) -> order_set(29),
      (cycle_in_Wire(5, 0) === 30.U) -> order_set(30),
      (cycle_in_Wire(5, 0) === 31.U) -> order_set(31),
      (cycle_in_Wire(5, 0) === 32.U) -> order_set(32),
      (cycle_in_Wire(5, 0) === 33.U) -> order_set(33),
      (cycle_in_Wire(5, 0) === 34.U) -> order_set(34),
      (cycle_in_Wire(5, 0) === 35.U) -> order_set(35),
      (cycle_in_Wire(5, 0) === 36.U) -> order_set(36),
      (cycle_in_Wire(5, 0) === 37.U) -> order_set(37),
      (cycle_in_Wire(5, 0) === 38.U) -> order_set(38),
      (cycle_in_Wire(5, 0) === 39.U) -> order_set(39),
      (cycle_in_Wire(5, 0) === 40.U) -> order_set(40),
      (cycle_in_Wire(5, 0) === 41.U) -> order_set(41),
      (cycle_in_Wire(5, 0) === 42.U) -> order_set(42),
      (cycle_in_Wire(5, 0) === 43.U) -> order_set(43),
      (cycle_in_Wire(5, 0) === 44.U) -> order_set(44),
      (cycle_in_Wire(5, 0) === 45.U) -> order_set(45),
      (cycle_in_Wire(5, 0) === 46.U) -> order_set(46),
      (cycle_in_Wire(5, 0) === 47.U) -> order_set(47),
      (cycle_in_Wire(5, 0) === 48.U) -> order_set(48),
      (cycle_in_Wire(5, 0) === 49.U) -> order_set(49),
      (cycle_in_Wire(5, 0) === 50.U) -> order_set(50),
      (cycle_in_Wire(5, 0) === 51.U) -> order_set(51),
      (cycle_in_Wire(5, 0) === 52.U) -> order_set(52),
      (cycle_in_Wire(5, 0) === 53.U) -> order_set(53),
      (cycle_in_Wire(5, 0) === 54.U) -> order_set(54),
      (cycle_in_Wire(5, 0) === 55.U) -> order_set(55),
      (cycle_in_Wire(5, 0) === 56.U) -> order_set(56),
      (cycle_in_Wire(5, 0) === 57.U) -> order_set(57),
      (cycle_in_Wire(5, 0) === 58.U) -> order_set(58),
      (cycle_in_Wire(5, 0) === 59.U) -> order_set(59),
      (cycle_in_Wire(5, 0) === 60.U) -> order_set(60),
      (cycle_in_Wire(5, 0) === 61.U) -> order_set(61),
      (cycle_in_Wire(5, 0) === 62.U) -> order_set(62),
      (cycle_in_Wire(5, 0) === 63.U) -> order_set(63)
    ))
  } else {
    order := order_set(0)
  }

  if(NO_PE == 1) {
    when(io.cfg === 1.U) {
      io.outputs(0) := Cat(inputsWire(0)(7, 0), inputsWire(0)(15, 8), inputsWire(0)(23, 16), inputsWire(0)(31, 24))
      for (i <- 1 until 15) {
        io.outputs(i) := Cat(inputsWire(i - 1)(7, 0), inputsWire(i - 1)(15, 8), inputsWire(i - 1)(23, 16), inputsWire(i - 1)(31, 24))
      }
      io.outputs(15) := inputsWire(14)
      io.outputs(16) := inputsWire(15)
    }.otherwise {
      if(PE_num == 32) {
        io.outputs(0) := Mux(cycle_in_Wire < 32.U, inputsWire(order_set(0)), inputsWire(order_set(1)))
      }
      else if(PE_num == 16) {
        io.outputs(0) :=  MuxCase(0.U, Array(
          (cycle_in_Wire(5,4) === 0.U) -> inputsWire(order_set(0)),
          (cycle_in_Wire(5,4) === 1.U) -> inputsWire(order_set(1)),
          (cycle_in_Wire(5,4) === 2.U) -> inputsWire(order_set(2)),
          (cycle_in_Wire(5,4) === 3.U) -> inputsWire(order_set(3))
        ))
      } else if(PE_num == 1) {
        when(cycle_in_Wire(5,0) < 16.U) {
          io.outputs(0) := inputsWire(cycle_in_Wire(5,0))
        } .elsewhen(16.U <= cycle_in_Wire(5,0) && cycle_in_Wire(5,0) < 32.U) {
          io.outputs(0) := inputsWire(((cycle_in_Wire(5,0) - 16.U) * 5.U + 1.U)% 16.U)
        } .elsewhen(32.U <= cycle_in_Wire(5,0) && cycle_in_Wire(5,0) < 48.U) {
          io.outputs(0) := inputsWire(((cycle_in_Wire(5, 0) - 32.U) * 3.U + 5.U) % 16.U)
        } .otherwise {
          io.outputs(0) := inputsWire(((cycle_in_Wire(5, 0) - 48.U) * 7.U) % 16.U)
        }
      } else {
        io.outputs(0) := inputsWire(order)
      }

      for (i <- 1 until 17) {
        io.outputs(i) := inputsWire(i - 1)
      }
    }
  } else {
    if(PE_num == 32) {
      io.outputs(0) := Mux(cycle_in_Wire < 32.U, inputsWire(order_set(0)), inputsWire(order_set(1)))
    }
    else if(PE_num == 16) {
      io.outputs(0) :=  MuxCase(0.U, Array(
        (cycle_in_Wire(5,4) === 0.U) -> inputsWire(order_set(0)),
        (cycle_in_Wire(5,4) === 1.U) -> inputsWire(order_set(1)),
        (cycle_in_Wire(5,4) === 2.U) -> inputsWire(order_set(2)),
        (cycle_in_Wire(5,4) === 3.U) -> inputsWire(order_set(3))
      ))
    } else if(PE_num == 1) {
      when(cycle_in_Wire(5,0) < 16.U) {
        io.outputs(0) := inputsWire(cycle_in_Wire(5,0))
      } .elsewhen(16.U <= cycle_in_Wire(5,0) < 32.U) {
        io.outputs(0) := inputsWire(((cycle_in_Wire(5,0) - 16.U) * 5.U + 1.U)% 16.U)
      } .elsewhen(32.U <= cycle_in_Wire(5,0) < 48.U) {
        io.outputs(0) := inputsWire(((cycle_in_Wire(5, 0) - 32.U) * 3.U + 5.U) % 16.U)
      } .otherwise {
        io.outputs(0) := inputsWire(((cycle_in_Wire(5, 0) - 48.U) * 7.U) % 16.U)
      }
    } else {
      io.outputs(0) := inputsWire(order)
    }
    for (i <- 1 until 17) {
      io.outputs(i) := inputsWire(i - 1)
    }
  }




  io.cycle_out := cycle_in_Wire + 1.U
}
