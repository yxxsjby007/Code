/*


package dsa.element

import chisel3._

import chisel3.util._
import dsa.element.ALU.OPC
import dsa.element.ALU.OpInfo
import dsa.element.ALU.ram

//data preprocess module
class DPM(elename: String, op_type: Int, in_num: Int, data_sets: Int, PE_num: Int, cycle: Int, width: Int) extends Module {
  override val desiredName = elename
  println("DPM :" + op_type)
  val alu_type = OpInfo.fuget(op_type)
  println("alu_type : " + alu_type)
  val max_cycle = alu_type.map(OpInfo.getOperandCycle(_)).max
  val max_out = alu_type.map(OpInfo.getDPMoutNum(_)).max
  println("max_out :" + max_out)
  val out_num = max_out * PE_num
  println("out_num :" + out_num)
  //println("max_cycle : " + max_cycle)
  val d = alu_type.map(OpInfo.getDPMoutNum(_)).max * data_sets
  val max_data_num = alu_type.map((OpInfo.getDPMOutData(_))).max
  val io = IO(new Bundle() {
    //cfg分高低控制为，低两位0~1控制数据输入输出，高几位控制运算类型
    val cfg = Input(UInt(7.W)) //cfg = 1时开始读入数据，cfg = 2时开始往外输出数据，cfg同时需要确定运算类型，从而确定outbuffers的数据
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(out_num, UInt(width.W)))
  })

  val oreder = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)

  val Rcon = Seq("h01000000".U, "h02000000".U, "h04000000".U, "h08000000".U,
    "h10000000".U, "h20000000".U, "h40000000".U, "h80000000".U,
    "h1b000000".U, "h36000000".U)
  //创建数据输入计数器
  val data_in_wire = Wire(UInt(log2Ceil(data_sets).W))
  val data_in_Reg = RegEnable(data_in_wire + 1.U, 0.U, data_in_wire < data_sets.U)
  data_in_wire := data_in_Reg
  //把数据依次存入到buffers中
  val inbuffers = RegInit(VecInit(Seq.fill(data_sets)(VecInit(Seq.fill(in_num)(0.U(width.W)))))) // 创建多个输入缓冲区，每个缓冲区存放in_num个数据
  when(io.cfg(0) === 1.U) {
    inbuffers(data_in_wire) := io.inputs
  }

  val tmpbuffers = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W)))))) // 输出前数据准备的缓冲区
  val outbuffers = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W)))))) // 创建多个输入缓冲区，每个缓冲区存放in_num个数据
  val tmpbuffs0 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W)))))) // 创建多个输入缓冲区，每个缓冲区存放in_num个数据
  //val tmpbuffs1 = RegInit(VecInit(Seq.fill(data_sets)(VecInit(Seq.fill(80)(0.U(width.W)))))) // 创建多个输入缓冲区，每个缓冲区存放in_num个数据

  val tmp_map = Seq.empty[(UInt, Vec[Vec[UInt]])] ++ alu_type.map { alu =>
    alu.id.U -> (alu match {
      case OPC.md5 => {
        val tmpbuffs0 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))
        for (j <- 0 until data_sets) {
          for (i <- 0 until 64) {
            tmpbuffs0(j)(i) := inbuffers(j)(oreder(i))
          }
        }
        tmpbuffs0
      }
      case OPC.sha1 => {
        val tmpbuffs1 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))

        for (i <- 0 until data_sets) {
          for (j <- 0 until 16) {
            tmpbuffs1(i)(j) := inbuffers(i)(j)
          }
          for (j <- 16 until 80) {
            val tmp = tmpbuffs1(i)(j - 3) ^ tmpbuffs1(i)(j - 8) ^ tmpbuffs1(i)(j - 14) ^ tmpbuffs1(i)(j - 16)
            tmpbuffs1(i)(j) := Cat(tmp(30, 0), tmp(31))
          }
        }
        tmpbuffs1
      }
      case OPC.sha256 => {
        val tmpbuffs2 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))
        for (i <- 0 until data_sets) {
          for (j <- 0 until 16) {
            tmpbuffs2(i)(j) := inbuffers(i)(j)
          }
          for (j <- 16 until 64) {
            val tmp0 = tmpbuffs2(i)(j - 2)
            val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
            val tmp1 = tmpbuffs2(i)(j - 15)
            val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
            tmpbuffs2(i)(j) := SIGMA_MIN1 + tmpbuffs2(i)(j - 7) + SIGMA_MIN0 + tmpbuffs2(i)(j - 16)
          }
        }
        tmpbuffs2
      }
      case OPC.sm3 => {
        val tmpbuffs3 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))
        val tmp_tmpbuffs3 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(68)(0.U(width.W))))))
        for (i <- 0 until data_sets) {
          for (j <- 0 until 16) {
            tmp_tmpbuffs3(i)(j) := inbuffers(i)(j)
          }
          for (j <- 16 until 68) {
            val tmp0 = tmp_tmpbuffs3(i)(j - 3)
            val tmp0_shift = Cat(tmp0(16, 0), tmp0(31, 17))
            val tmp1 = tmp_tmpbuffs3(i)(j - 16) ^ tmp_tmpbuffs3(i)(j - 9) ^ tmp0_shift
            val P1 = tmp1 ^ Cat(tmp1(16, 0), tmp1(31, 17)) ^ Cat(tmp1(8, 0), tmp1(31, 9))
            val tmp2 = tmp_tmpbuffs3(i)(j - 13)
            val tmp2_shift = Cat(tmp2(24, 0), tmp2(31, 25))
            tmp_tmpbuffs3(i)(j) := P1 ^ tmp2_shift ^ tmp_tmpbuffs3(i)(j - 6)
          }
        }
        for (i <- 0 until data_sets) {
          for (j <- 0 until 64) {
            tmpbuffs3(i)(j) := tmp_tmpbuffs3(i)(j)
          }
        }
        for (i <- data_sets until out_num) {
          for (j <- 0 until 64) {
            tmpbuffs3(i)(j) := tmp_tmpbuffs3(i - data_sets)(j) ^ tmp_tmpbuffs3(i - data_sets)(j + 4)
          }
        }
        tmpbuffs3
      }
      case OPC.sha224 => {
        val tmpbuffs4 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))
        for (i <- 0 until data_sets) {
          for (j <- 0 until 16) {
            tmpbuffs4(i)(j) := inbuffers(i)(j)
          }
          for (j <- 16 until 64) {
            val tmp0 = tmpbuffs4(i)(j - 2)
            val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
            val tmp1 = tmpbuffs4(i)(j - 15)
            val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
            tmpbuffs4(i)(j) := SIGMA_MIN1 + tmpbuffs4(i)(j - 7) + SIGMA_MIN0 + tmpbuffs4(i)(j - 16)
          }
        }
        tmpbuffs4
      }
      case OPC.sha384_32 => { //in_num = 32,按照高低输入，例如in[0] = high, in[1] = low, 先输出低位，再输出高位
        val tmpbuffs5 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))
        val tmp_tmpbuffs5 = RegInit(VecInit(Seq.fill(data_sets)(VecInit(Seq.fill(128)(0.U(64.W))))))
        for (i <- 0 until data_sets) {
          for (j <- 0 until 32 by 2) {
            tmp_tmpbuffs5(i)(j / 2) := Cat(inbuffers(i)(j), inbuffers(i)(j + 1))
          }
          for (j <- 16 until 80) {
            val tmp0 = tmp_tmpbuffs5(i)(j - 15)
            val tmp1 = tmp_tmpbuffs5(i)(j - 2)
            val s0 = Cat(tmp0(0), tmp0(63, 1)) ^ Cat(tmp0(7, 0), tmp0(63, 8)) ^ Cat(Fill(7, 0.U), tmp0(63, 7))
            val s1 = Cat(tmp1(18, 0), tmp1(63, 19)) ^ Cat(tmp1(60, 0), tmp1(63, 61)) ^ Cat(Fill(6, 0.U), tmp1(63, 6))
            tmp_tmpbuffs5(i)(j) := tmp_tmpbuffs5(i)(j - 16) + s0 + tmp_tmpbuffs5(i)(j - 7) + s1
          }
        }
        for (i <- 0 until data_sets) {
          for (j <- 0 until 80) {
            tmpbuffs5(i)(j) := tmp_tmpbuffs5(i)(j)(31, 0)
            tmpbuffs5(i + PE_num)(j) := tmp_tmpbuffs5(i)(j)(63, 32)
          }
        }
        tmpbuffs5
      }
      case OPC.sha384_64 => {
        val tmpbuffs6 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(64.W))))))
        //val tmp_tmpbuffs5 = RegInit(VecInit(Seq.fill(data_sets)(VecInit(Seq.fill(128)(0.U(64.W))))))
        for (i <- 0 until data_sets) {
          for (j <- 0 until 16) {
            tmpbuffs6(i)(j) := inbuffers(i)(j)
          }
          for (j <- 16 until 80) {
            val tmp0 = tmpbuffs6(i)(j - 15)
            val tmp1 = tmpbuffs6(i)(j - 2)
            val s0 = Cat(tmp0(0), tmp0(63, 1)) ^ Cat(tmp0(7, 0), tmp0(63, 8)) ^ Cat(Fill(7, 0.U), tmp0(63, 7))
            val s1 = Cat(tmp1(18, 0), tmp1(63, 19)) ^ Cat(tmp1(60, 0), tmp1(63, 61)) ^ Cat(Fill(6, 0.U), tmp1(63, 6))
            tmpbuffs6(i)(j) := tmpbuffs6(i)(j - 16) + s0 + tmpbuffs6(i)(j - 7) + s1
          }
        }
        tmpbuffs6
      }
      case OPC.aes128 => {
        //aes算法的第一轮异或运算放在DPM模块中，每五个时钟周期开始输出
        //innum=8, 四个密钥，四个明文，进行密文扩展，然后明文与第一组密文异或
        val tmpbuffs7 = RegInit(VecInit(Seq.fill(out_num)(VecInit(Seq.fill(128)(0.U(width.W))))))
        val aescntwire = Wire(UInt(6.W))
        val aescntReg = RegEnable(aescntwire + 1.U, 0.U, io.cfg(1) === 1.U)
        aescntwire := aescntReg

        val subram0 = Module(new ram(8, 8, "E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
        val subram1 = Module(new ram(8, 8, "E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
        val subram2 = Module(new ram(8, 8, "E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
        val subram3 = Module(new ram(8, 8, "E:\\DoctorProject\\RISC_dsa\\src\\resource\\AES_Subword_Data.txt"))
        val index_i = aescntwire % 4.U - 1.U
        val index_j = (aescntwire - 1.U) / 4.U * 4.U + 3.U
        val s0 = tmpbuffs7(index_i)(index_j)(23, 16)
        val s1 = tmpbuffs7(aescntwire % 4.U - 1.U)((aescntwire - 1.U) / 4.U * 4.U + 3.U)(15, 8)
        val s2 = tmpbuffs7(aescntwire % 4.U - 1.U)((aescntwire - 1.U) / 4.U * 4.U + 3.U)(7, 0)
        val s3 = tmpbuffs7(aescntwire % 4.U - 1.U)((aescntwire - 1.U) / 4.U * 4.U + 3.U)(31, 24)
        subram0.io.address := s0
        subram1.io.address := s1
        subram2.io.address := s2
        subram3.io.address := s3
        tmpbuffs7(aescntwire % 4.U - 1.U)((aescntwire - 1.U) / 4.U * 4.U + 4.U) := tmpbuffs7(aescntwire % 4.U - 1.U)((aescntwire - 1.U) / 4.U * 4.U + 1.U) ^
          Cat(subram0.io.val$srcDir/ue, subram1.io.val$srcDir/ue, subram2.io.val$srcDir/ue, subram3.io.val$srcDir/ue) ^ tmpbuffs7(aescntwire % 4.U - 1.U)(((aescntwire - 1.U) / 4.U * 4.U + 4.U) / 4.U)
        for (i <- 0 until data_sets) {
          for (j <- 0 until 4) {
            tmpbuffs7(i)(j) := inbuffers(i)(j)
          }
          for (j <- 4 until 44 by 4) {
            tmpbuffs7(i)(j + 1) := tmpbuffs7(i)(j) ^ tmpbuffs7(i)(j - 3)
            tmpbuffs7(i)(j + 2) := tmpbuffs7(i)(j + 1) ^ tmpbuffs7(i)(j - 2)
            tmpbuffs7(i)(j + 3) := tmpbuffs7(i)(j + 2) ^ tmpbuffs7(i)(j - 1)
          }
        }
        tmpbuffs7
      }
    }
      )

  }


  /*for (alu <- alu_type) {
    alu match {
      case OPC.md5 => {
        //创建一个outbuffer写一个数据处理模块，根据alu_type类型给outbuffer赋值
        for (j <- 0 until data_sets) {
          for (i <- 0 until 64) {
            tmpbuffs0(j)(i) := inbuffers(j)(oreder(i))
          }
        }
      }
      case OPC.sha1 => {
        for (i <- 0 until data_sets) {
          for (j <- 0 until 16) {
            tmpbuffs1(i)(j) := inbuffers(i)(j)
          }
          for (j <- 16 until 80) {
            val tmp = tmpbuffs1(i)(j - 3) ^ tmpbuffs1(i)(j - 8) ^ tmpbuffs1(i)(j - 14) ^ tmpbuffs1(i)(j - 16)
            tmpbuffs1(i)(j) := Cat(tmp(30, 0), tmp(31))
          }
        }
      }
    }
  }*/

  /*when(op_type.U === 3.U) {
    val tmp_map = Seq(0.U -> tmpbuffs0, 1.U -> tmpbuffs1)
  }.otherwise{
    val tmp_map = Seq(0.U -> tmpbuffs0, 1.U -> tmpbuffs1)
  }
  */

  tmpbuffers := MuxLookup(io.cfg(6, 2), tmpbuffs0, tmp_map)

  for (k <- 0 until data_sets) {
    for (i <- 0 until 128 by PE_num) {
      for (j <- 0 until data_sets) {
        outbuffers(k)(i + j) := tmpbuffers(j)(i + k)
      }
    }
  }
  for (k <- data_sets until out_num) {
    for (i <- 0 until 128 by PE_num) {
      for (j <- data_sets until out_num) {
        outbuffers(k)(i + j - data_sets) := tmpbuffers(j)(i + k - data_sets)
      }
    }
  }
  //循环选择数据输出的来源
  val cntwire = Wire(UInt(log2Ceil(PE_num).W))
  val cntReg = RegEnable(cntwire + 1.U, 0.U, io.cfg(1) === 1.U)
  cntwire := cntReg

  val cnwire = Wire(UInt(7.W))
  val cnReg = RegEnable(cnwire + 1.U, 0.U, io.cfg(1) === 1.U)
  cnwire := cnReg

  for (i <- 0 until PE_num) {
    io.outputs(i) := Mux((cnwire >= i.U & cnwire < (max_cycle + i).U), outbuffers(i)(cnwire - i.U), 0.U)
  }

  for (i <- PE_num until out_num) {
    io.outputs(i) := Mux((cnwire >= (i - PE_num).U & cnwire < (max_cycle + i).U), outbuffers(i)(cnwire - i.U + PE_num.U), 0.U)
  }


}

object DPMMain extends App {
  val alu_type = "example"
  val op_type = 1
  val in_num = 16
  val data_sets = 4
  val PE_num = 4
  val cycle = 64
  val width = 32
  chisel3.Driver.execute(args, () => new DPM("DPM", op_type, in_num, data_sets, PE_num, cycle, width))
}

*/

package dsa.element

import chisel3._

import chisel3.util._
import dsa.element.ALU.OPC
import dsa.element.ALU.OpInfo
class DPM(elename: String, op_type: Int, in_num: Int, data_sets: Int, PE_num: Int, cycle : Int, width: Int) extends Module{
  //一个周期输入十六个数据（先不考虑数据扩展）
  override val desiredName = elename
  println("DPM :" + op_type)
  val alu_type = OpInfo.fuget(op_type)
  println("alu_type : " + alu_type)
  val max_cycle = alu_type.map(OpInfo.getOperandCycle(_)).max
  val max_out = alu_type.map(OpInfo.getDPMoutNum(_)).max
  println("max_out :" + max_out)
  val out_num = max_out * PE_num
  //先考虑只有一个输出的情况
  val io = IO(new Bundle() {
    //cfg分高低控制为，低两位0~1控制数据输入输出，高几位控制运算类型
    val cfg = Input(UInt(7.W)) //cfg = 1时开始读入数据，cfg = 2时开始往外输出数据，cfg同时需要确定运算类型，从而确定outbuffers的数据
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num, UInt(width.W)))
    //val outputs = Output(Vec(PE_num * 2, UInt(width.W)))  //sha1两级合在一起
  })
  val data_in_wire = Wire(UInt(log2Ceil(data_sets).W))
  val data_in_Reg = RegEnable(data_in_wire + 1.U, 0.U, data_in_wire < data_sets.U)
  data_in_wire := data_in_Reg
  val inbuffers = RegInit(VecInit(Seq.fill(data_sets)(VecInit(Seq.fill(in_num)(0.U(width.W)))))) // 创建多个输入缓冲区，每个缓冲区存放in_num个数据
  when(io.cfg(0) === 1.U) {
    inbuffers(data_in_wire) := io.inputs
  }
  //创建一个输出计数寄存器
  val data_out_wire = Wire(UInt(10.W))
  val data_out_reg = RegEnable(data_out_wire + 1.U, 0.U, io.cfg(1) === 1.U)
  data_out_wire := data_out_reg

  //循环选择数据输出的来源
  val cntwire = Wire(UInt(log2Ceil(PE_num).W))
  val cntReg = RegEnable(cntwire + 1.U, 0.U, io.cfg(1) === 1.U)
  cntwire := cntReg

  val oreder = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    1, 6, 11, 0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12,
    5, 8, 11, 14, 1, 4, 7, 10, 13, 0, 3, 6, 9, 12, 15, 2,
    0, 7, 14, 5, 12, 3, 10, 1, 8, 15, 6, 13, 4, 11, 2, 9)

  //  val DPM1_1 = Module(new DMP1(32, 4, 1))
  //  DPM1_1.io.counter := data_out_wire
  //  DPM1_1.io.inputs := inbuffers(0)

  //  for(i <- 0 until 15) {
  //    inbuffers(0)(i) := inbuffers(0)(i + 1)
  //  }
  //  when(data_out_wire > 16.U) {
  //    inbuffers(0)(15) := DPM1_1.io.outputs
  //  } .otherwise {
  //    inbuffers(0)(15) := inbuffers(0)(0)
  //  }

  val DPM1_module = Seq.tabulate(PE_num)(i => Module(new DMP1(1,32, PE_num, i + 1, oreder(i % 64))))

  DPM1_module(0).io.inputs := io.inputs
  DPM1_module(0).io.cfg := io.cfg
  for(i <- 1 until PE_num) {
    for(j <- 0 until 16){
      DPM1_module(i).io.inputs(j) := DPM1_module(i - 1).io.outputs(j + 1)
    }
    DPM1_module(i).io.cfg := io.cfg
  }
  for(i <- 0 until PE_num) {
    io.outputs(i) := DPM1_module(i).io.outputs(0)
  }


  //sha1两级合在一起时
//    for(i <- 1 until PE_num) {
//      for(j <- 0 until 16){
//        DPM1_module(i).io.inputs(j) := DPM1_module(i - 1).io.outputs(j + 2)
//      }
//      DPM1_module(i).io.cfg := io.cfg
//    }
//    for(i <- 0 until PE_num) {
//      io.outputs(i * 2) := DPM1_module(i).io.outputs(0)
//      io.outputs(i * 2 + 1) := DPM1_module(i).io.outputs(1)
//    }

}


class DMP1(op_type: Int, width: Int, PE_num: Int, NO_PE: Int, md5_NO: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W)))  //最后一位作为计数器，前16位作为数据输入
    val cfg = Input(UInt(7.W))
    //val counter = Input(UInt(10.W))
    val outputs = Output(Vec(17, UInt(width.W)))
    //val outputs = Output(Vec(18, UInt(width.W)))  //两级运算合在一起，增加一个输出
  })
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for(i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }
  val alu_type = OpInfo.fuget(op_type)

  //只有md5

    io.outputs(0) := io.inputs(md5_NO)
    for(i <- 1 until 17) {
      io.outputs(i) := inputsWire(i - 1)
    }




  //只有sha256
//  val tmp0 = inputsWire(14)
//  val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
//  val tmp1 = inputsWire(1)
//  val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
//  val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)
//  if(NO_PE > 16) {
//    io.outputs(0) := tmp2
//    io.outputs(16) := tmp2
//  } else {
//    io.outputs(0) := inputsWire(0)
//    io.outputs(16) := inputsWire(0)
//  }
//  for(i <- 1 until 16) {
//    io.outputs(i) := inputsWire(i)
//  }


  //只有sha1
//  val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
//  val tmp_data = Cat(tmp(30, 0), tmp(31))
//  if(NO_PE > 16) {
//    io.outputs(0) := tmp_data
//    io.outputs(16) := tmp_data
//  } else {
//    io.outputs(0) := inputsWire(0)
//    io.outputs(16) := inputsWire(0)
//  }
//  for(i <- 1 until 16) {
//    io.outputs(i) := inputsWire(i)
//  }

  //两级sha1运算合成一个
//  val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
//  val tmp_data = Cat(tmp(30, 0), tmp(31))
//  val tmp_1 = inputsWire(14) ^ inputsWire(9) ^ inputsWire(3) ^ inputsWire(1)
//  val tmp_data_1 = Cat(tmp_1(30, 0), tmp_1(31))
//  if(NO_PE > 8) {
//    io.outputs(0) := tmp_data
//    io.outputs(1) := tmp_data_1
//    io.outputs(16) := tmp_data
//    io.outputs(17) := tmp_data_1
//  } else {
//    io.outputs(0) := inputsWire(0)
//    io.outputs(1) := inputsWire(1)
//    io.outputs(16) := inputsWire(0)
//    io.outputs(17) := inputsWire(1)
//  }
//  for(i <- 2 until 16) {
//    io.outputs(i) := inputsWire(i)
//  }



  //三种算法
//  when(io.cfg(6,2) === 0.U) {
//    io.outputs(0) := io.inputs(md5_NO)
//    for(i <- 1 until 17) {
//      io.outputs(i) := inputsWire(i - 1)
//    }
//  } .elsewhen(io.cfg(6,2) === 1.U) {
//    val tmp = inputsWire(13) ^ inputsWire(8) ^ inputsWire(2) ^ inputsWire(0)
//    val tmp_data = Cat(tmp(30, 0), tmp(31))
//    if(NO_PE > 16) {
//      io.outputs(0) := tmp_data
//      io.outputs(16) := tmp_data
//    } else {
//      io.outputs(0) := inputsWire(0)
//      io.outputs(16) := inputsWire(0)
//    }
//    for(i <- 1 until 16) {
//      io.outputs(i) := inputsWire(i)
//    }
//  } .elsewhen(io.cfg(6,2) === 2.U) {
//    val tmp0 = inputsWire(14)
//    val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
//    val tmp1 = inputsWire(1)
//    val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
//    val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)
//    if(NO_PE > 16) {
//      io.outputs(0) := tmp2
//      io.outputs(16) := tmp2
//    } else {
//      io.outputs(0) := inputsWire(0)
//      io.outputs(16) := inputsWire(0)
//    }
//    for(i <- 1 until 16) {
//      io.outputs(i) := inputsWire(i)
//    }
//  } .otherwise {
//    for(i <- 0 until 17) {
//      io.outputs(i) := 0.U
//    }
//  }


  //假设有4个PE单元
  //  when(io.counter > 16.U) {
  //    io.outputs(0) := tmp_data
  //  } .otherwise {
  //    io.outputs(0) := inputsWire(0)
  //  }
  //  for(i <- 1 until 17) {
  //    io.outputs(i) := inputsWire(i - 1)
  //  }

}

//object DPMMain extends App {
//  val op_type = 1
//  val in_num = 16
//  val data_sets = 1
//  val PE_num = 40
//  val width = 32
//  chisel3.Driver.execute(args, () => new DPM("DPM_newTest", op_type, in_num, data_sets, PE_num, 80, width))
//
//}









