package dsa.element

import chisel3._
import chisel3.util._

class DPM_sha256_multi(elename: String, in_num: Int, PE_num: Int, width: Int) extends Module {

  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))
    val outputs = Output(Vec(PE_num, UInt(width.W)))
    val cfg = Input(UInt((PE_num + 1).W))
  })
  val sha256_dpm = Seq.tabulate(PE_num)(i => Module(new DPM_sha256_1(32, i + 1)))


  when(io.cfg(PE_num) === 1.U) {
    for (j <- 0 until 16) {
      sha256_dpm(0).io.inputs(j) := sha256_dpm(PE_num - 1).io.outputs(j + 1)
    }
  } .otherwise {
    sha256_dpm(0).io.inputs := io.inputs
  }

  sha256_dpm(0).io.cfg:= io.cfg(0)
  for (i <- 1 until PE_num) {
    for (j <- 0 until 16) {
      sha256_dpm(i).io.inputs(j) := sha256_dpm(i - 1).io.outputs(j + 1)
      sha256_dpm(i).io.cfg := io.cfg(i)
    }
  }
  for (i <- 0 until PE_num) {
    io.outputs(i) := sha256_dpm(i).io.outputs(0)
  }
}

class DPM_sha256_1(width: Int, NO_PE: Int) extends Module {
  val io = IO(new Bundle() {
    val inputs = Input(Vec(16, UInt(width.W))) //最后一位作为计数器，前16位作为数据输入
    val outputs = Output(Vec(17, UInt(width.W)))
    val cfg = Input(UInt(1.W))

  })
  println("NO_PE : " + NO_PE)
  val inputsWire = Wire(Vec(16, UInt(width.W)))
  for (i <- 0 until 16) {
    inputsWire(i) := RegNext(io.inputs(i))
  }
  val tmp0 = inputsWire(14)
  val SIGMA_MIN1 = Cat(tmp0(16, 0), tmp0(31, 17)) ^ Cat(tmp0(18, 0), tmp0(31, 19)) ^ Cat(Fill(10, 0.U), tmp0(31, 10))
  val tmp1 = inputsWire(1)
  val SIGMA_MIN0 = Cat(tmp1(6, 0), tmp1(31, 7)) ^ Cat(tmp1(17, 0), tmp1(31, 18)) ^ Cat(Fill(3, 0.U), tmp1(31, 3))
  val tmp2 = SIGMA_MIN1 + inputsWire(9) + SIGMA_MIN0 + inputsWire(0)

  if (NO_PE <= 16) {          //1时表示逻辑运算后输出
    when(io.cfg === 1.U) {
      io.outputs(0) := tmp2
      io.outputs(16) := tmp2
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    } .otherwise {
      io.outputs(0) := inputsWire(0)
      io.outputs(16) := inputsWire(0)
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
    }
  } else {
      io.outputs(0) := tmp2
      io.outputs(16) := tmp2
      for (i <- 1 until 16) {
        io.outputs(i) := inputsWire(i)
      }
  }
}

