package dsa.element

import chisel3._
import chisel3.util._
import dsa.element.ALU.multiport_rom

class DPM_aes(elename: String, in_num: Int, width: Int, aes_type: Int)  extends Module {
  //aes_type:0->aes128,1->aes192,2->aes256
  val out_num = 40 + aes_type * 8
  val nr = 10 + aes_type * 2
  val nk = 4 + aes_type * 2
  override val desiredName = elename
  val io = IO(new Bundle() {
    val inputs = Input(Vec(in_num, UInt(width.W)))  //aes_type->in_num: 0->4, 1->6,2->8
    val outputs = Output(Vec(out_num, UInt(width.W)))
  })

  val DPM_AES = Seq.tabulate(nr)(i => Module(new aes_dpm(32, i, aes_type)))
  for(i <- 0 until in_num) {
    DPM_AES(0).io.inputs(i) := io.inputs(i)
  }
  for(i <- in_num until 8) {
    DPM_AES(0).io.inputs(i) := 0.U
  }


  for(i <- 1 until nr) {
    DPM_AES(i).io.inputs := DPM_AES(i - 1).io.outputs
  }


  for(i <- 0 until nr) {
    io.outputs(i * 4) := DPM_AES(i).io.outputs(0)
    io.outputs(i * 4 + 1) := DPM_AES(i).io.outputs(1)
    io.outputs(i * 4 + 2) := DPM_AES(i).io.outputs(2)
    io.outputs(i * 4 + 3) := DPM_AES(i).io.outputs(3)
  }

}

class aes_dpm(width: Int, NO: Int, aes_type: Int) extends Module {

  val num = 4 + aes_type * 2                          //取最大的值8
  val io = IO(new Bundle() {
    val inputs = Input(Vec(8, UInt(width.W)))       //input数由aes_type控制，0->4，1->6，2->8
    val outputs = Output(Vec(8, UInt(width.W)))    //input数由aes_type控制，0->4，1->6，2->8，输出的前四个参与aes异或运算
  })

  val inputsWire = Wire(Vec(8, UInt(width.W)))
  for (i <- 0 until 8) {
    inputsWire(i) := RegNext(RegNext(RegNext(RegNext(io.inputs(i))))) //aes128计算时需要延迟几个周期进行时钟匹配
//    inputsWire(i) := RegNext(io.inputs(i))
  }


//  val subram0 = Module(new ram(8,8,"E:\\DoctorProject\\dsa-4.2\\src\\resource\\AES_Subword_Data.txt"))
  val subrom0 = Module(new multiport_rom(8,8, 4, 0))
  val Rcon = Seq("h01000000".U,"h02000000".U,"h04000000".U,"h08000000".U,"h10000000".U,"h20000000".U,
    "h40000000".U,"h80000000".U,"h1b000000".U,"h36000000".U,"h6c000000".U,"hd8000000".U,
    "hab000000".U,"h4d000000".U,"h9a000000".U);

  val data = Wire(UInt(32.W))
  if(aes_type == 0) {
    data := inputsWire(3)
  } else if(aes_type == 1) {
    if(NO % 3 == 0) {
      data := inputsWire(5)
    }
    else {
      data := inputsWire(0) ^ inputsWire(1) ^  inputsWire(5)
    }
  } else {
    data := inputsWire(7)
  }

  val subdata = Cat(data(23, 16), data(15, 8), data(7, 0), data(31, 24))
  val data0 = Wire(UInt(8.W))
  val data1 = Wire(UInt(8.W))
  val data2 = Wire(UInt(8.W))
  val data3 = Wire(UInt(8.W))

  if(aes_type == 2 && NO % 2 == 1) {
    data0 := data(7, 0)
    data1 := data(15, 8)
    data2 := data(23, 16)
    data3 := data(31, 24)
  } else {
    data0 := subdata(7, 0)
    data1 := subdata(15, 8)
    data2 := subdata(23, 16)
    data3 := subdata(31, 24)
  }

  subrom0.io.address(0) := data0
  subrom0.io.address(1) := data1
  subrom0.io.address(2) := data2
  subrom0.io.address(3) := data3

  val w0_s = subrom0.io.value(0)
  val w1_s = subrom0.io.value(1)
  val w2_s = subrom0.io.value(2)
  val w3_s = subrom0.io.value(3)



//  val cntwire = Wire(UInt(3.W))
//  val cntReg = RegEnable(cntwire + 1.U, 0.U, true.asBool())
//  cntwire := Mux(cntReg === 3.U, 0.U, cntReg)
//  subrom0.io.address(0) := MuxLookup(cntwire, 0.U, Array(0.U -> data0, 1.U -> data1))
//  subrom0.io.address(1) := MuxLookup(cntwire, 0.U, Array(0.U -> data2, 1.U -> data3))
//  val w0_s = RegEnable(subrom0.io.value(0), cntwire === 0.U)
//  val w1_s = RegEnable(subrom0.io.value(0), cntwire === 1.U)
//  val w2_s = RegEnable(subrom0.io.value(1), cntwire === 0.U)
//  val w3_s = RegEnable(subrom0.io.value(1), cntwire === 1.U)

  val tmp0 = inputsWire(0) ^ Cat(w3_s, w2_s, w1_s, w0_s) ^ Rcon(NO)
//  val tmp0 = Cat(w3_s,w2_s,w1_s,w0_s)
  val tmp1 = inputsWire(1) ^ tmp0
  val tmp2 = inputsWire(2) ^ tmp1
  val tmp3 = inputsWire(3) ^ tmp2


  val tmp4 = Wire(UInt(32.W))
  val tmp5 = Wire(UInt(32.W))
  val tmp6 = Wire(UInt(32.W))
  val tmp7 = Wire(UInt(32.W))
  if(NO % 3 == 0) {
    tmp4 := inputsWire(0) ^ Cat(w3_s, w2_s, w1_s, w0_s) ^ Rcon(NO - NO / 3)
    tmp5 := inputsWire(1) ^ tmp4
    tmp6 := inputsWire(2) ^ tmp5
    tmp7 := inputsWire(3) ^ tmp6
  } else if(NO % 3 == 1){
    tmp4 := inputsWire(0) ^ inputsWire(5)
    tmp5 := inputsWire(1) ^ tmp4
    tmp6 := inputsWire(2) ^ Cat(w3_s, w2_s, w1_s, w0_s) ^ Rcon(NO - NO / 3)
    tmp7 := inputsWire(3) ^ tmp6
  } else {
    tmp4 := inputsWire(0) ^ inputsWire(5)
    tmp5 := inputsWire(1) ^ tmp4
    tmp6 := inputsWire(2) ^ tmp5
    tmp7 := inputsWire(3) ^ tmp6
  }

  val tmp8 = Wire(UInt(32.W))
  val tmp9 = Wire(UInt(32.W))
  val tmp10 = Wire(UInt(32.W))
  val tmp11 = Wire(UInt(32.W))

  if(NO % 2 == 0) {
    tmp8 := inputsWire(0) ^ Cat(w3_s, w2_s, w1_s, w0_s) ^ Rcon(NO / 2)
    tmp9 := inputsWire(1) ^ tmp8
    tmp10 := inputsWire(2) ^ tmp9
    tmp11 := inputsWire(3) ^ tmp10
  } else {
    tmp8 := inputsWire(0) ^  Cat(w3_s, w2_s, w1_s, w0_s)
    tmp9 := inputsWire(1) ^ tmp8
    tmp10 := inputsWire(2) ^ tmp9
    tmp11 := inputsWire(3) ^ tmp10
  }


  if(aes_type == 0) {
    io.outputs(0) := tmp0
    io.outputs(1) := tmp1
    io.outputs(2) := tmp2
    io.outputs(3) := tmp3
    io.outputs(4) := 0.U
    io.outputs(5) := 0.U
    io.outputs(6) := 0.U
    io.outputs(7) := 0.U
  } else if(aes_type == 1) {
    io.outputs(0) := inputsWire(4)
    io.outputs(1) := inputsWire(5)
    io.outputs(2) := tmp4
    io.outputs(3) := tmp5
    io.outputs(4) := tmp6
    io.outputs(5) := tmp7
    io.outputs(6) := 0.U
    io.outputs(7) := 0.U
  } else {
    io.outputs(0) := inputsWire(4)
    io.outputs(1) := inputsWire(5)
    io.outputs(2) := inputsWire(6)
    io.outputs(3) := inputsWire(7)
    io.outputs(4) := tmp8
    io.outputs(5) := tmp9
    io.outputs(6) := tmp10
    io.outputs(7) := tmp11
  }



}



//class DPM_aes128dec(elename: String, in_num: Int, width: Int)  extends Module {
//  val out_num = 40
//  override val desiredName = elename
//  val io = IO(new Bundle() {
//    val inputs = Input(Vec(in_num, UInt(width.W)))
//    val outputs = Output(Vec(out_num, UInt(width.W)))
//  })
//
//  val nr = 10
//  val DPM_AES128dec = Seq.tabulate(nr)(i => Module(new aesdec_dpm(32,  nr, i)))
//
//  DPM_AES128dec(0).io.inputs := io.inputs
//
//  for(i <- 1 until nr) {
//    DPM_AES128dec(i).io.inputs := DPM_AES128dec(i - 1).io.outputs
//  }
//
//  for(i <- 0 until nr) {
//    io.outputs(i * 4) := DPM_AES128dec(i).io.outputs(0)
//    io.outputs(i * 4 + 1) := DPM_AES128dec(i).io.outputs(1)
//    io.outputs(i * 4 + 2) := DPM_AES128dec(i).io.outputs(2)
//    io.outputs(i * 4 + 3) := DPM_AES128dec(i).io.outputs(3)
//  }
//
//}
//
//class aesdec_dpm(width: Int, nr: Int, NO: Int) extends Module {
//  val io = IO(new Bundle() {
//    val inputs = Input(Vec(40, UInt(width.W)))
//    val outputs = Output(Vec(4, UInt(width.W)))
//  })
//
//  val inputsWire = Wire(Vec(40, UInt(width.W)))
//
//  for (i <- 0 until 40) {
//        inputsWire(i) := RegNext(RegNext(RegNext(RegNext(io.inputs(i))))) //aes128计算时需要延迟几个周期进行时钟匹配
//  }
//
//  io.outputs(0) := inputsWire((nr - NO - 1) * 4)
//  io.outputs(1) := inputsWire((nr - NO - 1) * 4 + 1)
//  io.outputs(2) := inputsWire((nr - NO - 1) * 4 + 2)
//  io.outputs(3) := inputsWire((nr - NO - 1) * 4 + 3)
//
//
//}

