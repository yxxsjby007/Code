package dsa.element.oper_lib

import chisel3._
import chisel3.util._

class oper_libs(in_nums: Int, out_nums: Int, width: Int, NO_PE: Int, alu_type: String) extends Module {

  val io = IO(new Bundle {
    val inputs = Input(Vec(in_nums, UInt(width.W)))
    val outputs = Output(Vec(out_nums, UInt(width.W)))
  })
  val inputsWire = Wire(Vec(in_nums, UInt(width.W)))

  for (i <- 0 until in_nums) {
    inputsWire(i) := RegNext(io.inputs(i))
  }

  val kt = Wire(UInt(32.W))
  val k_ori = Seq("h5A827999".U, "h6ED9EBA1".U, "h8F1BBCDC".U, "hCA62C1D6".U)
  val k = Wire(UInt(32.W))
  if(NO_PE <= 20) {
      k := k_ori(0)
    } else if(20 < NO_PE && NO_PE <= 40) {
      k := k_ori(1)
    }  else if(40 < NO_PE && NO_PE <= 60) {
      k := k_ori(2)
    } else {
      k := k_ori(3)
    }

  val sha1func_res = Wire(UInt(width.W))
  val sha1func_res0 = Wire(UInt(width.W))
  val sha1func_res1 = Wire(UInt(width.W))
  val sha1func_res2 = Wire(UInt(width.W))

    if(NO_PE <= 20) {
      sha1func_res := sha1func_res0
    } else if(20 < NO_PE && NO_PE <= 40) {
      sha1func_res := sha1func_res1
    }  else if(40 < NO_PE && NO_PE <= 60) {
      sha1func_res := sha1func_res2
    } else {
      sha1func_res := sha1func_res1
    }

     //(b&c) | (~b&d)
  sha1func_res0 := (inputsWire(1) & inputsWire(2)) | ((~inputsWire(1)) & inputsWire(3))
  //b^c^d
  sha1func_res1 := inputsWire(1) ^ inputsWire(2) ^ inputsWire(3)
  //(b&c) | (b&d) | (c&d)
  sha1func_res2 := (inputsWire(1) & inputsWire(2)) | (inputsWire(1) & inputsWire(3)) | (inputsWire(2) & inputsWire(3))

  val shift_a = Wire(UInt(width.W))
  val shift_b = Wire(UInt(width.W))
  val tmp_A = Wire(UInt(width.W))
  shift_a := Cat(inputsWire(0)(26, 0), inputsWire(0)(31, 27))
  shift_b := Cat(inputsWire(1)(1, 0), inputsWire(1)(31, 2))
  tmp_A := shift_a + sha1func_res + inputsWire(4) + kt + inputsWire(5)

  if(alu_type == "sha1") {
    io.outputs(0) := tmp_A
    io.outputs(1) := inputsWire(0)
    io.outputs(2) := shift_b
    io.outputs(3) := inputsWire(2)
    io.outputs(4) := inputsWire(3)
  }



  val shiftrow0 = Cat(inputsWire(0)(31, 24), inputsWire(1)(23, 16), inputsWire(2)(15, 8), inputsWire(3)(7, 0))
  val shiftrow1 = Cat(inputsWire(1)(31, 24), inputsWire(2)(23, 16), inputsWire(3)(15, 8), inputsWire(0)(7, 0))
  val shiftrow2 = Cat(inputsWire(2)(31, 24), inputsWire(3)(23, 16), inputsWire(0)(15, 8), inputsWire(1)(7, 0))
  val shiftrow3 = Cat(inputsWire(3)(31, 24), inputsWire(0)(23, 16), inputsWire(1)(15, 8), inputsWire(2)(7, 0))


  def twoTimesFunc(mixinTwo: UInt): UInt = {
    Mux(mixinTwo(7) === 0.U, Cat(mixinTwo(6, 0), 0.U(1.W)), Cat(mixinTwo(6, 0), 0.U(1.W)) ^ "b00011011".U)
  }

  def ThreeTimesFunc(mixinThree: UInt): UInt = {
    Mux(mixinThree(7) === 0.U, Cat(mixinThree(6, 0), 0.U(1.W)) ^ mixinThree, Cat(mixinThree(6, 0), 0.U(1.W)) ^ "b00011011".U ^ mixinThree)
  }


  val w0_mc0 = twoTimesFunc(inputsWire(0)(31, 24)) ^ ThreeTimesFunc(inputsWire(0)(23, 16)) ^ inputsWire(0)(15, 8) ^ inputsWire(0)(7, 0)
  val w0_mc1 = inputsWire(0)(31, 24) ^ twoTimesFunc(inputsWire(0)(23, 16)) ^ ThreeTimesFunc(inputsWire(0)(15, 8)) ^ inputsWire(0)(7, 0)
  val w0_mc2 = inputsWire(0)(31, 24) ^ inputsWire(0)(23, 16) ^ twoTimesFunc(inputsWire(0)(15, 8)) ^ ThreeTimesFunc(inputsWire(0)(7, 0))
  val w0_mc3 = ThreeTimesFunc(inputsWire(0)(31, 24)) ^ inputsWire(0)(23, 16) ^ inputsWire(0)(15, 8) ^ twoTimesFunc(inputsWire(0)(7, 0))

  val mixcolumn = Cat(w0_mc0, w0_mc1, w0_mc2, w0_mc3)




  val xordata = inputsWire(0) ^ inputsWire(1) //输入的第一个值与第二个值异或
  val passdata = inputsWire(0)


  if (NO_PE % 13 == 0 || NO_PE % 13 == 1 || NO_PE % 13 == 2 || NO_PE % 13 == 3) {
    io.outputs(0) := xordata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U

  } else if (NO_PE % 13 == 8) {
    io.outputs(0) := shiftrow0
    io.outputs(1) := shiftrow1
    io.outputs(2) := shiftrow2
    io.outputs(3) := shiftrow3
  } else if ((NO_PE % 13 == 4 || NO_PE % 13 == 5 || NO_PE % 13 == 6 || NO_PE % 13 == 7)) {

    val s_data = Wire(Vec(4, UInt(8.W)))
    s_data(0) := inputsWire(0)(31, 24)
    s_data(1) := inputsWire(0)(23, 16)
    s_data(2) := inputsWire(0)(15, 8)
    s_data(3) := inputsWire(0)(7, 0)

    val subrom = Module(new multiport_rom(8, 8, 4, 0))
    for (i <- 0 until 4) {
      subrom.io.address(i) := s_data(i)
    }
    val subword = Cat(subrom.io.value(0), subrom.io.value(1), subrom.io.value(2), subrom.io.value(3))

    io.outputs(0) := subword
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U

  } else if ((NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) && (NO_PE > 117) && (alu_type == "aes_1")) {
    io.outputs(0) := passdata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  } else if ((NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) && (NO_PE > 143) && (alu_type == "aes_2")) {
    io.outputs(0) := passdata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  } else if ((NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) && (NO_PE > 169) && (alu_type == "aes_3")) {
    io.outputs(0) := passdata
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  } else if (NO_PE % 13 == 9 || NO_PE % 13 == 10 || NO_PE % 13 == 11 || NO_PE % 13 == 12) {
    io.outputs(0) := mixcolumn
    io.outputs(1) := 0.U
    io.outputs(2) := 0.U
    io.outputs(3) := 0.U
  }


}
