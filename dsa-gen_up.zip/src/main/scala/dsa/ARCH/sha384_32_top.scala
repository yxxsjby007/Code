package dsa.ARCH
import dsa.ADL.ADL.{ModuleTrace,EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
import dsa.IR.Info2Xml.dumpIR
class sha384_32_top (dsa : dsa_Param, set_width: Int) extends ModuleTrace("sha384_32"){

  this.typeStr = "dsa"
  this.deviceStr = "sha384_32_dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val DPM = new EleTrace("DPM", TYPE_DPM.id, List("in0","in1","in2","in3","in4","in5","in6","in7","in8","in9","in10","in11","in12","in13","in14","in15",
    "in16","in17","in18","in19", "in20","in21","in22","in23","in24","in25","in26","in27","in28","in29","in30","in31"),
    List("out0", "out1", "out2", "out3", "out4", "out5", "out6", "out7"), List(32, 32, 4, 4, 80, 32))
  addEle(DPM)

  //添加PE3和PE0之间的连接
  for(i <- 1 until 18) {
    addConnect(("PE3", "out" + (i - 1).toString), ("PE0", "in" + i.toString))
  }


  //添加PE.out和OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("PE3", "out" + i.toString), ("OB" + i.toString, "in0"))
  }

  //添加PE之间的连接
  for(j <- 0 until 3) {
    for(i <- 1 until 18) {
      addConnect(("PE" + j.toString, "out" + (i - 1).toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  //添加IB和DPM之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("IB" + i.toString, "out0"), ("DPM", "in" + i.toString))
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until 4) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in0"))
  }

  for(i <- 0 until 4) {
    addConnect(("DPM", "out" + (i + 4).toString), ("PE" + i.toString, "in18"))
  }


  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }



}


object sha384_32_dsaGen {
  val alu_sha384_32_p1 = List(32, 4, 1)
  val alu_sha384_32_p2 = List(32, 4, 2)
  val alu_sha384_32_p3 = List(32, 4, 3)
  val alu_sha384_32_p4 = List(32, 4, 4)

  val alu_p1 = alu_Param("sha384_32", 19, 17, alu_sha384_32_p1, "ALU0")
  val pe_p1 = PEParam(32, "PE0", 1, List(alu_p1))

  val alu_p2 = alu_Param("sha384_32", 19, 17, alu_sha384_32_p2, "ALU1")
  val pe_p2 = PEParam(32, "PE1", 1, List(alu_p2))

  val alu_p3 = alu_Param("sha384_32", 19, 17, alu_sha384_32_p3, "ALU2")
  val pe_p3 = PEParam(32, "PE2", 1, List(alu_p3))

  val alu_p4 = alu_Param("sha384_32", 19, 17, alu_sha384_32_p4, "ALU3")
  val pe_p4 = PEParam(32, "PE3", 1, List(alu_p4))
  //四个PE
  val sha384_32_dsaModule = new sha384_32_top(dsa_Param(4, 32, 16, List(pe_p1,pe_p2,pe_p3,pe_p4)), 32).getModuleInfo()

}

//object sha384_32_dsaGenApp extends App {
//  chisel3.Driver.execute(args, () => topGen(sha384_32_dsaGen.sha384_32_dsaModule, "sha384_32dsa.txt"))
//  dumpIR(sha384_32_dsaGen.sha384_32_dsaModule, "sha384_32dsa.xml", "sha384_32")
//
//}
