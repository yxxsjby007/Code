package dsa.ARCH
import dsa.ADL.ADL.{ModuleTrace,EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
import dsa.IR.Info2Xml.dumpIR
class sm3_top (dsa : dsa_Param, set_width: Int) extends ModuleTrace("sm3" + dsa.PE_num){

  this.typeStr = "dsa"
  this.deviceStr = "sm3_" + dsa.PE_num + "PE_dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val inList = for (i <- 0 until 16) yield {
    "in" + i
  }
  val outList = for (i <- 0 until dsa.PE_num * 2) yield {
    "out" + i
  }
  val DPM = new EleTrace("DPM", TYPE_DPM_sm3.id, inList.toList, outList.toList, List(16, dsa.PE_num, width))
  addEle(DPM)


  //添加PE.out和OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("PE" + (dsa.PE_num - 1), "out" + i.toString), ("OB" + i.toString, "in0"))
  }

  //添加PE之间的连接
  for(j <- 0 until dsa.PE_num - 1) {
    for(i <- 0 until 9) {
      addConnect(("PE" + j.toString, "out" + i.toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  if(dsa.PE_num < 64) {
    for(i <- 0 until 9) {
      addConnect(("PE" + (dsa.PE_num - 1), "out" + i.toString), ("PE0", "in" + i.toString))
    }
  }


  //添加IB和DPM之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("IB" + i.toString, "out0"), ("DPM", "in" + i.toString))
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until dsa.PE_num) {
    addConnect(("DPM", "out" + (2 * i).toString), ("PE" + i.toString, "in9"))
    addConnect(("DPM", "out" + (2 * i + 1).toString), ("PE" + i.toString, "in10"))
  }

  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }
}

object  sm3_dsaGen {
  val pe_num = 1
  val width = 32
  val in_num = 16
  val out_num = 8
  val paramList = for (i <- 1 to pe_num) yield List(width, pe_num, i)
  val pe_p = for (i <- 0 until pe_num) yield {
    val peIndex = "PE" + i
    val aluIndex = "ALU" + i
    val aluParam = alu_Param("sm3", 11, 9, paramList(i), aluIndex)
    PEParam(width, peIndex, 1, List(aluParam))
  }

  val sm3_dsaModule = new sm3_top(dsa_Param(pe_num, in_num, out_num, pe_p.toList), width).getModuleInfo()
}

//object sm3_dsaGenApp extends App {
//  chisel3.Driver.execute(args, () => topGen(sm3_dsaGen.sm3_dsaModule, "sm3_" + sm3_dsaGen.pe_num  + ".txt"))
//  dumpIR(sm3_dsaGen.sm3_dsaModule, "sm3_"+ sm3_dsaGen.pe_num + ".xml", "sm3_" + sm3_dsaGen.pe_num)
//
//}