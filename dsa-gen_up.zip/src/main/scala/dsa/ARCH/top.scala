package dsa.ARCH

import dsa.module.TopModule.topGen

class top {

}


object Main extends App {
  // 检查是否有足够的参数
  // if (args.length < 1) {
  //   println("Usage: need args")
  //   println(args.length)
  //   sys.exit(1)
  // }

  // val arg1 = args(0)

  // arg1 match {
  //   case "sha1" =>
  //     chisel3.Driver.execute(args, () => topGen(sha1_dsaGen.sha1_dsaModule, "sha1_multi_80PE.txt"))
  //   case "md5" =>
  //     chisel3.Driver.execute(args, () => topGen(md5_multi_16PE_dsaGen.md5_multi_dsaModule, "md5_multi_16PE.txt"))
  //   case "sm3" =>
  //     chisel3.Driver.execute(args, () => topGen(sm3_dsaGen.sm3_dsaModule, "sm3_" + sm3_dsaGen.pe_num  + ".txt"))
  //   case "sha256" =>
  //     chisel3.Driver.execute(args, () => topGen(sha256_multi_16PE_dsaGen.sha256_multi_dsaModule, "sha256_multi_16PE.txt"))
  //   case "aes128" =>
  //     chisel3.Driver.execute(args, () => topGen(aes128_dsaGen.aes128_dsaModule, "aes128.txt"))

  //   case _ =>
  //     println("Invalid argument.")
  // }

  chisel3.Driver.execute(args, () => topGen(sha1_dsaGen.sha1_dsaModule, "sha1_multi_80PE.txt"))
  chisel3.Driver.execute(args, () => topGen(md5_multi_16PE_dsaGen.md5_multi_dsaModule, "md5_multi_16PE.txt"))
}
