package dsa.ARCH

import dsa.ADL.ADL.{ModuleTrace,EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
import dsa.IR.Info2Xml.dumpIR
class Template (name: String, dsa : dsa_Param, set_width: Int, dpm: DPM_Param, connect_network: Connect_Params) extends ModuleTrace ("template" + dsa.PE_num){

  this.typeStr = "dsa"
  this.deviceStr = name + dsa.PE_num + "PE_dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val inList = for (i <- 0 until dpm.in_num) yield {
    "in" + i
  }
  val outList = for (i <- 0 until dpm.out_num) yield {
    "out" + i
  }
  val DPM = new EleTrace("DPM", TYPE_DPM_sha1.id, inList.toList, outList.toList, List(dpm.in_num, dpm.out_num, dpm.width))
  addEle(DPM)


  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }


  //添加互连网络
  for(i <- 0 until connect_network.cn_length) {
    addConnect((connect_network.cn(i).Out_obj, "out" + connect_network.cn(i).out_No),
      (connect_network.cn(i).In_obj, "in" + connect_network.cn(i).in_No))

  }


}