package dsa.ARCH

import dsa.ADL.ADL.{ModuleTrace, EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen

class aes128_top(dsa: dsa_Param, set_width: Int) extends ModuleTrace("aes128") {
  this.typeStr = "dsa"
  this.deviceStr = "aes128" + "dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for (i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i), "PE" + i.toString))
  }

  //LM: 添加IB
  for (i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List(width))
    addEle(IB)
  }

  //LM: 添加OB
  for (i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val inList = for (i <- 0 until 4) yield {
    "in" + i
  }
  val outList = for (i <- 0 until 40) yield {
    "out" + i
  }
  val DPM = new EleTrace("DPM", TYPE_DPM_aes.id, inList.toList, outList.toList, List(4, 32, 0))
  addEle(DPM)


  //添加PE.out和OB之间的连接

  for (i <- 0 until dsa.OB_num) {
    addConnect(("PE" + (dsa.PE_num - 4 + i), "out0"), ("OB" + i.toString, "in0"))
  }


  //0,1,2,3PE的输入与OB连接0，1，2，3表示加密数据，4，5，6，7表示key
  for (i <- 0 until 4) {
    addConnect(("IB" + i.toString, "out0"), ("PE" + i.toString, "in0"))
    addConnect(("IB" + (i + 4).toString, "out0"), ("PE" + i.toString, "in1"))
  }

  //OB输入的key连接到DPM
  //添加IB和DPM之间的连接
  for (i <- 0 until 4) {
    addConnect(("IB" + (i + 4).toString, "out0"), ("DPM", "in" + i.toString))
  }


  //添加DPM和PE之间的连接
  for (j <- 0 until 10) {
    for (i <- 0 until 4) {
      addConnect(("DPM", "out" + (j * 4  + i).toString), ("PE" + (13 * j + 13 + i).toString, "in1"))
    }
  }

  //PE0~3输入到PE4~7
  for (j <- 0 until 10) {
    for (i <- 0 until 4) {
      addConnect(("PE" + (j * 13 + i).toString, "out0"), ("PE" + (j * 13 + 4 + i).toString, "in0"))
    }

    //PE4~7的输出连接到PE8
    for(i <- 0 until 4) {
      addConnect(("PE" + (j * 13 + 4 + i).toString, "out0"), ("PE" + (j * 13 + 8).toString, "in" + i.toString))
    }

    //PE8的输出连接到PE9~12的输入
    for (i <- 0 until 4) {
      addConnect(("PE" + (j * 13 + 8).toString, "out" + i.toString), ("PE" + (j * 13 + i + 9).toString, "in0"))
    }


    //PE9~12的输出连接到PE13~16的输入
    for (i <- 0 until 4) {
      addConnect(("PE" + (j * 13 + i + 9).toString, "out0"), ("PE" + (j * 13 + i + 13).toString, "in0"))
    }
  }



  //添加输入与IB之间的连接
  for (i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for (i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }


}

object aes128_dsaGen  {
  val pe_num = 134
  val width = 32
  val in_num = 8
  val out_num = 4
  val paramList = for (i <- 0 until pe_num) yield List(width, i, 0)
  val pe_p = for (i <- 0 until pe_num) yield {
    val peIndex = "PE" + i
    val aluIndex = "ALU" + i
    val aluParam = alu_Param("aes", 4, 4, paramList(i), aluIndex)
    PEParam(width, peIndex, 1, List(aluParam))
  }
  val aes128_dsaModule = new aes128_top(dsa_Param(pe_num, in_num, out_num, pe_p.toList), width).getModuleInfo()

  //chisel3.Driver.execute(args, () => topGen(aes128_dsaModule, "aes128" +  ".txt"))


}

