package dsa.ARCH
import dsa.ADL.ADL.{EleTrace, ModuleTrace}
import dsa.ARCH.md5_sha1Gen.{alu_p0_0, alu_p0_1}
import dsa.IR.Info2Xml.dumpIR
import dsa.module.PE
import dsa.module.TopModule.topGen
import dsa.module.dsaParam.{PEParam, alu_Param, dsa_Param}
import dsa.parameter.EleType.{TYPE_DPM, TYPE_IB, TYPE_OB}
class hash_top (dsa: dsa_Param, set_width: Int) extends ModuleTrace("hash"){
  this.typeStr = "dsa"
  this.deviceStr = "hash_dsa"
  this.width = set_width
  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val DPM = new EleTrace("DPM", TYPE_DPM.id, List("in0","in1","in2","in3","in4","in5","in6","in7","in8","in9","in10","in11","in12","in13","in14","in15",
    "in16", "in17", "in18", "in19", "in20", "in21", "in22", "in23", "in24", "in25", "in26", "in27", "in28", "in29", "in30", "in31"),
    List("out0","out1","out2","out3","out4","out5","out6","out7","out8","out9","out10","out11","out12","out13","out14","out15", "out16",
    "out17", "out18", "out19", "out20", "out21", "out22", "out23", "out24", "out25", "out26", "out27", "out28", "out29", "out30", "out31"), List(47, 32, 16, 16, 80, 32))
  addEle(DPM)

  //沒有sm3時候的連接
  //添加PE15和PE0之间的连接
  /*for(i <- 1 until 10) {
    addConnect(("PE15", "out" + (i - 1).toString), ("PE0", "in" + i.toString))
  }

  //添加PE之间的连接
  for(j <- 0 until 15) {
    for(i <- 1 until 10) {
      addConnect(("PE" + j.toString, "out" + (i - 1).toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }
  //添加DPM和PE之间的连接
  for(i <- 0 until 16) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in0"))
  }*/

  //有sm3時候的連接
  //添加PE15和PE0之间的连接
  /*for(i <- 1 until 10) {
    addConnect(("PE15", "out" + (i - 1).toString), ("PE0", "in" + i.toString))
  }

  //添加PE之间的连接
  for(j <- 0 until 15) {
    for(i <- 1 until 10) {
      addConnect(("PE" + j.toString, "out" + (i - 1).toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until 16) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in0"))
    addConnect(("DPM", "out" + (i + 16).toString), ("PE" + i.toString, "in10"))
  }*/

  //存在sha384时候的连接
  //添加PE15和PE0之间的连接
  for(i <- 1 until 18) {
    addConnect(("PE15", "out" + (i - 1).toString), ("PE0", "in" + i.toString))
  }

  //添加PE之间的连接
  for(j <- 0 until 15) {
    for(i <- 1 until 18) {
      addConnect(("PE" + j.toString, "out" + (i - 1).toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until 16) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in0"))
    addConnect(("DPM", "out" + (i + 16).toString), ("PE" + i.toString, "in18"))
  }


  //添加PE.out和OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("PE15", "out" + i.toString), ("OB" + i.toString, "in0"))
  }


  //添加IB和DPM之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("IB" + i.toString, "out0"), ("DPM", "in" + i.toString))
  }

  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }

}

object hash_Gen {
  val alu_p0 = List(63, 32, 16, 1)
  val alu_p1 = List(63, 32, 16, 2)
  val alu_p2 = List(63, 32, 16, 3)
  val alu_p3 = List(63, 32, 16, 4)
  val alu_p4 = List(63, 32, 16, 5)
  val alu_p5 = List(63, 32, 16, 6)
  val alu_p6 = List(63, 32, 16, 7)
  val alu_p7 = List(63, 32, 16, 8)
  val alu_p8 = List(63, 32, 16, 9)
  val alu_p9 = List(63, 32, 16, 10)
  val alu_p10 = List(63, 32,  16, 11)
  val alu_p11 = List(63, 32,  16, 12)
  val alu_p12 = List(63, 32,  16, 13)
  val alu_p13 = List(63, 32,  16, 14)
  val alu_p14 = List(63, 32,  16, 15)
  val alu_p15 = List(63, 32,  16, 16)
  val pe_p0 = PEParam(32, "PE0", 1, List(alu_Param("hash", 19, 17, alu_p0, "ALU0")))
  val pe_p1 = PEParam(32, "PE1", 1, List(alu_Param("hash", 19, 17, alu_p1, "ALU1")))
  val pe_p2 = PEParam(32, "PE2", 1, List(alu_Param("hash", 19, 17, alu_p2, "ALU2")))
  val pe_p3 = PEParam(32, "PE3", 1, List(alu_Param("hash", 19, 17, alu_p3, "ALU3")))
  val pe_p4 = PEParam(32, "PE4", 1, List(alu_Param("hash", 19, 17, alu_p4, "ALU4")))
  val pe_p5 = PEParam(32, "PE5", 1, List(alu_Param("hash", 19, 17, alu_p5, "ALU5")))
  val pe_p6 = PEParam(32, "PE6", 1, List(alu_Param("hash", 19, 17, alu_p6, "ALU6")))
  val pe_p7 = PEParam(32, "PE7", 1, List(alu_Param("hash", 19, 17, alu_p7, "ALU7")))
  val pe_p8 = PEParam(32, "PE8", 1, List(alu_Param("hash", 19, 17, alu_p8, "ALU8")))
  val pe_p9 = PEParam(32, "PE9", 1, List(alu_Param("hash", 19, 17, alu_p9, "ALU9")))
  val pe_p10 = PEParam(32, "PE10", 1, List(alu_Param("hash", 19, 17, alu_p10, "ALU10")))
  val pe_p11 = PEParam(32, "PE11", 1, List(alu_Param("hash", 19, 17, alu_p11, "ALU11")))
  val pe_p12 = PEParam(32, "PE12", 1, List(alu_Param("hash", 19, 17, alu_p12, "ALU12")))
  val pe_p13 = PEParam(32, "PE13", 1, List(alu_Param("hash", 19, 17, alu_p13, "ALU13")))
  val pe_p14 = PEParam(32, "PE14", 1, List(alu_Param("hash", 19, 17, alu_p14, "ALU14")))
  val pe_p15 = PEParam(32, "PE15", 1, List(alu_Param("hash", 19, 17, alu_p15, "ALU15")))

  val hash_dsaModule = new hash_top(dsa_Param(16, 32, 16, List(pe_p0, pe_p1, pe_p2, pe_p3,
    pe_p4, pe_p5, pe_p6, pe_p7, pe_p8, pe_p9, pe_p10, pe_p11, pe_p12, pe_p13, pe_p14, pe_p15)), 32).getModuleInfo()


}


//object hash_dsaGenAPP extends App {
//  chisel3.Driver.execute(args,() => topGen(hash_Gen.hash_dsaModule, "hashdsa.txt"))
//  dumpIR(hash_Gen.hash_dsaModule, "hash_dsa.xml", "hash")
//}
