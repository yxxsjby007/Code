package dsa.ARCH

import dsa.ADL.ADL.{ModuleTrace, EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
import dsa.IR.Info2Xml.dumpIR

class md5_sha1_top(dsa: dsa_Param, set_width: Int) extends ModuleTrace("md5_sha1") {
  this.typeStr = "dsa"
  this.deviceStr = "md5_sha1_dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val DPM = new EleTrace("DPM", TYPE_DPM.id, List("in0","in1","in2","in3","in4","in5","in6","in7","in8","in9","in10","in11","in12","in13","in14","in15"),
    List("out0","out1","out2","out3","out4","out5","out6","out7","out8","out9","out10","out11","out12","out13","out14","out15"), List(3, 16, 16, 16, 80, 32))
  addEle(DPM)


  //添加PE15和PE0之间的连接
  for(i <- 1 until 7) {
    addConnect(("PE15", "out" + (i - 1).toString), ("PE0", "in" + i.toString))
  }

  //添加PE.out和OB之间的连接
  for(i <- 0 until 5) {
    addConnect(("PE15", "out" + i.toString), ("OB" + i.toString, "in0"))
  }

  //添加PE之间的连接
  for(j <- 0 until 15) {
    for(i <- 1 until 7) {
      addConnect(("PE" + j.toString, "out" + (i - 1).toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  //添加IB和DPM之间的连接
  for(i <- 0 until 16) {
    addConnect(("IB" + i.toString, "out0"), ("DPM", "in" + i.toString))
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until 16) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in0"))
  }

  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }


}


object md5_sha1Gen {
  val alu_md5_p0 = List(32, 16, 1)
  val alu_md5_p1 = List(32, 16, 2)
  val alu_md5_p2 = List(32, 16, 3)
  val alu_md5_p3 = List(32, 16, 4)
  val alu_md5_p4 = List(32, 16, 5)
  val alu_md5_p5 = List(32, 16, 6)
  val alu_md5_p6 = List(32, 16, 7)
  val alu_md5_p7 = List(32, 16, 8)
  val alu_md5_p8 = List(32, 16, 9)
  val alu_md5_p9 = List(32, 16, 10)
  val alu_md5_p10 = List(32, 16, 11)
  val alu_md5_p11 = List(32, 16, 12)
  val alu_md5_p12 = List(32, 16, 13)
  val alu_md5_p13 = List(32, 16, 14)
  val alu_md5_p14 = List(32, 16, 15)
  val alu_md5_p15 = List(32, 16, 16)

  val alu_sha1_p0 = List(32, 16, 1)
  val alu_sha1_p1 = List(32, 16, 2)
  val alu_sha1_p2 = List(32, 16, 3)
  val alu_sha1_p3 = List(32, 16, 4)
  val alu_sha1_p4 = List(32, 16, 5)
  val alu_sha1_p5 = List(32, 16, 6)
  val alu_sha1_p6 = List(32, 16, 7)
  val alu_sha1_p7 = List(32, 16, 8)
  val alu_sha1_p8 = List(32, 16, 9)
  val alu_sha1_p9 = List(32, 16, 10)
  val alu_sha1_p10 = List(32, 16, 11)
  val alu_sha1_p11 = List(32, 16, 12)
  val alu_sha1_p12 = List(32, 16, 13)
  val alu_sha1_p13 = List(32, 16, 14)
  val alu_sha1_p14 = List(32, 16, 15)
  val alu_sha1_p15 = List(32, 16, 16)


  val alu_p0_0 = alu_Param("md5", 6, 5, alu_md5_p0, "ALU0")
  val alu_p0_1 = alu_Param("sha1", 7, 6, alu_sha1_p0, "ALU1")
  val pe_p0 = PEParam(32, "PE0", 2, List(alu_p0_0, alu_p0_1))

  val alu_p1_0 = alu_Param("md5", 6, 5, alu_md5_p1, "ALU0")
  val alu_p1_1 = alu_Param("sha1", 7, 6, alu_sha1_p1, "ALU1")
  val pe_p1 = PEParam(32, "PE1", 2, List(alu_p1_0, alu_p1_1))

  val alu_p2_0 = alu_Param("md5", 6, 5, alu_md5_p2, "ALU0")
  val alu_p2_1 = alu_Param("sha1", 7, 6, alu_sha1_p2, "ALU1")
  val pe_p2 = PEParam(32, "PE2", 2, List(alu_p2_0, alu_p2_1))

  val alu_p3_0 = alu_Param("md5", 6, 5, alu_md5_p3, "ALU0")
  val alu_p3_1 = alu_Param("sha1", 7, 6, alu_sha1_p3, "ALU1")
  val pe_p3 = PEParam(32, "PE3", 2, List(alu_p3_0, alu_p3_1))

  val alu_p4_0 = alu_Param("md5", 6, 5, alu_md5_p4, "ALU0")
  val alu_p4_1 = alu_Param("sha1", 7, 6, alu_sha1_p4, "ALU1")
  val pe_p4 = PEParam(32, "PE4", 2, List(alu_p4_0, alu_p4_1))

  val alu_p5_0 = alu_Param("md5", 6, 5, alu_md5_p5, "ALU0")
  val alu_p5_1 = alu_Param("sha1", 7, 6, alu_sha1_p5, "ALU1")
  val pe_p5 = PEParam(32, "PE5", 2, List(alu_p5_0, alu_p5_1))

  val alu_p6_0 = alu_Param("md5", 6, 5, alu_md5_p6, "ALU0")
  val alu_p6_1 = alu_Param("sha1", 7, 6, alu_sha1_p6, "ALU1")
  val pe_p6 = PEParam(32, "PE6", 2, List(alu_p6_0, alu_p6_1))

  val alu_p7_0 = alu_Param("md5", 6, 5, alu_md5_p7, "ALU0")
  val alu_p7_1 = alu_Param("sha1", 7, 6, alu_sha1_p7, "ALU1")
  val pe_p7 = PEParam(32, "PE7", 2, List(alu_p7_0, alu_p7_1))

  val alu_p8_0 = alu_Param("md5", 6, 5, alu_md5_p8, "ALU0")
  val alu_p8_1 = alu_Param("sha1", 7, 6, alu_sha1_p8, "ALU1")
  val pe_p8 = PEParam(32, "PE8", 2, List(alu_p8_0, alu_p8_1))

  val alu_p9_0 = alu_Param("md5", 6, 5, alu_md5_p9, "ALU0")
  val alu_p9_1 = alu_Param("sha1", 7, 6, alu_sha1_p9, "ALU1")
  val pe_p9 = PEParam(32, "PE9", 2, List(alu_p9_0, alu_p9_1))

  val alu_p10_0 = alu_Param("md5", 6, 5, alu_md5_p10, "ALU0")
  val alu_p10_1 = alu_Param("sha1", 7, 6, alu_sha1_p10, "ALU1")
  val pe_p10 = PEParam(32, "PE10", 2, List(alu_p10_0, alu_p10_1))

  val alu_p11_0 = alu_Param("md5", 6, 5, alu_md5_p11, "ALU0")
  val alu_p11_1 = alu_Param("sha1", 7, 6, alu_sha1_p11, "ALU1")
  val pe_p11 = PEParam(32, "PE11", 2, List(alu_p11_0, alu_p11_1))

  val alu_p12_0 = alu_Param("md5", 6, 5, alu_md5_p12, "ALU0")
  val alu_p12_1 = alu_Param("sha1", 7, 6, alu_sha1_p12, "ALU1")
  val pe_p12 = PEParam(32, "PE12", 2, List(alu_p12_0, alu_p12_1))

  val alu_p13_0 = alu_Param("md5", 6, 5, alu_md5_p13, "ALU0")
  val alu_p13_1 = alu_Param("sha1", 7, 6, alu_sha1_p13, "ALU1")
  val pe_p13 = PEParam(32, "PE13", 2, List(alu_p13_0, alu_p13_1))

  val alu_p14_0 = alu_Param("md5", 6, 5, alu_md5_p14, "ALU0")
  val alu_p14_1 = alu_Param("sha1", 7, 6, alu_sha1_p14, "ALU1")
  val pe_p14 = PEParam(32, "PE14", 2, List(alu_p14_0, alu_p14_1))

  val alu_p15_0 = alu_Param("md5", 6, 5, alu_md5_p15, "ALU0")
  val alu_p15_1 = alu_Param("sha1", 7, 6, alu_sha1_p15, "ALU1")
  val pe_p15 = PEParam(32, "PE15", 2, List(alu_p15_0, alu_p15_1))


  val md5_sha1_dsaModule = new md5_sha1_top(dsa_Param(16, 16, 5, List(pe_p0, pe_p1, pe_p2, pe_p3,
    pe_p4, pe_p5, pe_p6, pe_p7, pe_p8, pe_p9, pe_p10, pe_p11, pe_p12, pe_p13, pe_p14, pe_p15)), 32).getModuleInfo()

}

//object md5_sha1_dsaGenAPP extends App {
//  chisel3.Driver.execute(args,() => topGen(md5_sha1Gen.md5_sha1_dsaModule, "md5_sha1.txt"))
//  dumpIR(md5_sha1Gen.md5_sha1_dsaModule, "md5_sha1dsa.xml", "md5_sha1")
//}