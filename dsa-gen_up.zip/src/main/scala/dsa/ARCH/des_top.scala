package dsa.ARCH
import dsa.ADL.ADL.{ModuleTrace, EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
class des_top(dsa: dsa_Param, set_width: Int) extends ModuleTrace("des") {
  this.typeStr = "dsa"
  this.deviceStr = "des" + "dsa"
  this.width = set_width
  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for (i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i), "PE" + i.toString))
  }

  //LM: 添加IB
  for (i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List(width))
    addEle(IB)
  }

  //LM: 添加OB
  for (i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val inList = for (i <- 0 until 2) yield {
    "in" + i
  }
  val outList = for (i <- 0 until 32) yield {
    "out" + i
  }
  val DPM = new EleTrace("DPM", TYPE_DPM_des.id, inList.toList, outList.toList, List(2, 32))
  addEle(DPM)


  //添加PE.out和OB之间的连接
  for (i <- 0 until dsa.OB_num) {
    addConnect(("PE" + (dsa.PE_num - 1), "out" + i.toString), ("OB" + i.toString, "in0"))
  }


  //IB0,IB1的输入表示输入加密数据，连接到PE0
  //IB3，IB4的输入表示输入的密钥key，连接到DPM
  //添加IB和DPM之间的连接
  for (i <- 0 until 2) {
    addConnect(("IB" + i.toString, "out0"), ("PE0", "in" + i.toString))
    addConnect(("IB" + (i + 2).toString, "out0"), ("DPM", "in" + i.toString))
  }


  //添加DPM和PE之间的连接
  for (j <- 0 until 16) {
    addConnect(("DPM", "out" + (j * 2).toString), ("PE" + (1 + j).toString, "in2"))
    addConnect(("DPM", "out" + (j * 2 + 1).toString), ("PE" + (1 + j).toString, "in3"))
  }

  //添加PE之间的连接，上一级的PE输出输入到下一级PE的输入上
  for(i <-  0 until 16) {
    addConnect(("PE" + i.toString, "out0"), ("PE" + (i + 1).toString, "in0"))
    addConnect(("PE" + i.toString, "out1"), ("PE" + (i + 1).toString, "in1"))
  }




  //添加输入与IB之间的连接
  for (i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for (i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }


}

object des_dsaGen extends App {
  val pe_num = 17
  val width = 32
  val in_num = 4
  val out_num = 2
  val paramList = for (i <- 0 until pe_num) yield List(width, i)
  val pe_p = for (i <- 0 until pe_num) yield {
    val peIndex = "PE" + i
    val aluIndex = "ALU" + i
    val aluParam = alu_Param("des", 4, 2, paramList(i), aluIndex)
    PEParam(width, peIndex, 1, List(aluParam))
  }
  val des_dsaModule = new des_top(dsa_Param(pe_num, in_num, out_num, pe_p.toList), width).getModuleInfo()

  chisel3.Driver.execute(args, () => topGen(des_dsaModule, "des" +  ".txt"))


}


