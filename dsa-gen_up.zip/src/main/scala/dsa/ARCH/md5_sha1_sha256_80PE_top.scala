package dsa.ARCH
import dsa.ADL.ADL.{ModuleTrace,EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
import dsa.IR.Info2Xml.dumpIR


class md5_sha1_sha256_80PE_top (dsa : dsa_Param, set_width: Int) extends ModuleTrace("md5_sha1_sha256") {
  this.typeStr = "dsa"
  this.deviceStr = "md5_sha1_sha256_80PE_dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val inList = for (i <- 0 until 16) yield {
    "in" + i
  }
  val outList = for (i <- 0 until 80) yield {
    "out" + i
  }
  val DPM = new EleTrace("DPM", TYPE_DPM_md5_sha1_sha256.id, inList.toList, outList.toList, List(16, 80, 32))
  addEle(DPM)

  //添加PE.out和OB之间的连接
  for(i <- 0 until 8) {
    addConnect(("PE63", "out" + i.toString), ("OB" + i.toString, "in0"))
  }
  for(i <- 8 until 13) {
    addConnect(("PE79", "out" + (i - 8).toString), ("OB" + i.toString, "in0"))
  }

  //添加PE之间的连接
  for(j <- 0 until dsa.PE_num - 1) {
    for(i <- 0 until dsa.peParams(0).alu_Params(0).out_num) {
      addConnect(("PE" + j.toString, "out" + i.toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  //添加IB和DPM之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("IB" + i.toString, "out0"), ("DPM", "in" + i.toString))
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until dsa.PE_num) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in8"))
  }

  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }



}

object md5_sha1_sha256_80PE_dsaGen {

  val paramList = for (i <- 1 to 80) yield List(32, 80, i)
  val pe_p = for (i <- 0 until 80) yield {
    val peIndex = "PE" + i
    val aluIndex = "ALU" + i
    val aluParam = alu_Param("md5_sha1_sha256", 9, 8, paramList(i), aluIndex)
    PEParam(32, peIndex, 1, List(aluParam))
  }

  val md5_sha1_sha256_dsaModule = new md5_sha1_sha256_80PE_top(dsa_Param(80, 16, 13, pe_p.toList), 32).getModuleInfo()

}

//object md5_sha1_sha256_80PE_dsaGenApp extends App {
//  chisel3.Driver.execute(args, () => topGen(md5_sha1_sha256_80PE_dsaGen.md5_sha1_sha256_dsaModule, "md5_sha1_sha256dsa_80PE.txt"))
//  dumpIR(md5_sha1_sha256_80PE_dsaGen.md5_sha1_sha256_dsaModule, "md5_sha1_sha256dsa_80PE.xml", "md5_sha1_sha256_80PE")
//
//}