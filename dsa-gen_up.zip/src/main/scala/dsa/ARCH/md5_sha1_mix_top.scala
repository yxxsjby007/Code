package dsa.ARCH
import dsa.ADL.ADL.{ModuleTrace, EleTrace}
import dsa.module.dsaParam._
import dsa.module.PE
import dsa.parameter.EleType._
import dsa.module.TopModule.topGen
import dsa.IR.Info2Xml.dumpIR

class md5_sha1_mix_top(dsa: dsa_Param, set_width: Int) extends ModuleTrace("md5_sha1_mix") {
  this.typeStr = "dsa"
  this.deviceStr = "md5_sha1_mix_dsa"
  this.width = set_width

  //添加输入
  val inPortsList = (0 until dsa.IB_num).map("in" + _.toString).toList
  this.inPorts = inPortsList

  //LM: 添加输出
  val outPortsList = (0 until dsa.OB_num).map("out" + _.toString).toList
  this.outPorts = outPortsList

  //添加PE
  for(i <- 0 until dsa.PE_num) {
    addModule(PE(dsa.peParams(i),"PE" + i.toString))
  }

  //LM: 添加IB
  for(i <- 0 until dsa.IB_num) {
    val IB = new EleTrace("IB" + i.toString, TYPE_IB.id, List("in0"), List("out0"), List( width))
    addEle(IB)
  }

  //LM: 添加OB
  for(i <- 0 until dsa.OB_num) {
    val OB = new EleTrace("OB" + i.toString, TYPE_OB.id, List("in0"), List("out0"), List(1, width))
    addEle(OB)
  }

  //添加DPM
  val DPM = new EleTrace("DPM", TYPE_DPM.id, List("in0","in1","in2","in3","in4","in5","in6","in7","in8","in9","in10","in11","in12","in13","in14","in15"),
    List("out0","out1","out2","out3","out4","out5","out6","out7","out8","out9","out10","out11","out12","out13","out14","out15"), List(3, 16, 16, 16, 80, 32))
  addEle(DPM)


  //添加PE15和PE0之间的连接
  for(i <- 1 until 7) {
    addConnect(("PE15", "out" + (i - 1).toString), ("PE0", "in" + i.toString))
  }

  //添加PE.out和OB之间的连接
  for(i <- 0 until 5) {
    addConnect(("PE15", "out" + i.toString), ("OB" + i.toString, "in0"))
  }

  //添加PE之间的连接
  for(j <- 0 until 15) {
    for(i <- 1 until 7) {
      addConnect(("PE" + j.toString, "out" + (i - 1).toString), ("PE" + (j + 1).toString, "in" + i.toString))
    }
  }

  //添加IB和DPM之间的连接
  for(i <- 0 until 16) {
    addConnect(("IB" + i.toString, "out0"), ("DPM", "in" + i.toString))
  }

  //添加DPM和PE之间的连接
  for(i <- 0 until 16) {
    addConnect(("DPM", "out" + i.toString), ("PE" + i.toString, "in0"))
  }

  //添加输入与IB之间的连接
  for(i <- 0 until dsa.IB_num) {
    addConnect(("this", "in" + i.toString), ("IB" + i.toString, "in0"))
  }

  //添加输出与OB之间的连接
  for(i <- 0 until dsa.OB_num) {
    addConnect(("OB" + i.toString, "out0"), ("this", "out" + i.toString))
  }
}

object md5_sha1_mixGen {
  val  alu_md5_sha1_mix_p0 = List(32, 16, 0, 1,
    0, 4, 8, 12, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    0, 16, 32, 48, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)


  val alu_md5_sha1_mix_p1 = List(32, 16, 0, 1,
    1,  5,   9, 13,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15,
    1,  17, 33, 49, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p2 = List(32, 16, 0, 1,
    2, 6, 10, 14, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    2, 18, 34, 50, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p3 = List(32, 16, 0, 1,
    3, 7, 11, 15, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    3, 19, 35, 51, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p4 = List(32, 16, 0, 1,
    0, 4, 8, 12, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    4, 20, 36, 52, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p5 = List(32, 16, 0, 1,
    1, 5, 9, 13, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    5, 21, 37, 53, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p6 = List(32, 16, 0, 1,
    2, 6, 10, 14, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    6, 22, 38, 54, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p7 = List(32, 16, 0, 1,
    3, 7, 11, 15, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    7, 23, 39, 55, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p8 = List(32, 16, 0, 1,
    0, 4, 8, 12, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    8, 24, 40, 56, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p9 = List(32, 16, 0, 1,
    1, 5, 9, 13, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    9, 25, 41, 57, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p10 = List(32, 16, 0, 1,
    2, 6, 10, 14, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    10, 26, 42, 58, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p11 = List(32, 16, 0, 1,
    3, 7, 11, 15, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    11, 27, 43, 59, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p12 = List(32, 16, 0, 1,
    0, 4, 8, 12, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    12, 28, 44, 60, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p13 = List(32, 16, 0, 1,
    1, 5, 9, 13, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    13, 29, 45, 61, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p14 = List(32, 16, 0, 1,
    2, 6, 10, 14, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    14, 30, 46, 62, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)

  val alu_md5_sha1_mix_p15 = List(32, 16, 0, 1,
    3,  7, 11, 15, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
    15, 31, 47, 63, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60,
    16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3)


  val alu_p0 = alu_Param("md5_sha1", 7, 6 , alu_md5_sha1_mix_p0, "ALU0")
  val pe_p0 = PEParam(32, "PE0", 1, List(alu_p0))

  val alu_p1 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p1, "ALU0")
  val pe_p1 = PEParam(32, "PE1", 1, List(alu_p1))

  val alu_p2 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p2, "ALU0")
  val pe_p2 = PEParam(32, "PE2", 1, List(alu_p2))

  val alu_p3 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p3, "ALU0")
  val pe_p3 = PEParam(32, "PE3", 1, List(alu_p3))

  val alu_p4 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p4, "ALU0")
  val pe_p4 = PEParam(32, "PE4", 1, List(alu_p4))

  val alu_p5 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p5, "ALU0")
  val pe_p5 = PEParam(32, "PE5", 1, List(alu_p5))

  val alu_p6 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p6, "ALU0")
  val pe_p6 = PEParam(32, "PE6", 1, List(alu_p6))

  val alu_p7 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p7, "ALU0")
  val pe_p7 = PEParam(32, "PE7", 1, List(alu_p7))

  val alu_p8 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p8, "ALU0")
  val pe_p8 = PEParam(32, "PE8", 1, List(alu_p8))

  val alu_p9 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p9, "ALU0")
  val pe_p9 = PEParam(32, "PE9", 1, List(alu_p9))

  val alu_p10 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p10, "ALU0")
  val pe_p10 = PEParam(32, "PE10", 1, List(alu_p10))

  val alu_p11 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p11, "ALU0")
  val pe_p11 = PEParam(32, "PE11", 1, List(alu_p11))

  val alu_p12 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p12, "ALU0")
  val pe_p12 = PEParam(32, "PE12", 1, List(alu_p12))

  val alu_p13 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p13, "ALU0")
  val pe_p13 = PEParam(32, "PE13", 1, List(alu_p13))

  val alu_p14= alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p14, "ALU0")
  val pe_p14 = PEParam(32, "PE14", 1, List(alu_p14))

  val alu_p15 = alu_Param("md5_sha1", 7, 6, alu_md5_sha1_mix_p0, "ALU0")
  val pe_p15 = PEParam(32, "PE15", 1, List(alu_p15))

  val md5_sha1_mix_dsaModule = new md5_sha1_mix_top(dsa_Param(16, 16, 5, List(pe_p0, pe_p1, pe_p2, pe_p3,
    pe_p4, pe_p5, pe_p6, pe_p7, pe_p8, pe_p9, pe_p10, pe_p11, pe_p12, pe_p13, pe_p14, pe_p15)), 32).getModuleInfo()


}

//object md5_sha1_mix_dsaGenApp extends App {
//  chisel3.Driver.execute(args,() => topGen(md5_sha1_mixGen.md5_sha1_mix_dsaModule, "md5_sha1_mix.txt"))
//  dumpIR(md5_sha1_mixGen.md5_sha1_mix_dsaModule, "md5_sha1_mix_dsa.xml", "md5_sha1_mix")
//}