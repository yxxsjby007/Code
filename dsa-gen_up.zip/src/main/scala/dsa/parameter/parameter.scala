package dsa.parameter
import chisel3._
import chisel3.util._
import dsa.element.ALU.OpInfo
import dsa.element.ALU.OpInfo.{getALUinNum, getALUoutNum}

object  EleType extends Enumeration {
  type EleType = Value

  val TYPE_ALU,
  TYPE_hash,
  TYPE_md5,
  TYPE_sha1,
  TYPE_sha224,
  TYPE_sha256,
  TYPE_sha512,
  TYPE_sm3,
  TYPE_sha384_32,
  TYPE_md5_sha1,
  TYPE_DPM,
  TYPE_DPM_new,
  TYPE_DPM_md5_sha1_sha256,
  TYPE_DPM_md5_sha1_sha256_2cycle,
  TYPE_Multiplexer,
  TYPE_MultiplexerR,
  TYPE_IB,
  TYPE_OB,
  TYPE_IO,
  TYPE_sha1_2cycle,
  TYPE_sha1_new,
  TYPE_sha1_multi,
  TYPE_sha256_multi,
  TYPE_md5_multi,
  TYPE_DPM_sha1_multi,
  TYPE_DPM_sha1,
  TYPE_DPM_sha256,
  TYPE_DPM_sha512,
  TYPE_DPM_sm3,
  TYPE_DPM_md5,
  TYPE_DPM_sha256_multi,
  TYPE_DPM_md5_multi,
  TYPE_sha1_regout,
  TYPE_md5_new,
  TYPE_sha256_new,
  TYPE_md5_sha1_sha256,
  TYPE_md5_sha1_sha256_2cycle,
  TYPE_aes,
  TYPE_DPM_aes,
  TYPE_Module= Value
  val eleTypeNum = this.values.size - 2
}


object EleTypeFun {
  def getEleCfgW (eleType : Int , elePar : List[Int]) : Int = {
    EleType(eleType) match {
      case EleType.TYPE_Multiplexer => log2Up( elePar(0))
      case EleType.TYPE_DPM => 7
      case EleType.TYPE_DPM_new => 0
      case EleType.TYPE_DPM_md5_sha1_sha256 => 2
      case EleType.TYPE_DPM_md5_sha1_sha256_2cycle => 2
      case EleType.TYPE_hash => 5
      case EleType.TYPE_md5 => 1
      case EleType.TYPE_sha1_2cycle => 1
      case EleType.TYPE_sha1_new => 0
      case EleType.TYPE_sha1_multi => 3
      case EleType.TYPE_sha256_multi => 3
      case EleType.TYPE_md5_multi => 3
      case EleType.TYPE_DPM_sha1_multi => elePar(1)
      case EleType.TYPE_DPM_sha1 => 1
      case EleType.TYPE_DPM_sha256 => 1
      case EleType.TYPE_DPM_sha512 => 2
      case EleType.TYPE_DPM_sm3 => 2
      case EleType.TYPE_DPM_md5 => 1
      case EleType.TYPE_DPM_sha256_multi => elePar(1)
      case EleType.TYPE_DPM_md5_multi => elePar(1)
      case EleType.TYPE_sha1_regout => 0
      case EleType.TYPE_md5_new => 0
      case EleType.TYPE_sha256_new => 0
      case EleType.TYPE_md5_sha1_sha256 => 2
      case EleType.TYPE_md5_sha1_sha256_2cycle => 2
      case EleType.TYPE_sha1 => 1
      case EleType.TYPE_sha512 => 1
      case EleType.TYPE_sha224 => 1
      case EleType.TYPE_sha256 => 1
      case EleType.TYPE_sm3 => 1
      case EleType.TYPE_sha384_32 => 1
      case EleType.TYPE_md5_sha1 => 2
      case EleType.TYPE_aes => 0
      case EleType.TYPE_DPM_aes => 0
      case EleType.TYPE_MultiplexerR => log2Up( elePar(0))
      case EleType.TYPE_IB => 0
      case EleType.TYPE_OB => log2Up( elePar(0))
    }
  }

  def eleTypeName(eleType : Int) : String = {
    EleType(eleType) match {
      case EleType.TYPE_ALU => "ALU"
      case EleType.TYPE_md5 => "ALU"
      case EleType.TYPE_sha1_2cycle => "ALU"
      case EleType.TYPE_sha1_new => "ALU"
      case EleType.TYPE_sha1_multi => "ALU"
      case EleType.TYPE_sha256_multi => "ALU"
      case EleType.TYPE_md5_multi => "ALU"
      case EleType.TYPE_sha1_regout => "ALU"
      case EleType.TYPE_md5_new => "ALU"
      case EleType.TYPE_sha256_new => "ALU"
      case EleType.TYPE_md5_sha1_sha256 => "ALU"
      case EleType.TYPE_md5_sha1_sha256_2cycle => "ALU"
      case EleType.TYPE_sha1 => "ALU"
      case EleType.TYPE_sha512 => "ALU"
      case EleType.TYPE_md5_sha1 => "ALU"
      case EleType.TYPE_hash => "ALU"
      case EleType.TYPE_sha224 => "ALU"
      case EleType.TYPE_sm3 => "ALU"
      case EleType.TYPE_aes => "ALU"
      case EleType.TYPE_sha384_32 => "ALU"
      case EleType.TYPE_sha256 => "ALU"
      case EleType.TYPE_Multiplexer => "MUX"
      case EleType.TYPE_MultiplexerR => "MUXR"
      case EleType.TYPE_IB => "IB"
      case EleType.TYPE_OB => "OB"
      case EleType.TYPE_DPM => "DPM"
      case EleType.TYPE_DPM_new => "DPM"
      case EleType.TYPE_DPM_sha1_multi => "DPM"
      case EleType.TYPE_DPM_sha1 => "DPM"
      case EleType.TYPE_DPM_sha256 => "DPM"
      case EleType.TYPE_DPM_sha512 => "DPM"
      case EleType.TYPE_DPM_sm3 => "DPM"
      case EleType.TYPE_DPM_md5 => "DPM"
      case EleType.TYPE_DPM_aes => "DPM"
      case EleType.TYPE_DPM_sha256_multi => "DPM"
      case EleType.TYPE_DPM_md5_multi => "DPM"
      case EleType.TYPE_DPM_md5_sha1_sha256 => "DPM"
      case EleType.TYPE_DPM_md5_sha1_sha256_2cycle => "DPM"
    }
  }

  def getEleInNum(eleType : Int , elePar : List[Int]) : Int = {
    EleType(eleType) match {
      case EleType.TYPE_ALU => elePar(0)    //第一个参数存放输入端口数
      case EleType.TYPE_md5 => elePar(0)      //第一个参数存放输入端口数
      case EleType.TYPE_sha1_2cycle => elePar(0)
      case EleType.TYPE_sha1_new => elePar(0)
      case EleType.TYPE_sha1_multi => elePar(0)
      case EleType.TYPE_md5_multi => elePar(0)
      case EleType.TYPE_sha256_multi => elePar(0)
      case EleType.TYPE_DPM_sha1_multi => elePar(0)
      case EleType.TYPE_DPM_sha1 => elePar(0)
      case EleType.TYPE_DPM_sha256 => elePar(0)
      case EleType.TYPE_DPM_sha512 => elePar(0)
      case EleType.TYPE_DPM_sm3 => elePar(0)
      case EleType.TYPE_DPM_md5 => elePar(0)
      case EleType.TYPE_DPM_sha256_multi => elePar(0)
      case EleType.TYPE_DPM_md5_multi => elePar(0)
      case EleType.TYPE_sha1_regout => elePar(0)
      case EleType.TYPE_md5_new => elePar(0)
      case EleType.TYPE_aes => elePar(0)
      case EleType.TYPE_sha256_new => elePar(0)
      case EleType.TYPE_md5_sha1_sha256 => elePar(0)
      case EleType.TYPE_md5_sha1_sha256_2cycle => elePar(0)
      case EleType.TYPE_sha1 => elePar(0)
      case EleType.TYPE_sha512 => elePar(0)
      case EleType.TYPE_sha224 => 10
      case EleType.TYPE_sm3 => 11
      case EleType.TYPE_sha384_32 => 19
      case EleType.TYPE_sha256 => 10
      case EleType.TYPE_md5_sha1 => elePar(0)
      case EleType.TYPE_DPM => elePar(1)
      case EleType.TYPE_DPM_aes => elePar(0)
      case EleType.TYPE_DPM_new => elePar(0)
      case EleType.TYPE_DPM_md5_sha1_sha256 => elePar(0)
      case EleType.TYPE_DPM_md5_sha1_sha256_2cycle => elePar(0)
      case EleType.TYPE_hash => OpInfo.fuget(elePar(0)).map(getALUinNum(_)).max
      case EleType.TYPE_Multiplexer => elePar(0)
      case EleType.TYPE_MultiplexerR => elePar(0)
      case EleType.TYPE_IB => 1
      case EleType.TYPE_OB => elePar(0)
    }
  }

  def getEleOutNum(eleType: Int, elePar: List[Int]): Int = {
    EleType(eleType) match {
      case EleType.TYPE_md5 => 5       //第二个参数存放输出端口数
      case EleType.TYPE_sha1 => 6
      case EleType.TYPE_sha1_2cycle => 6
      case EleType.TYPE_sha1_new => 4
      case EleType.TYPE_sha1_multi => 5
      case EleType.TYPE_sha256_multi => 8
      case EleType.TYPE_md5_multi => 4
      case EleType.TYPE_sha1_regout => 4
      case EleType.TYPE_md5_new => 5
      case EleType.TYPE_sha256_new => 8
      case EleType.TYPE_md5_sha1_sha256 => 8
      case EleType.TYPE_md5_sha1_sha256_2cycle => 8
      case EleType.TYPE_md5_sha1 => 5
      case EleType.TYPE_sha224 => 9
      case EleType.TYPE_sha512 => 9
      case EleType.TYPE_aes => elePar(1)
      case EleType.TYPE_DPM_aes => elePar(1)
      case EleType.TYPE_sm3 => 9
      case EleType.TYPE_sha384_32 => 17
      case EleType.TYPE_sha256 => 9
      case EleType.TYPE_DPM => OpInfo.fuget(elePar(0)).map(OpInfo.getDPMoutNum(_)).max * elePar(3)
      case EleType.TYPE_DPM_new => 80
      case EleType.TYPE_DPM_sha1_multi => elePar(1)
      case EleType.TYPE_DPM_sha1 => elePar(1)
      case EleType.TYPE_DPM_sha256 => elePar(1)
      case EleType.TYPE_DPM_sha512 => elePar(1)
      case EleType.TYPE_DPM_sm3 => elePar(1) * 2
      case EleType.TYPE_DPM_md5 => elePar(1)
      case EleType.TYPE_DPM_sha256_multi => elePar(1)
      case EleType.TYPE_DPM_md5_multi => elePar(1)
      case EleType.TYPE_DPM_md5_sha1_sha256 => 80
      case EleType.TYPE_DPM_md5_sha1_sha256_2cycle => 80
      case EleType.TYPE_hash => OpInfo.fuget(elePar(0)).map(getALUoutNum(_)).max
      case EleType.TYPE_Multiplexer => 1
      case EleType.TYPE_MultiplexerR => 1
      case EleType.TYPE_IB => 1
      case EleType.TYPE_OB => 1
    }
  }

  def getEleWidth(eleType: Int, elePar: List[Int]): Int = {
    EleType(eleType) match {
      case EleType.TYPE_ALU => elePar(2)      //第二个参数存放位宽
      case EleType.TYPE_md5 => elePar(2)      //第二个参数存放位宽
      case EleType.TYPE_sha1 => elePar(2)
      case EleType.TYPE_sha1_2cycle => elePar(2)
      case EleType.TYPE_sha1_new => elePar(2)
      case EleType.TYPE_sha1_multi => elePar(2)
      case EleType.TYPE_sha256_multi => elePar(2)
      case EleType.TYPE_md5_multi => elePar(2)
      case EleType.TYPE_sha1_regout => elePar(2)
      case EleType.TYPE_sha256_new => elePar(2)
      case EleType.TYPE_md5_sha1_sha256 => elePar(2)
      case EleType.TYPE_md5_sha1_sha256_2cycle => elePar(2)
      case EleType.TYPE_md5_new => elePar(2)
      case EleType.TYPE_sha224 => elePar(2)
      case EleType.TYPE_sha512 => elePar(2)
      case EleType.TYPE_sm3 => elePar(2)
      case EleType.TYPE_sha384_32 => elePar(2)
      case EleType.TYPE_sha256 => elePar(2)
      case EleType.TYPE_md5_sha1 => elePar(2)
      case EleType.TYPE_DPM => elePar(5)      //第二个参数存放位宽
      case EleType.TYPE_DPM_new => elePar(2)
      case EleType.TYPE_DPM_sha1_multi => elePar(2)
      case EleType.TYPE_DPM_sha1 => elePar(2)
      case EleType.TYPE_DPM_sha256 => elePar(2)
      case EleType.TYPE_DPM_sha512 => elePar(2)
      case EleType.TYPE_DPM_sm3 => elePar(2)
      case EleType.TYPE_DPM_md5 => elePar(2)
      case EleType.TYPE_DPM_md5_multi => elePar(2)
      case EleType.TYPE_DPM_sha256_multi => elePar(2)
      case EleType.TYPE_DPM_md5_sha1_sha256 => elePar(2)
      case EleType.TYPE_DPM_md5_sha1_sha256_2cycle => elePar(2)
      case EleType.TYPE_hash => elePar(1)
      case EleType.TYPE_Multiplexer =>  elePar(1)
      case EleType.TYPE_MultiplexerR =>  elePar(1)
      case EleType.TYPE_IB => elePar(0)
      case EleType.TYPE_OB => elePar(1)
      case EleType.TYPE_aes => elePar(2)
      case EleType.TYPE_DPM_aes => elePar(2)
    }
  }

  def getElePortName (eleType: Int, isIn : Boolean , num : Int) : String = {
    eleType match {
      case _ =>
        if(isIn){
          "in" + num
        } else {
          "out" + num
        }
    }
  }
}

object Param {
  val cfgDataW = 31
  val dataW = 32
  val pe_cfgwidth = 1
  val pe_cyclewidth = 7
}
