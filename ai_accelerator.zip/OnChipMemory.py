from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class OnChipMemory(ClockedObject):
    type = 'OnChipMemory'
    cxx_header = "ai_accelerator/on_chip_memory.hh"
    cxx_class = "gem5::OnChipMemory"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    size = Param.MemorySize("1MB", "Size")
    bandwidth = Param.MemoryBandwidth("1GB/s", "Bandwidth")
    latency = Param.Latency("10ns", "Latency")
    num_banks = Param.Unsigned(4, "Number of banks")
    
    # 添加需要的参数
    access_latency = Param.Cycles(10, "Memory access latency in cycles")
    port_width = Param.Unsigned(64, "Width of memory ports in bits")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Memory interface
    port = RequestPort("Port to the memory system")
    
    bank_interleaving = Param.Bool(True, "Enable bank interleaving") 