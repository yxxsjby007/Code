#include "ai_accelerator/ld_unit2.hh"
#include "base/trace.hh"
#include "debug/AIAccelerator.hh"
#include "mem/packet_access.hh"
#include "mem/packet.hh"
#include "sim/system.hh"

namespace gem5
{

LdUnit2::LdUnit2(const LdUnit2Params &params) :
    ClockedObject(params),
    state(IDLE),
    dataBuffer(BUFFER_SIZE / 8),
    memPort("mem_port", this),
    ctrlPort("ctrl_port", this),
    simdPort("simd_port", this),
    scalarPort("scalar_port", this),
    accessLatency(params.accessLatency),
    maxQueueSize(params.maxQueueSize),
    transferWidth(params.transferWidth)
{
    DPRINTF(AIAccelerator, "Created LD Unit2\n");
}

void
LdUnit2::tick()
{
    switch (state) {
        case IDLE:
            if (!requestQueue.empty()) {
                processNextRequest();
            }
            break;
            
        case LOADING:
            // 等待加载完成
            break;
            
        case DISTRIBUTING:
            // 等待分发完成
            break;
    }
}

void
LdUnit2::processNextRequest()
{
    LoadRequest &req = requestQueue.front();
    
    // 创建内存读请求
    RequestPtr memReq = std::make_shared<Request>(
        req.addr, req.size, 0, 0);
    PacketPtr pkt = new Packet(memReq, MemCmd::ReadReq);
    pkt->allocate();
    
    if (memPort.sendTimingReq(pkt)) {
        state = LOADING;
        DPRINTF(AIAccelerator, "Initiated load from address 0x%lx\n", req.addr);
    }
}

void
LdUnit2::distributeData(const LoadRequest &req)
{
    // 创建数据分发请求
    RequestPtr destReq = std::make_shared<Request>(0, req.size, 0, 0);
    PacketPtr pkt = new Packet(destReq, MemCmd::WriteReq);
    pkt->allocate();
    memcpy(pkt->getPtr<uint8_t>(), dataBuffer.data(), req.size);
    
    bool success = false;
    switch (req.destId) {
        case 0:  // Controller
            success = ctrlPort.sendTimingReq(pkt);
            break;
        case 1:  // SIMD Vector Core
            success = simdPort.sendTimingReq(pkt);
            break;
        case 2:  // Scalar Core
            success = scalarPort.sendTimingReq(pkt);
            break;
    }
    
    if (success) {
        state = DISTRIBUTING;
        DPRINTF(AIAccelerator, "Distributing data to destination %d\n",
                req.destId);
    } else {
        delete pkt;
    }
}

void
LdUnit2::scheduleResponse(PacketPtr pkt, Tick delay)
{
    auto event = new EventFunctionWrapper(
        [this, pkt]() {
            // 不需要处理响应，因为RequestPort不发送响应
            // 只需要处理请求完成后的操作
            if (pkt->isRead()) {
                // 内存读取完成
                state = IDLE;
            } else {
                // 数据分发完成
                requestQueue.pop();
                state = IDLE;
            }
            delete pkt;
        },
        name());
    schedule(event, curTick() + delay);
}

void
LdUnit2::initiateLoad(uint64_t addr, size_t size, int destId)
{
    if (hasSpace()) {
        LoadRequest req;
        req.addr = addr;
        req.size = size;
        req.destId = destId;
        requestQueue.push(req);
        DPRINTF(AIAccelerator, "Queued load request from address 0x%lx to dest %d\n",
                addr, destId);
    }
}

Port &
LdUnit2::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "mem_port") {
        return memPort;
    } else if (if_name == "ctrl_port") {
        return ctrlPort;
    } else if (if_name == "simd_port") {
        return simdPort;
    } else if (if_name == "scalar_port") {
        return scalarPort;
    } else {
        return ClockedObject::getPort(if_name, idx);
    }
}

bool
LdUnit2::LoadPort::recvTimingResp(PacketPtr pkt)
{
    if (pkt->isRead()) {
        // 从内存读取的响应
        memcpy(owner->dataBuffer.data(),
               pkt->getConstPtr<uint8_t>(),
               pkt->getSize());
        
        // 开始分发数据
        LoadRequest &req = owner->requestQueue.front();
        owner->distributeData(req);
        
        delete pkt;
        return true;
    } else {
        // 数据分发完成
        owner->requestQueue.pop();
        owner->state = IDLE;
        
        delete pkt;
        return true;
    }
}

void
LdUnit2::LoadPort::recvReqRetry()
{
    // 重试请求
    if (owner->state == LOADING) {
        owner->processNextRequest();
    } else if (owner->state == DISTRIBUTING) {
        owner->distributeData(owner->requestQueue.front());
    }
}

} // namespace gem5 