from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class DataFormatConverter(ClockedObject):
    type = 'DataFormatConverter'
    cxx_header = "ai_accelerator/data_format_converter.hh"
    cxx_class = "gem5::DataFormatConverter"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    input_formats = VectorParam.String(["FP32", "FP16", "INT8"], "Supported input formats")
    output_formats = VectorParam.String(["FP32", "FP16", "INT8"], "Supported output formats")
    latency = Param.Latency("10ns", "Conversion latency")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    bandwidth = Param.UInt32(8, "Number of elements per cycle")
    support_fp16_to_fp32 = Param.Bool(True, "Support FP16 to FP32 conversion")
    support_fp32_to_fp16 = Param.Bool(True, "Support FP32 to FP16 conversion")
    support_int8_to_fp16 = Param.Bool(True, "Support INT8 to FP16 conversion")
    support_int8_to_fp32 = Param.Bool(True, "Support INT8 to FP32 conversion")
    support_bf16 = Param.Bool(True, "Support BF16 format conversions") 