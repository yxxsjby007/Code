#ifndef __AI_ACCELERATOR_AI_ACCELERATOR_HH__
#define __AI_ACCELERATOR_AI_ACCELERATOR_HH__

#include "params/AIAccelerator.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include "base/types.hh"
#include "base/statistics.hh"
#include <queue>

namespace gem5
{

class AIAccelerator : public ClockedObject
{
  private:
    // 内存接口
    class AccPort : public RequestPort
    {
      public:
        AccPort(const std::string &name, AIAccelerator *owner) :
            RequestPort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingResp(PacketPtr pkt);
        void recvReqRetry();
        
      private:
        AIAccelerator *owner;
    };

    AccPort port;
    
    // 子组件指针
    AIController *controller;
    LdStUnit *ldStUnit;
    OnChipMemory *onChipMemory;
    TABuffer *taBuffer;
    TensorCore *tensorCore;
    Buffer *resultBuffer;
    LdUnit2 *ldUnit2;
    SIMDVectorCore *simdCore;
    DataFormatConverter *dataFormatConverter;
    
    // 状态变量
    bool busy;
    Cycles tensorCoreLatency;
    Cycles simdCoreLatency;
    Cycles memoryLatency;
    
    // 配置参数
    const uint32_t instBufferSize;
    const uint32_t taBufferSize;
    const uint32_t resultBufferSize;
    const bool supportSparse;
    const bool supportInt4;
    const bool supportFp16;
    const bool supportBf16;
    
    // 内部队列
    std::queue<PacketPtr> pendingRequests;
    
    // 统计信息
    struct AIAcceleratorStats {
        statistics::Scalar numInstructions;
        statistics::Scalar numComputeOps;
        statistics::Scalar numMemoryOps;
        statistics::Average computeLatency;
        statistics::Average memoryLatency;
        statistics::Formula utilization;
    } stats;

  public:
    AIAccelerator(const AIAcceleratorParams &params);
    
    // 主要接口
    Port &getPort(const std::string &if_name,
                  PortID idx = InvalidPortID) override;
    
    void tick();
    bool isBusy() const { return busy; }
    
    // 指令执行
    void executeInstruction(uint64_t inst);
    void handleMemoryResponse(PacketPtr pkt);
    
    // 统计信息
    void regStats() override;
    void resetStats();
    
  protected:
    // 内部函数
    bool sendMemoryRequest(PacketPtr pkt);
    void processMemoryResponse(PacketPtr pkt);
    void updateStats();
};

} // namespace gem5

#endif // __AI_ACCELERATOR_AI_ACCELERATOR_HH__ 