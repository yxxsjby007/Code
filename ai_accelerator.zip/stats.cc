#include "ai_accelerator/stats.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include <fstream>

namespace gem5
{

AcceleratorStats::AcceleratorStats(const AcceleratorStatsParams &params)
    : ClockedObject(params),
      enableDetailedStats(params.enable_detailed_stats),
      samplingPeriod(params.sampling_period),
      outputFile(params.output_file)
{
    // 初始化统计计数器
    initStats();
    
    DPRINTF(AIAccelerator, "Accelerator Stats initialized\n");
}

void
AcceleratorStats::initStats()
{
    // 注册统计信息
    computeOps
        .name(name() + ".computeOps")
        .desc("Number of compute operations executed")
        ;
        
    memoryAccesses
        .name(name() + ".memoryAccesses")
        .desc("Number of memory accesses")
        ;
        
    memoryBandwidth
        .name(name() + ".memoryBandwidth")
        .desc("Memory bandwidth utilization")
        ;
        
    computeUtilization
        .name(name() + ".computeUtilization")
        .desc("Compute unit utilization")
        ;
        
    energyConsumption
        .name(name() + ".energyConsumption")
        .desc("Estimated energy consumption")
        ;
        
    powerConsumption
        .name(name() + ".powerConsumption")
        .desc("Estimated power consumption")
        ;
}

void
AcceleratorStats::regStats()
{
    ClockedObject::regStats();
    
    // 注册所有统计信息
    computeOps.reset();
    memoryAccesses.reset();
    memoryBandwidth.reset();
    computeUtilization.reset();
    energyConsumption.reset();
    powerConsumption.reset();
}

void
AcceleratorStats::tick()
{
    // 定期采样和更新统计信息
    if (curTick() % samplingPeriod == 0) {
        updateStats();
    }
}

void
AcceleratorStats::updateStats()
{
    // 这里应该实现从加速器组件收集统计信息的逻辑
    // 这只是一个示例实现
    
    DPRINTF(AIAccelerator, "Updating accelerator statistics\n");
}

void
AcceleratorStats::recordComputeOp(int numOps)
{
    computeOps += numOps;
}

void
AcceleratorStats::recordMemoryAccess(int numAccesses, int bytesAccessed)
{
    memoryAccesses += numAccesses;
    // 更新带宽统计
    memoryBandwidth = bytesAccessed / (double)samplingPeriod;
}

void
AcceleratorStats::recordUtilization(double util)
{
    // 更新计算利用率
    computeUtilization = util;
}

void
AcceleratorStats::recordPower(double power, double energy)
{
    powerConsumption = power;
    energyConsumption += energy;
}

void
AcceleratorStats::dumpStats()
{
    if (!outputFile.empty()) {
        std::ofstream out(outputFile);
        if (out.is_open()) {
            out << "Accelerator Statistics:" << std::endl;
            out << "Compute Operations: " << computeOps << std::endl;
            out << "Memory Accesses: " << memoryAccesses << std::endl;
            out << "Memory Bandwidth: " << memoryBandwidth << " bytes/cycle" << std::endl;
            out << "Compute Utilization: " << computeUtilization * 100 << "%" << std::endl;
            out << "Energy Consumption: " << energyConsumption << " J" << std::endl;
            out << "Power Consumption: " << powerConsumption << " W" << std::endl;
            out.close();
            
            DPRINTF(AIAccelerator, "Statistics dumped to %s\n", outputFile);
        }
    }
}

void
AcceleratorStats::reset()
{
    // 重置所有统计计数器
    computeOps.reset();
    memoryAccesses.reset();
    memoryBandwidth.reset();
    computeUtilization.reset();
    energyConsumption.reset();
    powerConsumption.reset();
    
    DPRINTF(AIAccelerator, "Statistics reset\n");
}

} // namespace gem5 