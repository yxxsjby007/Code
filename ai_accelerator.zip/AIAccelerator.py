from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

# Import basic components first
from .Buffer import Buffer
from .DataFormatConverter import DataFormatConverter
from .LdStUnit import LdStUnit
from .LdUnit2 import LdUnit2
from .OnChipMemory import OnChipMemory
from .SIMDVectorCore import SIMDVectorCore
from .TABuffer import TABuffer
from .TensorCore import TensorCore

# Import controller last as it might have dependencies on other components
from .AIController import AIController

class AIAccelerator(ClockedObject):
    type = 'AIAccelerator'
    cxx_header = "ai_accelerator/ai_accelerator.hh"
    cxx_class = "gem5::AIAccelerator"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    controller = Param.AIController(NULL, "AI controller")
    
    data_port = RequestPort("Data port")
    
    # Parameters
    clock_rate = Param.String("1GHz", "Clock rate")
    memory_size = Param.MemorySize("1GB", "Memory size")
    peak_flops = Param.Float(1.0, "Peak FLOPS in TFLOPS")
    precision = Param.String("Mixed", "Precision mode (FP32, FP16, INT8, Mixed)")
    
    # Statistics
    enable_stats = Param.Bool(True, "Enable statistics collection")
    stat_period = Param.Cycles(1000, "Statistics sampling period in cycles")
    
    # Power and area estimation
    tdp = Param.Float(300.0, "Thermal design power in Watts")
    area = Param.Float(600.0, "Die area in mm^2")
    
    # Debug options
    debug_mode = Param.Bool(False, "Enable debug mode")
    trace_execution = Param.Bool(False, "Trace execution details")
    
    # Advanced options
    cache_coherence = Param.Bool(True, "Support cache coherence with host")
    interrupt_mode = Param.String("MSI", "Interrupt mode (MSI, MSI-X, Legacy)")
    dma_channels = Param.Unsigned(4, "Number of DMA channels")
    command_queue_size = Param.Unsigned(16, "Size of command queue")
    result_queue_size = Param.Unsigned(16, "Size of result queue")
    
    # 子组件
    ld_st_unit = Param.LdStUnit("Load/Store unit")
    on_chip_memory = Param.OnChipMemory("On-chip memory")
    ta_buffer = Param.TABuffer("TA buffer")
    tensor_core = Param.TensorCore("Tensor core")
    result_buffer = Param.Buffer("Result buffer")
    ld_unit2 = Param.LdUnit2("Second load unit")
    simd_core = Param.SIMDVectorCore("SIMD vector core")
    data_format_converter = Param.DataFormatConverter("Data format converter")
    
    # 配置参数
    clock_domain = Param.ClockDomain(Parent.clk_domain, "Clock domain")
    
    # 内存接口
    port = RequestPort("Port to the memory system")
    
    # 性能参数
    tensor_core_latency = Param.Cycles(1, "Tensor core operation latency")
    simd_core_latency = Param.Cycles(1, "SIMD core operation latency")
    memory_latency = Param.Cycles(10, "Memory access latency")
    
    # 缓冲区大小
    inst_buffer_size = Param.UInt32(1024, "Instruction buffer size")
    ta_buffer_size = Param.UInt32(32*32*8, "TA buffer size in bits")
    result_buffer_size = Param.UInt32(1024, "Result buffer size")
    
    # 功能配置
    support_sparse = Param.Bool(True, "Support for sparse tensor operations")
    support_int4 = Param.Bool(True, "Support for INT4 operations")
    support_fp16 = Param.Bool(True, "Support for FP16 operations")
    support_bf16 = Param.Bool(True, "Support for BF16 operations") 