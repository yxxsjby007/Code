#include "ai_accelerator/on_chip_memory.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include <cstring>
#include "mem/packet_access.hh"
#include "sim/system.hh"

namespace gem5
{

OnChipMemory::OnChipMemory(const OnChipMemoryParams &params)
    : ClockedObject(params),
      accessLatency(params.access_latency),
      portWidth(params.port_width)
{
    // Initialize memory banks
    initializeBanks();

    // Initialize read ports
    for (int i = 0; i < NUM_READ_PORTS; i++) {
        readPortVec.emplace_back(csprintf("read_port%d", i), this, true);
    }

    // Initialize write ports
    for (int i = 0; i < NUM_WRITE_PORTS; i++) {
        writePortVec.emplace_back(csprintf("write_port%d", i), this, false);
    }
    
    // 初始化bank状态
    for (int i = 0; i < NUM_BANKS; i++) {
        bankStatus[i].busy = false;
    }

    DPRINTF(AIAccelerator, "On-Chip Memory initialized with %d banks\n", NUM_BANKS);
}

OnChipMemory::~OnChipMemory()
{
    // 不需要手动释放vector
}

Port &
OnChipMemory::getPort(const std::string &if_name, PortID idx)
{
    // 检查是否是读端口
    if (if_name.find("read_port") == 0) {
        int port_id = std::stoi(if_name.substr(9));
        if (port_id < NUM_READ_PORTS) {
            return readPortVec[port_id];
        }
    }
    
    // 检查是否是写端口
    if (if_name.find("write_port") == 0) {
        int port_id = std::stoi(if_name.substr(10));
        if (port_id < NUM_WRITE_PORTS) {
            return writePortVec[port_id];
        }
    }
    
    // 默认返回
    return ClockedObject::getPort(if_name, idx);
}

void
OnChipMemory::tick()
{
    processPendingAccesses();

    // Process bank queues
    for (int i = 0; i < NUM_BANKS; i++) {
        if (!bankStatus[i].busy && !bankStatus[i].readQueue.empty()) {
            uint64_t addr = bankStatus[i].readQueue.front();
            bankStatus[i].readQueue.pop();
            bankStatus[i].busy = true;
            // Process read
            DPRINTF(AIAccelerator, "Processing read from bank %d at address %#x\n",
                    i, addr);
        } else if (!bankStatus[i].busy && !bankStatus[i].writeQueue.empty()) {
            uint64_t addr = bankStatus[i].writeQueue.front();
            bankStatus[i].writeQueue.pop();
            bankStatus[i].busy = true;
            // Process write
            DPRINTF(AIAccelerator, "Processing write to bank %d at address %#x\n",
                    i, addr);
        }
    }

    // 处理等待中的请求
    if (!requestQueue.empty()) {
        processNextRequest();
    }
    
    // 更新端口状态
    Tick currentTick = curTick();
    for (auto &port : readPortVec) {
        if (port.busy && currentTick >= port.readyTime) {
            port.busy = false;
        }
    }
    for (auto &port : writePortVec) {
        if (port.busy && currentTick >= port.readyTime) {
            port.busy = false;
        }
    }
}

void
OnChipMemory::processNextRequest()
{
    MemRequest &req = requestQueue.front();
    int bankId = getBankId(req.addr);
    
    if (isBankBusy(bankId)) {
        return;
    }
    
    bool canProcess = req.isRead ?
        (req.portId < NUM_READ_PORTS && !readPortVec[req.portId].busy) :
        (req.portId < NUM_WRITE_PORTS && !writePortVec[req.portId].busy);
        
    if (!canProcess) {
        return;
    }
    
    // 处理请求
    if (req.isRead) {
        // 读取数据
        uint8_t *data = new uint8_t[req.size];
        readFromBank(bankId, req.addr, data, req.size);
        req.pkt->setData(data);
        req.pkt->makeResponse();
        
        // 更新端口状态
        readPortVec[req.portId].busy = true;
        readPortVec[req.portId].bankAccessing = bankId;
        readPortVec[req.portId].readyTime = curTick() + accessLatency;
        
        // 调度响应
        scheduleResponse(req.pkt, accessLatency);
    } else {
        // 写入数据
        writeToBank(bankId, req.addr, req.pkt->getConstPtr<uint8_t>(), req.size);
        req.pkt->makeResponse();
        
        // 更新端口状态
        writePortVec[req.portId].busy = true;
        writePortVec[req.portId].bankAccessing = bankId;
        writePortVec[req.portId].readyTime = curTick() + accessLatency;
        
        // 调度响应
        scheduleResponse(req.pkt, accessLatency);
    }
    
    requestQueue.pop();
}

void
OnChipMemory::scheduleResponse(PacketPtr pkt, Tick delay)
{
    // 创建事件以在指定延迟后发送响应
    auto event = new EventFunctionWrapper(
        [this, pkt]() {
            if (pkt->isRead()) {
                // 处理读响应
                pkt->makeResponse();
                readPortVec[0].sendTimingResp(pkt);
            } else {
                // 处理写响应
                pkt->makeResponse();
                writePortVec[0].sendTimingResp(pkt);
            }
        },
        name());
    schedule(event, curTick() + delay);
}

bool
OnChipMemory::read(int portId, uint64_t addr, uint8_t* data, size_t size)
{
    if (!validateAccess(addr, size)) {
        return false;
    }

    int bankId = getBankId(addr);
    if (bankId < 0 || bankId >= NUM_BANKS) {
        return false;
    }

    BankAccess access;
    access.bankId = bankId;
    access.isRead = true;
    access.addr = addr;

    bankStatus[bankId].readQueue.push(addr);

    DPRINTF(AIAccelerator, "Queued read access to bank %d, port %d\n",
            bankId, portId);
    return true;
}

bool
OnChipMemory::write(int portId, uint64_t addr, const uint8_t* data, size_t size)
{
    if (!validateAccess(addr, size)) {
        return false;
    }

    int bankId = getBankId(addr);
    if (bankId < 0 || bankId >= NUM_BANKS) {
        return false;
    }

    BankAccess access;
    access.bankId = bankId;
    access.isRead = false;
    access.addr = addr;

    bankStatus[bankId].writeQueue.push(addr);

    DPRINTF(AIAccelerator, "Queued write access to bank %d, port %d\n",
            bankId, portId);
    return true;
}

int
OnChipMemory::requestReadPort()
{
    for (int i = 0; i < NUM_READ_PORTS; i++) {
        if (!readPortVec[i].busy) {
            readPortVec[i].busy = true;
            return i;
        }
    }
    return -1;  // No free port
}

int
OnChipMemory::requestWritePort()
{
    for (int i = 0; i < NUM_WRITE_PORTS; i++) {
        if (!writePortVec[i].busy) {
            writePortVec[i].busy = true;
            return i;
        }
    }
    return -1;  // No free port
}

void
OnChipMemory::releasePort(int portId, bool isRead)
{
    if (isRead) {
        if (portId >= 0 && portId < NUM_READ_PORTS) {
            readPortVec[portId].busy = false;
        }
    } else {
        if (portId >= 0 && portId < NUM_WRITE_PORTS) {
            writePortVec[portId].busy = false;
        }
    }
}

bool
OnChipMemory::isBankBusy(int bankId) const
{
    // 检查读端口是否访问该bank
    for (const auto &port : readPortVec) {
        if (port.busy && port.bankAccessing == bankId) {
            return true;
        }
    }
    
    // 检查写端口是否访问该bank
    for (const auto &port : writePortVec) {
        if (port.busy && port.bankAccessing == bankId) {
            return true;
        }
    }
    
    return bankStatus[bankId].busy;
}

bool
OnChipMemory::isPortBusy(int portId, bool isRead) const
{
    if (isRead) {
        if (portId >= 0 && portId < NUM_READ_PORTS) {
            return readPortVec[portId].busy;
        }
    } else {
        if (portId >= 0 && portId < NUM_WRITE_PORTS) {
            return writePortVec[portId].busy;
        }
    }
    return true;  // Invalid port is treated as busy
}

bool
OnChipMemory::hasAvailableReadPort() const
{
    for (int i = 0; i < NUM_READ_PORTS; i++) {
        if (!readPortVec[i].busy) {
            return true;
        }
    }
    return false;
}

bool
OnChipMemory::hasAvailableWritePort() const
{
    for (int i = 0; i < NUM_WRITE_PORTS; i++) {
        if (!writePortVec[i].busy) {
            return true;
        }
    }
    return false;
}

void
OnChipMemory::setBankSize(size_t size)
{
    // 只允许在初始化阶段设置
    clearBanks();
    for (auto& bank : banks) {
        bank.resize(size);
    }
}

void
OnChipMemory::configureBandwidth(size_t bitsPerCycle)
{
    // 可能需要更新访问延迟或其他参数
}

void
OnChipMemory::initializeBanks()
{
    // 初始化内存bank
    for (auto& bank : banks) {
        bank.resize(BANK_SIZE, 0);
    }
}

void
OnChipMemory::clearBanks()
{
    for (auto& bank : banks) {
        bank.clear();
    }
}

bool
OnChipMemory::validateAccess(uint64_t addr, size_t size) const
{
    int bankId = getBankId(addr);
    if (bankId < 0 || bankId >= NUM_BANKS) {
        return false;
    }
    
    size_t offset = addr % BANK_SIZE;
    return (offset + size <= BANK_SIZE);
}

void
OnChipMemory::processPendingAccesses()
{
    // 处理队列中的访问请求
}

void
OnChipMemory::completeBankAccess(const BankAccess& access)
{
    // 完成bank访问
    bankStatus[access.bankId].busy = false;
}

bool
OnChipMemory::readFromBank(int bankId, uint64_t addr, uint8_t* data, size_t size)
{
    if (!validateAccess(addr, size)) {
        return false;
    }
    
    size_t offset = addr % BANK_SIZE;
    memcpy(data, &banks[bankId][offset], size);
    return true;
}

bool
OnChipMemory::writeToBank(int bankId, uint64_t addr, const uint8_t* data, size_t size)
{
    if (!validateAccess(addr, size)) {
        return false;
    }
    
    size_t offset = addr % BANK_SIZE;
    memcpy(&banks[bankId][offset], data, size);
    return true;
}

void
OnChipMemory::reset()
{
    clearBanks();
    initializeBanks();
    
    // 重置端口状态
    for (auto& port : readPortVec) {
        port.busy = false;
    }
    
    for (auto& port : writePortVec) {
        port.busy = false;
    }
    
    // 清空请求队列
    while (!requestQueue.empty()) {
        requestQueue.pop();
    }
    
    // 重置bank状态
    for (auto& status : bankStatus) {
        status.busy = false;
        while (!status.readQueue.empty()) {
            status.readQueue.pop();
        }
        while (!status.writeQueue.empty()) {
            status.writeQueue.pop();
        }
    }
}

int
OnChipMemory::getBankId(uint64_t addr) const
{
    return (addr / BANK_SIZE) % NUM_BANKS;
}

bool
OnChipMemory::hasReadPort() const
{
    for (const auto& port : readPortVec) {
        if (!port.busy) {
            return true;
        }
    }
    return false;
}

bool
OnChipMemory::hasWritePort() const
{
    for (const auto& port : writePortVec) {
        if (!port.busy) {
            return true;
        }
    }
    return false;
}

bool
OnChipMemory::MemoryPort::recvTimingReq(PacketPtr pkt)
{
    // 尝试处理定时请求
    MemRequest req;
    req.isRead = pkt->isRead();
    req.portId = 0;  // 假设是第一个端口
    req.addr = pkt->getAddr();
    req.size = pkt->getSize();
    req.pkt = pkt;
    
    owner->requestQueue.push(req);
    return true;
}

void
OnChipMemory::MemoryPort::recvRespRetry()
{
    // 重试之前失败的响应
}

Tick
OnChipMemory::MemoryPort::recvAtomic(PacketPtr pkt)
{
    // 原子访问，简单实现
    if (pkt->isRead()) {
        uint8_t* data = new uint8_t[pkt->getSize()];
        int bankId = owner->getBankId(pkt->getAddr());
        owner->readFromBank(bankId, pkt->getAddr(), data, pkt->getSize());
        pkt->setData(data);
    } else {
        int bankId = owner->getBankId(pkt->getAddr());
        owner->writeToBank(bankId, pkt->getAddr(), 
                          pkt->getConstPtr<uint8_t>(), pkt->getSize());
    }
    
    pkt->makeResponse();
    return owner->accessLatency;
}

void
OnChipMemory::MemoryPort::recvFunctional(PacketPtr pkt)
{
    // 功能性访问，简单实现
    if (pkt->isRead()) {
        uint8_t* data = new uint8_t[pkt->getSize()];
        int bankId = owner->getBankId(pkt->getAddr());
        owner->readFromBank(bankId, pkt->getAddr(), data, pkt->getSize());
        pkt->setData(data);
    } else {
        int bankId = owner->getBankId(pkt->getAddr());
        owner->writeToBank(bankId, pkt->getAddr(), 
                          pkt->getConstPtr<uint8_t>(), pkt->getSize());
    }
    
    pkt->makeResponse();
}

AddrRangeList
OnChipMemory::MemoryPort::getAddrRanges() const
{
    AddrRangeList ranges;
    // 假设所有内存连续
    ranges.push_back(AddrRange(0, NUM_BANKS * BANK_SIZE - 1));
    return ranges;
}

} // namespace gem5 