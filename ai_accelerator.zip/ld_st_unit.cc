#include "ai_accelerator/ld_st_unit.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include "mem/packet.hh"
#include "mem/packet_access.hh"

namespace gem5
{

LdStUnit::LdStUnit(const LdStUnitParams &params) :
    ClockedObject(params),
    state(IDLE),
    portBusy(false),
    offChipPort("off_chip_port", this),
    onChipPort("on_chip_port", this),
    core2corePort("core2core_port", this),
    fifoPort("fifo_port", this),
    maxQueueSize(params.max_outstanding_requests),
    transferWidth(params.cache_line_size)
{
    DPRINTF(AIAccelerator, "Created LD/ST Unit\n");
}

void
LdStUnit::tick()
{
    if (!requestQueue.empty() && !portBusy) {
        processNextRequest();
    }
}

void
LdStUnit::processNextRequest()
{
    Request &req = requestQueue.front();
    bool success = false;

    switch (state) {
        case IDLE:
            if (req.isLoad) {
                if (req.addrList.empty()) {
                    state = LOADING;
                } else {
                    state = GATHERING;
                }
            } else {
                if (req.addrList.empty()) {
                    state = STORING;
                } else {
                    state = SCATTERING;
                }
            }
            break;

        case LOADING:
            // 创建内存读请求
            {
                RequestPtr memReq = std::make_shared<gem5::Request>(
                    req.addr, req.size, 0, 0);
                PacketPtr pkt = new Packet(memReq, MemCmd::ReadReq);
                pkt->allocate();

                if (offChipPort.sendTimingReq(pkt)) {
                    portBusy = true;
                    success = true;
                    DPRINTF(AIAccelerator, "Initiated load from address 0x%lx\n",
                            req.addr);
                }
            }
            break;

        case STORING:
            // 创建内存写请求
            {
                RequestPtr memReq = std::make_shared<gem5::Request>(
                    req.addr, req.size, 0, 0);
                PacketPtr pkt = new Packet(memReq, MemCmd::WriteReq);
                pkt->allocate();
                memcpy(pkt->getPtr<uint8_t>(), dataBuffer, req.size);

                if (offChipPort.sendTimingReq(pkt)) {
                    portBusy = true;
                    success = true;
                    DPRINTF(AIAccelerator, "Initiated store to address 0x%lx\n",
                            req.addr);
                }
            }
            break;

        case GATHERING:
        case SCATTERING:
            handleGatherScatter();
            break;
    }

    if (success) {
        requestQueue.pop();
        if (requestQueue.empty()) {
            state = IDLE;
        }
    }
}

void
LdStUnit::handleGatherScatter()
{
    Request &req = requestQueue.front();
    static size_t currentIndex = 0;

    if (currentIndex < req.addrList.size()) {
        uint64_t addr = req.addrList[currentIndex];
        RequestPtr memReq = std::make_shared<gem5::Request>(
            addr, sizeof(uint64_t), 0, 0);
        PacketPtr pkt = new Packet(memReq,
            state == GATHERING ? MemCmd::ReadReq : MemCmd::WriteReq);
        pkt->allocate();

        if (state == SCATTERING) {
            memcpy(pkt->getPtr<uint8_t>(),
                   &dataBuffer[currentIndex * sizeof(uint64_t)],
                   sizeof(uint64_t));
        }

        if (offChipPort.sendTimingReq(pkt)) {
            portBusy = true;
            currentIndex++;
            DPRINTF(AIAccelerator, "%s at address 0x%lx\n",
                    state == GATHERING ? "Gathering" : "Scattering", addr);
        }
    } else {
        currentIndex = 0;
        requestQueue.pop();
        if (requestQueue.empty()) {
            state = IDLE;
        }
    }
}

void
LdStUnit::initiateLoad(uint64_t addr, uint64_t size)
{
    if (hasSpace()) {
        requestQueue.push(Request(addr, size, true));
        DPRINTF(AIAccelerator, "Queued load request from address 0x%lx\n", addr);
    }
}

void
LdStUnit::initiateStore(uint64_t addr, uint64_t size)
{
    if (hasSpace()) {
        requestQueue.push(Request(addr, size, false));
        DPRINTF(AIAccelerator, "Queued store request to address 0x%lx\n", addr);
    }
}

void
LdStUnit::initiateGatherLoad(uint64_t sourceId,
                             const std::vector<uint64_t> &addrList)
{
    if (hasSpace()) {
        requestQueue.push(Request(sourceId, 0, true, addrList));
        DPRINTF(AIAccelerator, "Queued gather load request\n");
    }
}

void
LdStUnit::initiateScatterStore(uint64_t sourceId,
                               const std::vector<uint64_t> &addrList)
{
    if (hasSpace()) {
        requestQueue.push(Request(sourceId, 0, false, addrList));
        DPRINTF(AIAccelerator, "Queued scatter store request\n");
    }
}

Port &
LdStUnit::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "off_chip_port") {
        return offChipPort;
    } else if (if_name == "on_chip_port") {
        return onChipPort;
    } else if (if_name == "core2core_port") {
        return core2corePort;
    } else if (if_name == "fifo_port") {
        return fifoPort;
    } else {
        return ClockedObject::getPort(if_name, idx);
    }
}

bool
LdStUnit::MemPort::recvTimingResp(PacketPtr pkt)
{
    owner->portBusy = false;
    
    if (pkt->isRead()) {
        // 对于Load请求，将数据复制到缓冲区
        memcpy(owner->dataBuffer, pkt->getConstPtr<uint8_t>(), pkt->getSize());
    }
    
    delete pkt;
    return true;
}

void
LdStUnit::MemPort::recvReqRetry()
{
    // 尝试重新发送最后一个请求
    owner->processNextRequest();
}

} // namespace gem5 