from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class LdUnit2(ClockedObject):
    type = 'LdUnit2'
    cxx_header = "ai_accelerator/ld_unit2.hh"
    cxx_class = "gem5::LdUnit2"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    data_port = RequestPort("Data port")
    size = Param.MemorySize("1MB", "Size")
    bandwidth = Param.MemoryBandwidth("1GB/s", "Bandwidth")
    latency = Param.Latency("10ns", "Latency")
    
    # 添加缺失的参数
    accessLatency = Param.Cycles(10, "Access latency in cycles")
    maxQueueSize = Param.UInt32(16, "Maximum queue size")
    transferWidth = Param.UInt32(64, "Transfer width in bits")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    max_outstanding_requests = Param.UInt32(16, "Maximum number of outstanding requests")
    cache_line_size = Param.UInt32(64, "Cache line size in bytes")
    prefetch_enabled = Param.Bool(True, "Enable prefetching") 