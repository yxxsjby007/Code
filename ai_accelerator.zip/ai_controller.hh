#ifndef __AI_ACCELERATOR_AI_CONTROLLER_HH__
#define __AI_ACCELERATOR_AI_CONTROLLER_HH__

#include "params/AIController.hh"
#include "sim/clocked_object.hh"
#include "base/types.hh"
#include "mem/packet.hh"
#include "mem/port.hh"
#include <queue>
#include <vector>

namespace gem5
{

class AIController : public ClockedObject
{
  private:
    // 指令缓冲区
    struct InstructionBuffer {
        std::queue<uint64_t> instructions;
        size_t capacity;
    } instBuffer;

    // 控制单元状态
    enum ControllerState {
        IDLE,
        FETCH,
        DECODE,
        ISSUE,
        SYNC
    } state;

    // 发射单元数量
    static const int NUM_ISSUE_UNITS = 4;
    
    // 同步单元状态
    bool syncRequired;
    std::vector<bool> unitSyncStatus;

    // 内部函数
    void fetch();
    void decode();
    void issue();
    void sync();

  public:
    AIController(const AIControllerParams &params);

    // 主要接口函数
    void tick();
    void loadProgram(const std::vector<uint64_t> &program);
    bool isSynced() const { return !syncRequired; }
    
    // 与其他单元的接口
    void signalUnitCompletion(int unitId);
    bool isIssueAvailable() const;
    
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);

  protected:
    // 端口定义
    class CPUPort : public RequestPort
    {
      public:
        CPUPort(const std::string &name, AIController *owner) :
            RequestPort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingResp(PacketPtr pkt);
        void recvReqRetry();
        
      private:
        AIController *owner;
    };

    CPUPort instPort;
    std::vector<CPUPort> dataPort;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_AI_CONTROLLER_HH__ 