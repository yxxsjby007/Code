#ifndef __AI_ACCELERATOR_LD_ST_UNIT_HH__
#define __AI_ACCELERATOR_LD_ST_UNIT_HH__

#include "params/LdStUnit.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include "mem/packet.hh"
#include "mem/request.hh"
#include <queue>
#include <vector>

namespace gem5
{

class LdStUnit : public ClockedObject
{
  private:
    // 内部状态
    enum State {
        IDLE,
        LOADING,
        STORING,
        GATHERING,
        SCATTERING
    } state;

    // 数据传输请求队列
    struct Request {
        uint64_t addr;
        uint64_t size;
        bool isLoad;
        std::vector<uint64_t> addrList; // 用于gather/scatter操作
        
        // 添加构造函数
        Request() : addr(0), size(0), isLoad(true) {}
        Request(uint64_t addr, uint64_t size, bool isLoad = true) 
            : addr(addr), size(size), isLoad(isLoad) {}
        Request(uint64_t addr, uint64_t size, bool isLoad, 
                const std::vector<uint64_t> &addrList)
            : addr(addr), size(size), isLoad(isLoad), addrList(addrList) {}
    };
    std::queue<Request> requestQueue;

    // 数据缓冲区
    static const size_t BUFFER_SIZE = 512; // 512位宽度
    uint8_t dataBuffer[BUFFER_SIZE/8];
    
    // 端口状态
    bool portBusy;
    
    // 内部函数
    void processNextRequest();
    void handleGatherScatter();

  public:
    LdStUnit(const LdStUnitParams &params);

    // 主要接口函数
    void tick();
    
    // 数据传输接口
    void initiateLoad(uint64_t addr, uint64_t size);
    void initiateStore(uint64_t addr, uint64_t size);
    void initiateGatherLoad(uint64_t sourceId, const std::vector<uint64_t> &addrList);
    void initiateScatterStore(uint64_t sourceId, const std::vector<uint64_t> &addrList);
    
    // 状态查询
    bool isIdle() const { return state == IDLE; }
    bool hasSpace() const { return requestQueue.size() < maxQueueSize; }
    
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);

  protected:
    // 端口定义
    class MemPort : public RequestPort
    {
      public:
        MemPort(const std::string &name, LdStUnit *owner) :
            RequestPort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingResp(PacketPtr pkt);
        void recvReqRetry();
        
      private:
        LdStUnit *owner;
    };

    // 内存端口
    MemPort offChipPort;
    MemPort onChipPort;
    MemPort core2corePort;
    
    // FIFO端口
    MemPort fifoPort;
    
    // 配置参数
    const size_t maxQueueSize;
    const size_t transferWidth;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_LD_ST_UNIT_HH__ 