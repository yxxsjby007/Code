#include "ai_accelerator/simd_vector_core.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include "base/logging.hh"

namespace gem5
{

SIMDVectorCore::SIMDVectorCore(const SIMDVectorCoreParams &params) :
    ClockedObject(params),
    vectorLength(32),
    busy(false)
{
    // 初始化向量寄存器
    vectorRegisters.resize(NUM_VECTOR_REGISTERS);
    for (auto &reg : vectorRegisters) {
        reg.resize(vectorLength, 0.0f);
    }
}

bool
SIMDVectorCore::isReady() const
{
    return !busy;
}

void
SIMDVectorCore::tick()
{
    if (!busy) {
        return;
    }

    // 处理当前操作
    if (!pendingOps.empty()) {
        auto &op = pendingOps.front();
        
        switch (op.type) {
            case VectorOpType::ADD:
                vectorAdd(op.destReg, op.srcReg1, op.srcReg2);
                break;
                
            case VectorOpType::MUL:
                vectorMul(op.destReg, op.srcReg1, op.srcReg2);
                break;
                
            case VectorOpType::MAC:
                vectorMAC(op.destReg, op.srcReg1, op.srcReg2);
                break;
                
            default:
                panic("Unknown vector operation type");
        }
        
        pendingOps.pop();
        
        if (pendingOps.empty()) {
            busy = false;
        }
    }
}

bool
SIMDVectorCore::scheduleOp(const VectorOperation &op)
{
    if (busy) {
        return false;
    }

    // 验证寄存器索引
    if (op.destReg >= NUM_VECTOR_REGISTERS ||
        op.srcReg1 >= NUM_VECTOR_REGISTERS ||
        op.srcReg2 >= NUM_VECTOR_REGISTERS) {
        warn("Invalid vector register index");
        return false;
    }

    pendingOps.push(op);
    busy = true;
    return true;
}

void
SIMDVectorCore::vectorAdd(int destReg, int srcReg1, int srcReg2)
{
    DPRINTF(AIAccelerator, "Performing vector addition: %d = %d + %d\n",
            destReg, srcReg1, srcReg2);
            
    for (int i = 0; i < vectorLength; i++) {
        vectorRegisters[destReg][i] = 
            vectorRegisters[srcReg1][i] + vectorRegisters[srcReg2][i];
    }
}

void
SIMDVectorCore::vectorMul(int destReg, int srcReg1, int srcReg2)
{
    DPRINTF(AIAccelerator, "Performing vector multiplication: %d = %d * %d\n",
            destReg, srcReg1, srcReg2);
            
    for (int i = 0; i < vectorLength; i++) {
        vectorRegisters[destReg][i] = 
            vectorRegisters[srcReg1][i] * vectorRegisters[srcReg2][i];
    }
}

void
SIMDVectorCore::vectorMAC(int destReg, int srcReg1, int srcReg2)
{
    DPRINTF(AIAccelerator, "Performing vector MAC: %d += %d * %d\n",
            destReg, srcReg1, srcReg2);
            
    for (int i = 0; i < vectorLength; i++) {
        vectorRegisters[destReg][i] += 
            vectorRegisters[srcReg1][i] * vectorRegisters[srcReg2][i];
    }
}

bool
SIMDVectorCore::loadVectorRegister(int regIdx, const std::vector<float> &data)
{
    if (regIdx >= NUM_VECTOR_REGISTERS || data.size() != vectorLength) {
        return false;
    }
    
    vectorRegisters[regIdx] = data;
    return true;
}

bool
SIMDVectorCore::storeVectorRegister(int regIdx, std::vector<float> &data) const
{
    if (regIdx >= NUM_VECTOR_REGISTERS) {
        return false;
    }
    
    data = vectorRegisters[regIdx];
    return true;
}

} // namespace gem5 