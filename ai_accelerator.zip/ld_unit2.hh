#ifndef __AI_ACCELERATOR_LD_UNIT2_HH__
#define __AI_ACCELERATOR_LD_UNIT2_HH__

#include "params/LdUnit2.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include <queue>
#include <vector>

namespace gem5
{

class LdUnit2 : public ClockedObject
{
  private:
    // 加载单元状态
    enum State {
        IDLE,
        LOADING,
        DISTRIBUTING
    } state;
    
    // 数据缓冲区
    static const size_t BUFFER_SIZE = 512;  // 512位宽度
    std::vector<uint8_t> dataBuffer;
    
    // 数据请求队列
    struct LoadRequest {
        uint64_t addr;
        size_t size;
        int destId;  // 0: Controller, 1: SIMD Vector Core, 2: Scalar Core
        PacketPtr pkt;
    };
    std::queue<LoadRequest> requestQueue;
    
    // 内部处理函数
    void processNextRequest();
    void scheduleResponse(PacketPtr pkt, Tick delay);
    void distributeData(const LoadRequest &req);

  public:
    LdUnit2(const LdUnit2Params &params);

    // 主要接口函数
    void tick();
    
    // 加载接口
    void initiateLoad(uint64_t addr, size_t size, int destId);
    
    // 端口访问接口
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);
    
    // 状态查询
    bool isIdle() const { return state == IDLE; }
    bool hasSpace() const { return requestQueue.size() < maxQueueSize; }

  protected:
    // 端口定义
    class LoadPort : public RequestPort
    {
      public:
        LoadPort(const std::string &name, LdUnit2 *owner) :
            RequestPort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingResp(PacketPtr pkt);
        void recvReqRetry();
        
      private:
        LdUnit2 *owner;
    };

    // 输入端口
    LoadPort memPort;  // 从Off-chip Memory读取数据
    
    // 输出端口
    LoadPort ctrlPort;    // 输出到Controller
    LoadPort simdPort;    // 输出到SIMD Vector Core
    LoadPort scalarPort;  // 输出到Scalar Core
    
    // 配置参数
    const Tick accessLatency;
    const size_t maxQueueSize;
    const size_t transferWidth;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_LD_UNIT2_HH__ 