from m5.SimObject import SimObject
from m5.params import *
 
def debugFlag(name, desc):
    return SimObject.SubObject(name, 'DebugFlag', desc) 