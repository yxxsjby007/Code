#include "ai_accelerator/data_format_converter.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include "base/logging.hh"
#include <cstring>
#include <cmath>

namespace gem5
{

DataFormatConverter::DataFormatConverter(const DataFormatConverterParams &params) :
    ClockedObject(params),
    busy(false)
{
}

void
DataFormatConverter::tick()
{
    if (!busy || pendingRequests.empty()) {
        return;
    }

    auto &req = pendingRequests.front();
    std::vector<uint8_t> result;

    // 首先转换到FP32（如果源格式不是FP32）
    std::vector<uint8_t> fp32Data;
    if (req.srcFormat != DataFormat::FP32) {
        fp32Data = convertToFP32(req.data, req.srcFormat);
    } else {
        fp32Data = req.data;
    }

    // 然后从FP32转换到目标格式
    switch (req.dstFormat) {
        case DataFormat::FP16:
            result = convertFP32ToFP16(fp32Data);
            break;
        case DataFormat::BF16:
            result = convertFP32ToBF16(fp32Data);
            break;
        case DataFormat::INT8:
            result = convertFP32ToINT8(fp32Data);
            break;
        case DataFormat::INT4:
            result = convertFP32ToINT4(fp32Data);
            break;
        case DataFormat::FP32:
            result = fp32Data;
            break;
    }

    pendingRequests.front().data = result;
    pendingRequests.pop();

    if (pendingRequests.empty()) {
        busy = false;
    }
}

bool
DataFormatConverter::requestConversion(const ConversionRequest &req)
{
    if (busy) {
        return false;
    }

    pendingRequests.push(req);
    busy = true;
    return true;
}

bool
DataFormatConverter::getResult(std::vector<uint8_t> &result)
{
    if (busy || pendingRequests.empty()) {
        return false;
    }

    result = pendingRequests.front().data;
    return true;
}

std::vector<uint8_t>
DataFormatConverter::convertFP32ToFP16(const std::vector<uint8_t> &data)
{
    std::vector<uint8_t> result;
    result.reserve(data.size() / 2);

    for (size_t i = 0; i < data.size(); i += 4) {
        uint32_t fp32;
        std::memcpy(&fp32, &data[i], 4);

        // 提取符号位、指数和尾数
        uint32_t sign = (fp32 >> 31) & 0x1;
        uint32_t exp = (fp32 >> 23) & 0xFF;
        uint32_t frac = fp32 & 0x7FFFFF;

        // 转换为FP16
        uint16_t fp16 = (sign << 15);
        
        if (exp == 0) {
            // 处理零和非规格化数
            fp16 |= 0;
        } else if (exp == 0xFF) {
            // 处理无穷大和NaN
            fp16 |= 0x7C00;
            if (frac != 0) {
                fp16 |= (frac >> 13);
            }
        } else {
            // 处理规格化数
            int newExp = exp - 127 + 15;
            if (newExp >= 31) {
                // 上溢出到无穷大
                fp16 |= 0x7C00;
            } else if (newExp <= 0) {
                // 下溢出到零
                fp16 |= 0;
            } else {
                fp16 |= (newExp << 10) | (frac >> 13);
            }
        }

        result.push_back(fp16 & 0xFF);
        result.push_back(fp16 >> 8);
    }

    return result;
}

std::vector<uint8_t>
DataFormatConverter::convertFP32ToBF16(const std::vector<uint8_t> &data)
{
    std::vector<uint8_t> result;
    result.reserve(data.size() / 2);

    for (size_t i = 0; i < data.size(); i += 4) {
        // BF16保留FP32的高16位
        result.push_back(data[i + 1]);
        result.push_back(data[i + 0]);
    }

    return result;
}

std::vector<uint8_t>
DataFormatConverter::convertFP32ToINT8(const std::vector<uint8_t> &data)
{
    std::vector<uint8_t> result;
    result.reserve(data.size() / 4);

    for (size_t i = 0; i < data.size(); i += 4) {
        float fp32;
        std::memcpy(&fp32, &data[i], 4);
        
        // 将浮点数限制在INT8范围内并四舍五入
        int32_t intVal = std::round(std::max(std::min(fp32, 127.0f), -128.0f));
        result.push_back(static_cast<uint8_t>(intVal));
    }

    return result;
}

std::vector<uint8_t>
DataFormatConverter::convertFP32ToINT4(const std::vector<uint8_t> &data)
{
    std::vector<uint8_t> result;
    result.reserve(data.size() / 8);

    for (size_t i = 0; i < data.size(); i += 8) {
        uint8_t packed = 0;
        
        // 处理两个FP32数，每个转换为4位
        for (int j = 0; j < 2; j++) {
            float fp32;
            std::memcpy(&fp32, &data[i + j * 4], 4);
            
            // 将浮点数限制在INT4范围内并四舍五入
            int32_t intVal = std::round(std::max(std::min(fp32, 7.0f), -8.0f));
            packed |= (intVal & 0xF) << (j * 4);
        }
        
        result.push_back(packed);
    }

    return result;
}

std::vector<uint8_t>
DataFormatConverter::convertToFP32(const std::vector<uint8_t> &data, DataFormat srcFormat)
{
    std::vector<uint8_t> result;
    
    switch (srcFormat) {
        case DataFormat::FP16: {
            result.reserve(data.size() * 2);
            for (size_t i = 0; i < data.size(); i += 2) {
                uint16_t fp16;
                std::memcpy(&fp16, &data[i], 2);
                
                uint32_t sign = (fp16 >> 15) & 0x1;
                uint32_t exp = (fp16 >> 10) & 0x1F;
                uint32_t frac = fp16 & 0x3FF;
                
                uint32_t fp32;
                if (exp == 0) {
                    if (frac == 0) {
                        // Zero
                        fp32 = sign << 31;
                    } else {
                        // Denormal
                        exp = -14;
                        while ((frac & 0x400) == 0) {
                            frac <<= 1;
                            exp--;
                        }
                        frac &= 0x3FF;
                        fp32 = (sign << 31) | ((exp + 127) << 23) | (frac << 13);
                    }
                } else if (exp == 0x1F) {
                    // Infinity or NaN
                    fp32 = (sign << 31) | (0xFF << 23) | (frac << 13);
                } else {
                    // Normal number
                    fp32 = (sign << 31) | ((exp + 112) << 23) | (frac << 13);
                }
                
                uint8_t bytes[4];
                std::memcpy(bytes, &fp32, 4);
                for (int j = 0; j < 4; j++) {
                    result.push_back(bytes[j]);
                }
            }
            break;
        }
        
        case DataFormat::BF16: {
            result.reserve(data.size() * 2);
            for (size_t i = 0; i < data.size(); i += 2) {
                // BF16是FP32的高16位，所以直接补零即可
                result.push_back(data[i + 1]);
                result.push_back(data[i]);
                result.push_back(0);
                result.push_back(0);
            }
            break;
        }
        
        case DataFormat::INT8: {
            result.reserve(data.size() * 4);
            for (auto val : data) {
                float fp32 = static_cast<float>(static_cast<int8_t>(val));
                uint8_t bytes[4];
                std::memcpy(bytes, &fp32, 4);
                for (int j = 0; j < 4; j++) {
                    result.push_back(bytes[j]);
                }
            }
            break;
        }
        
        case DataFormat::INT4: {
            result.reserve(data.size() * 8);
            for (auto packed : data) {
                for (int j = 0; j < 2; j++) {
                    int8_t val = (packed >> (j * 4)) & 0xF;
                    if (val & 0x8) {
                        val |= 0xF0;  // 符号扩展
                    }
                    float fp32 = static_cast<float>(val);
                    uint8_t bytes[4];
                    std::memcpy(bytes, &fp32, 4);
                    for (int k = 0; k < 4; k++) {
                        result.push_back(bytes[k]);
                    }
                }
            }
            break;
        }
        
        default:
            panic("Unsupported source format");
    }
    
    return result;
}

} // namespace gem5 