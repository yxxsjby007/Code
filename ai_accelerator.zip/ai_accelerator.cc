#include "ai_accelerator/ai_accelerator.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include "base/logging.hh"
#include "sim/system.hh"

namespace gem5
{

AIAccelerator::AIAccelerator(const AIAcceleratorParams &params) :
    ClockedObject(params),
    port(name() + ".port", this),
    controller(params.controller),
    ldStUnit(params.ld_st_unit),
    onChipMemory(params.on_chip_memory),
    taBuffer(params.ta_buffer),
    tensorCore(params.tensor_core),
    resultBuffer(params.result_buffer),
    ldUnit2(params.ld_unit2),
    simdCore(params.simd_core),
    dataFormatConverter(params.data_format_converter),
    busy(false),
    tensorCoreLatency(params.tensor_core_latency),
    simdCoreLatency(params.simd_core_latency),
    memoryLatency(params.memory_latency),
    instBufferSize(params.inst_buffer_size),
    taBufferSize(params.ta_buffer_size),
    resultBufferSize(params.result_buffer_size),
    supportSparse(params.support_sparse),
    supportInt4(params.support_int4),
    supportFp16(params.support_fp16),
    supportBf16(params.support_bf16)
{
}

Port &
AIAccelerator::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "port") {
        return port;
    }
    return ClockedObject::getPort(if_name, idx);
}

void
AIAccelerator::tick()
{
    // 更新子组件状态
    controller->tick();
    ldStUnit->tick();
    onChipMemory->tick();
    taBuffer->tick();
    tensorCore->tick();
    resultBuffer->tick();
    ldUnit2->tick();
    simdCore->tick();
    dataFormatConverter->tick();
    
    // 处理内存请求
    while (!pendingRequests.empty()) {
        PacketPtr pkt = pendingRequests.front();
        if (sendMemoryRequest(pkt)) {
            pendingRequests.pop();
        } else {
            break;
        }
    }
    
    // 更新统计信息
    updateStats();
}

void
AIAccelerator::executeInstruction(uint64_t inst)
{
    DPRINTF(AIAccelerator, "Executing instruction: %#x\n", inst);
    
    // 解码并执行指令
    // TODO: 实现具体的指令执行逻辑
    
    stats.numInstructions++;
}

void
AIAccelerator::handleMemoryResponse(PacketPtr pkt)
{
    DPRINTF(AIAccelerator, "Received memory response for address %#x\n",
            pkt->getAddr());
            
    processMemoryResponse(pkt);
    stats.numMemoryOps++;
}

bool
AIAccelerator::sendMemoryRequest(PacketPtr pkt)
{
    if (!port.sendTimingReq(pkt)) {
        DPRINTF(AIAccelerator, "Memory request retry required\n");
        return false;
    }
    return true;
}

void
AIAccelerator::processMemoryResponse(PacketPtr pkt)
{
    // TODO: 实现内存响应处理逻辑
    delete pkt;
}

void
AIAccelerator::regStats()
{
    ClockedObject::regStats();
    
    stats.numInstructions
        .name(name() + ".num_instructions")
        .desc("Number of instructions executed");
        
    stats.numComputeOps
        .name(name() + ".num_compute_ops")
        .desc("Number of compute operations");
        
    stats.numMemoryOps
        .name(name() + ".num_memory_ops")
        .desc("Number of memory operations");
        
    stats.computeLatency
        .name(name() + ".compute_latency")
        .desc("Average compute operation latency")
        .precision(2);
        
    stats.memoryLatency
        .name(name() + ".memory_latency")
        .desc("Average memory operation latency")
        .precision(2);
        
    stats.utilization
        .name(name() + ".utilization")
        .desc("Overall accelerator utilization")
        .precision(2);
        
    stats.utilization = stats.numComputeOps / simTicks;
}

void
AIAccelerator::resetStats()
{
    ClockedObject::resetStats();
    // 重置其他统计信息
}

void
AIAccelerator::updateStats()
{
    // TODO: 更新统计信息
}

bool
AIAccelerator::AccPort::recvTimingResp(PacketPtr pkt)
{
    owner->handleMemoryResponse(pkt);
    return true;
}

void
AIAccelerator::AccPort::recvReqRetry()
{
    // 重试发送失败的请求
}

} // namespace gem5 