from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class AIController(ClockedObject):
    type = 'AIController'
    cxx_header = "ai_accelerator/ai_controller.hh"
    cxx_class = "gem5::AIController"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    ta_buffer = Param.TABuffer(NULL, "Tensor address buffer")
    ld_st_unit = Param.LdStUnit(NULL, "Load/Store unit")
    on_chip_mem = Param.OnChipMemory(NULL, "On chip memory")
    tensor_core = Param.TensorCore(NULL, "Tensor core")
    simd_core = Param.SIMDVectorCore(NULL, "SIMD vector core")

    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    instruction_buffer_size = Param.UInt32(1024, "Instruction buffer size in bytes")
    max_concurrent_tasks = Param.UInt32(8, "Maximum number of concurrent tasks")
    latency = Param.Cycles(1, "Controller operation latency") 