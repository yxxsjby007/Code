#include "ai_accelerator/sync_controller.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"

namespace gem5
{

SyncController::SyncController(const SyncControllerParams &params)
    : ClockedObject(params),
      numUnits(params.num_units),
      syncMode(params.sync_mode),
      timeout(params.timeout),
      syncRequired(false)
{
    // 初始化同步状态
    unitSyncStatus.resize(numUnits, false);
    
    DPRINTF(AIAccelerator, "Sync Controller initialized with %d units\n", numUnits);
}

void
SyncController::tick()
{
    // 检查是否所有单元都已同步
    if (syncRequired) {
        bool allSynced = true;
        for (bool status : unitSyncStatus) {
            if (!status) {
                allSynced = false;
                break;
            }
        }
        
        if (allSynced) {
            // 重置同步状态
            syncRequired = false;
            std::fill(unitSyncStatus.begin(), unitSyncStatus.end(), false);
            
            DPRINTF(AIAccelerator, "All units synchronized\n");
        }
    }
}

void
SyncController::requestSync(int unitId)
{
    if (unitId >= 0 && unitId < numUnits) {
        syncRequired = true;
        unitSyncStatus[unitId] = true;
        
        DPRINTF(AIAccelerator, "Unit %d requested synchronization\n", unitId);
    }
}

bool
SyncController::isSynced(int unitId) const
{
    if (unitId >= 0 && unitId < numUnits) {
        return !syncRequired || unitSyncStatus[unitId];
    }
    return false;
}

bool
SyncController::isAllSynced() const
{
    if (!syncRequired) {
        return true;
    }
    
    for (bool status : unitSyncStatus) {
        if (!status) {
            return false;
        }
    }
    
    return true;
}

void
SyncController::reset()
{
    syncRequired = false;
    std::fill(unitSyncStatus.begin(), unitSyncStatus.end(), false);
    
    DPRINTF(AIAccelerator, "Sync Controller reset\n");
}

} // namespace gem5 