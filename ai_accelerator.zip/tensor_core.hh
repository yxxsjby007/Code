#ifndef __AI_ACCELERATOR_TENSOR_CORE_HH__
#define __AI_ACCELERATOR_TENSOR_CORE_HH__

#include "base/types.hh"
#include "sim/clocked_object.hh"
#include "params/TensorCore.hh"
#include "mem/port.hh"
#include <vector>
#include <array>
#include <queue>

namespace gem5
{

class TensorCore : public ClockedObject
{
  private:
    static const int MATRIX_DIM = 32;
    static const int VECTOR_DIM = 32;

    // Matrix structures
    struct Matrix {
        std::vector<float> data;
        bool valid;
    };

    // Computation modes
    enum class ComputeMode {
        DENSE,
        STRUCTURED_SPARSE,
        UNSTRUCTURED_SPARSE
    };

    // Matrix operands
    Matrix matrixA;  // TA matrix (32x32)
    Matrix matrixB;  // TB matrix (32x1)
    Matrix matrixC;  // TC matrix (accumulator)
    Matrix matrixR;  // Result matrix

    // Status flags
    bool computing;
    bool accumulating;
    ComputeMode currentMode;

    // Computation tracking
    struct ComputeOperation {
        uint64_t aAddr;
        uint64_t bAddr;
        uint64_t cAddr;
        size_t len;
        bool isAccumulate;
    };
    std::queue<ComputeOperation> pendingOps;

    // Sparsity support
    struct SparsityPattern {
        std::vector<uint32_t> indices;
        std::vector<float> values;
    };
    SparsityPattern structuredPattern;
    SparsityPattern unstructuredPattern;

  public:
    TensorCore(const TensorCoreParams &params);
    ~TensorCore();

    // Main operation functions
    void tick();
    void reset();

    // Matrix loading functions
    bool loadMatrixA(const float* data, size_t len);
    bool loadMatrixB(const float* data, size_t len);
    bool loadMatrixC(const float* data, size_t len);
    
    // Computation functions
    bool computeMatrixMultiply();
    bool computeAccumulate();
    
    // Result retrieval
    bool getResult(float* data, size_t len) const;
    
    // Status checks
    bool isBusy() const;
    bool isResultReady() const;
    
    // Configuration
    void setComputeMode(ComputeMode mode);
    void configureSparsity(const std::vector<uint32_t>& pattern);

  protected:
    // Internal helper functions
    void initializeMatrices();
    void clearMatrices();
    bool validateDimensions(size_t len) const;
    
    // Computation helpers
    void processPendingOperations();
    void completeOperation(const ComputeOperation& op);
    
    // Matrix operations
    bool performDenseMultiply();
    bool performStructuredSparseMultiply();
    bool performUnstructuredSparseMultiply();
    
    // Sparsity handling
    bool validateSparsityPattern(const std::vector<uint32_t>& pattern) const;
    void applySparsityPattern(const SparsityPattern& pattern);
};

} // namespace gem5

#endif // __AI_ACCELERATOR_TENSOR_CORE_HH__ 