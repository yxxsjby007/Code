from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class SIMDVectorCore(ClockedObject):
    type = 'SIMDVectorCore'
    cxx_header = "ai_accelerator/simd_vector_core.hh"
    cxx_class = "gem5::SIMDVectorCore"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    width = Param.Unsigned(16, "SIMD width")
    num_units = Param.Unsigned(8, "Number of SIMD units")
    latency = Param.Latency("10ns", "Computation latency")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    lane_width = Param.UInt32(32, "Width of each SIMD lane in bits")
    vector_length = Param.UInt32(16, "Vector register length")
    support_fp32 = Param.Bool(True, "Support for FP32 operations")
    support_fp16 = Param.Bool(True, "Support for FP16 operations")
    support_int16 = Param.Bool(True, "Support for INT16 operations") 