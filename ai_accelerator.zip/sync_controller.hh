#ifndef __AI_ACCELERATOR_SYNC_CONTROLLER_HH__
#define __AI_ACCELERATOR_SYNC_CONTROLLER_HH__

#include "params/SyncController.hh"
#include "sim/clocked_object.hh"
#include "base/types.hh"
#include "sim/sim_object.hh"
#include <vector>
#include <queue>

namespace gem5
{

class SyncController : public ClockedObject
{
  private:
    // 同步状态
    struct SyncState {
        bool active;
        std::vector<bool> unitStatus;
        uint64_t startTick;
        uint64_t timeout;
    };
    
    // 同步组
    struct SyncGroup {
        std::vector<int> units;
        bool barrier;
    };
    
    // 成员变量
    std::vector<SyncState> syncStates;
    std::queue<SyncGroup> pendingSyncs;
    uint64_t defaultTimeout;
    
    // 配置参数
    const unsigned int numUnits;
    const std::string syncMode;
    const Cycles timeout;

    // 新增成员变量
    bool syncRequired;
    std::vector<bool> unitSyncStatus;

  public:
    SyncController(const SyncControllerParams &params);
    
    // 同步控制接口
    void requestSync(const std::vector<int> &units, bool barrier = false);
    void signalUnitReady(int unitId);
    bool isSyncComplete(int groupId) const;
    
    // 超时处理
    void checkTimeouts();
    void setTimeout(uint64_t ticks);
    
    // 状态查询
    bool isUnitBusy(int unitId) const;
    int getActiveGroups() const;
    
    // 主要接口函数
    void tick();
    void requestSync(int unitId);
    bool isSynced(int unitId) const;
    bool isAllSynced() const;
    void reset();
    
  protected:
    // 内部函数
    void createSyncGroup(const std::vector<int> &units, bool barrier);
    void processPendingSyncs();
    void clearSyncState(int groupId);
};

} // namespace gem5

#endif // __AI_ACCELERATOR_SYNC_CONTROLLER_HH__ 