#ifndef __AI_ACCELERATOR_SIMD_VECTOR_CORE_HH__
#define __AI_ACCELERATOR_SIMD_VECTOR_CORE_HH__

#include "params/SIMDVectorCore.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include <array>
#include <queue>
#include <vector>

namespace gem5
{

class SIMDVectorCore : public ClockedObject
{
  private:
    // 向量运算单元配置
    static const int VECTOR_LENGTH = 16;  // 每个向量寄存器的元素数量
    static const int NUM_REGISTERS = 32;  // 向量寄存器数量
    
    // 数据类型枚举
    enum DataType {
        INT8, INT16, INT32,
        FP8, FP16, BF16, FP32
    };
    
    // 操作类型枚举
    enum OpType {
        SINGLE_OP,   // 单操作数运算
        DUAL_OP,     // 双操作数运算
        RELU,        // ReLU激活
        TANH,        // Tanh激活
        EXP,         // 指数运算
        RSQRT        // 平方根倒数
    };
    
    // 向量寄存器文件
    struct VectorRegister {
        std::vector<uint8_t> data;
        DataType type;
        bool valid;
    };
    std::array<VectorRegister, NUM_REGISTERS> registers;
    
    // 计算单元状态
    enum State {
        IDLE,
        LOADING,
        COMPUTING,
        STORING
    } state;
    
    // 计算请求
    struct ComputeRequest {
        OpType op;
        DataType dataType;
        int destReg;
        int srcReg1;
        int srcReg2;  // 用于双操作数运算
        PacketPtr pkt;
    };
    std::queue<ComputeRequest> requestQueue;
    
    // 内部处理函数
    void processNextRequest();
    void scheduleResponse(PacketPtr pkt, Tick delay);
    void performComputation(const ComputeRequest &req);
    
    // 具体运算实现
    void singleOp(int destReg, int srcReg, DataType type);
    void dualOp(int destReg, int srcReg1, int srcReg2, DataType type);
    void relu(int destReg, int srcReg, DataType type);
    void tanh(int destReg, int srcReg, DataType type);
    void exp(int destReg, int srcReg, DataType type);
    void rsqrt(int destReg, int srcReg, DataType type);

  public:
    SIMDVectorCore(const SIMDVectorCoreParams &params);

    // 主要接口函数
    void tick();
    
    // 计算接口
    void initiateSingleOp(int destReg, int srcReg, DataType type);
    void initiateDualOp(int destReg, int srcReg1, int srcReg2, DataType type);
    void initiateRelu(int destReg, int srcReg, DataType type);
    void initiateTanh(int destReg, int srcReg, DataType type);
    void initiateExp(int destReg, int srcReg, DataType type);
    void initiateRsqrt(int destReg, int srcReg, DataType type);
    
    // 端口访问接口
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);
    
    // 状态查询
    bool isIdle() const { return state == IDLE; }
    bool hasSpace() const { return requestQueue.size() < maxQueueSize; }

  protected:
    // 端口定义
    class VectorPort : public ResponsePort
    {
      public:
        VectorPort(const std::string &name, SIMDVectorCore *owner) :
            ResponsePort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingReq(PacketPtr pkt);
        void recvRespRetry();
        
        Tick recvAtomic(PacketPtr pkt);
        void recvFunctional(PacketPtr pkt);
        
        AddrRangeList getAddrRanges() const;
        
      private:
        SIMDVectorCore *owner;
    };

    // 输入端口
    VectorPort vaPort;   // VA输入
    VectorPort vbPort;   // VB输入
    
    // 输出端口
    VectorPort vrPort;   // VR输出
    
    // 配置参数
    const Tick computeLatency;
    const size_t maxQueueSize;
    const size_t vectorWidth;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_SIMD_VECTOR_CORE_HH__ 