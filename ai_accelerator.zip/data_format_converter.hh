#ifndef __AI_ACCELERATOR_DATA_FORMAT_CONVERTER_HH__
#define __AI_ACCELERATOR_DATA_FORMAT_CONVERTER_HH__

#include "params/DataFormatConverter.hh"
#include "sim/clocked_object.hh"
#include <queue>
#include <vector>

namespace gem5
{

class DataFormatConverter : public ClockedObject
{
  public:
    enum class DataFormat {
        FP32,
        FP16,
        BF16,
        INT8,
        INT4
    };

    struct ConversionRequest {
        DataFormat srcFormat;
        DataFormat dstFormat;
        std::vector<uint8_t> data;
        size_t elements;
    };

  private:
    bool busy;
    std::queue<ConversionRequest> pendingRequests;
    
    // 内部转换函数
    std::vector<uint8_t> convertFP32ToFP16(const std::vector<uint8_t> &data);
    std::vector<uint8_t> convertFP32ToBF16(const std::vector<uint8_t> &data);
    std::vector<uint8_t> convertFP32ToINT8(const std::vector<uint8_t> &data);
    std::vector<uint8_t> convertFP32ToINT4(const std::vector<uint8_t> &data);
    
    std::vector<uint8_t> convertToFP32(const std::vector<uint8_t> &data, DataFormat srcFormat);

  public:
    DataFormatConverter(const DataFormatConverterParams &params);
    
    // 主要接口
    bool isReady() const { return !busy; }
    void tick();
    
    // 请求转换
    bool requestConversion(const ConversionRequest &req);
    
    // 获取结果
    bool getResult(std::vector<uint8_t> &result);
};

} // namespace gem5

#endif // __AI_ACCELERATOR_DATA_FORMAT_CONVERTER_HH__ 