#ifndef __AI_ACCELERATOR_STATS_HH__
#define __AI_ACCELERATOR_STATS_HH__

#include "params/AcceleratorStats.hh"
#include "sim/clocked_object.hh"
#include "base/statistics.hh"

namespace gem5
{

class AcceleratorStats : public ClockedObject
{
  private:
    // 配置参数
    const bool enableDetailedStats;
    const Cycles samplingPeriod;
    const std::string outputFile;
    
    // 统计计数器
    statistics::Scalar computeOps;
    statistics::Scalar memoryAccesses;
    statistics::Scalar memoryBandwidth;
    statistics::Scalar computeUtilization;
    statistics::Scalar energyConsumption;
    statistics::Scalar powerConsumption;
    
    // 内部方法
    void initStats();
    void updateStats();

  public:
    AcceleratorStats(const AcceleratorStatsParams &params);

    // 主要接口函数
    void regStats() override;
    void tick();
    void reset();
    void dumpStats();
    
    // 记录事件的接口
    void recordComputeOp(int numOps);
    void recordMemoryAccess(int numAccesses, int bytesAccessed);
    void recordUtilization(double util);
    void recordPower(double power, double energy);
};

} // namespace gem5

#endif // __AI_ACCELERATOR_STATS_HH__ 