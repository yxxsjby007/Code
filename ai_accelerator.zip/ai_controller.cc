#include "ai_accelerator/ai_controller.hh"
#include "base/trace.hh"
#include "debug/AIAccelerator.hh"
#include "sim/system.hh"
#include "mem/packet.hh"

namespace gem5
{

AIController::AIController(const AIControllerParams &params) :
    ClockedObject(params),
    state(IDLE),
    syncRequired(false),
    unitSyncStatus(NUM_ISSUE_UNITS, false),
    instPort("inst_port", this),
    dataPort(NUM_ISSUE_UNITS, CPUPort("data_port", this))
{
    // 初始化指令缓冲区
    instBuffer.capacity = params.instBufferSize;
    
    DPRINTF(AIAccelerator, "Created AIController with %d issue units\n", 
            NUM_ISSUE_UNITS);
}

void
AIController::tick()
{
    switch (state) {
        case IDLE:
            if (!instBuffer.instructions.empty()) {
                state = FETCH;
            }
            break;
            
        case FETCH:
            fetch();
            state = DECODE;
            break;
            
        case DECODE:
            decode();
            state = ISSUE;
            break;
            
        case ISSUE:
            issue();
            if (syncRequired) {
                state = SYNC;
            } else {
                state = FETCH;
            }
            break;
            
        case SYNC:
            sync();
            if (!syncRequired) {
                state = FETCH;
            }
            break;
    }
}

void
AIController::fetch()
{
    DPRINTF(AIAccelerator, "Fetching instruction\n");
    // 从指令缓冲区获取指令
    if (!instBuffer.instructions.empty()) {
        uint64_t inst = instBuffer.instructions.front();
        instBuffer.instructions.pop();
        DPRINTF(AIAccelerator, "Fetched instruction: 0x%lx\n", inst);
    }
}

void
AIController::decode()
{
    DPRINTF(AIAccelerator, "Decoding instruction\n");
    // 实现指令解码逻辑
    // TODO: 添加具体的指令解码实现
}

void
AIController::issue()
{
    DPRINTF(AIAccelerator, "Issuing instruction\n");
    // 实现指令发射逻辑
    // TODO: 添加具体的指令发射实现
    
    // 设置同步要求
    syncRequired = true;
    std::fill(unitSyncStatus.begin(), unitSyncStatus.end(), false);
}

void
AIController::sync()
{
    DPRINTF(AIAccelerator, "Synchronizing units\n");
    // 检查所有单元是否完成
    bool allSynced = true;
    for (bool status : unitSyncStatus) {
        if (!status) {
            allSynced = false;
            break;
        }
    }
    
    if (allSynced) {
        syncRequired = false;
        DPRINTF(AIAccelerator, "All units synchronized\n");
    }
}

void
AIController::loadProgram(const std::vector<uint64_t> &program)
{
    // 清空当前指令缓冲区
    while (!instBuffer.instructions.empty()) {
        instBuffer.instructions.pop();
    }
    
    // 加载新程序
    for (uint64_t inst : program) {
        if (instBuffer.instructions.size() < instBuffer.capacity) {
            instBuffer.instructions.push(inst);
        } else {
            DPRINTF(AIAccelerator, "Warning: Instruction buffer full\n");
            break;
        }
    }
    
    DPRINTF(AIAccelerator, "Loaded %zu instructions\n", 
            instBuffer.instructions.size());
}

void
AIController::signalUnitCompletion(int unitId)
{
    if (unitId >= 0 && unitId < NUM_ISSUE_UNITS) {
        unitSyncStatus[unitId] = true;
        DPRINTF(AIAccelerator, "Unit %d completed execution\n", unitId);
    }
}

bool
AIController::isIssueAvailable() const
{
    return state != ISSUE && state != SYNC;
}

Port &
AIController::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "inst_port") {
        return instPort;
    } else if (if_name == "data_port" && idx < NUM_ISSUE_UNITS) {
        return dataPort[idx];
    } else {
        return ClockedObject::getPort(if_name, idx);
    }
}

bool
AIController::CPUPort::recvTimingResp(PacketPtr pkt)
{
    DPRINTF(AIAccelerator, "Received timing response\n");
    // 处理响应包
    delete pkt;
    return true;
}

void
AIController::CPUPort::recvReqRetry()
{
    DPRINTF(AIAccelerator, "Received request retry\n");
    // 在这里重试请求
}

} // namespace gem5 