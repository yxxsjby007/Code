#include "ai_accelerator/buffer.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include <algorithm>
#include <cstring>
#include "mem/packet_access.hh"
#include "sim/system.hh"

namespace gem5
{

Buffer::Buffer(const BufferParams &params)
    : ClockedObject(params),
    data(BUFFER_SIZE / 8),
    isFull(false),
    isEmpty(true),
    busy(false),
    currentEntry(0),
    tensorPort("tensor_port", this),
    tcPort("tc_port", this),
    castPort("cast_port", this),
    accessLatency(params.accessLatency),
    bufferWidth(params.bufferWidth)
{
    // Initialize buffer configuration
    numEntries = 32;  // Default number of entries
    entrySize = 1024; // Default entry size in floats
    
    // Initialize buffer storage
    initializeBuffer();

    // 初始化部分和存储
    partialSums.resize(BUFFER_SIZE / 32);  // 假设每个部分和是32位
    
    DPRINTF(AIAccelerator, "Created Buffer with %zu bytes capacity\n",
            BUFFER_SIZE / 8);
}

Buffer::~Buffer()
{
}

void
Buffer::tick()
{
    processPendingOperations();

    if (!busy && !pendingOps.empty()) {
        auto& op = pendingOps.front();
        completeOperation(op);
        pendingOps.pop();
    }

    // 处理等待中的请求
    if (!requestQueue.empty()) {
        processNextRequest();
    }

    DPRINTF(AIAccelerator, "Buffer tick completed\n");
}

bool
Buffer::write(const float* data, size_t size, uint64_t tag)
{
    if (!validateSize(size)) {
        return false;
    }

    int entryIndex = findFreeEntry();
    if (entryIndex < 0) {
        return false;
    }

    BufferOp op;
    op.type = BufferOp::Type::WRITE;
    op.entryIndex = entryIndex;
    op.tag = tag;
    op.data.assign(data, data + size);

    pendingOps.push(op);
    busy = true;

    DPRINTF(AIAccelerator, "Queued write operation for tag %#x\n", tag);
    return true;
}

bool
Buffer::read(float* data, size_t size, uint64_t tag) const
{
    if (!validateSize(size)) {
        return false;
    }

    int entryIndex = findEntry(tag);
    if (entryIndex < 0) {
        return false;
    }

    return readFromEntry(entryIndex, data, size);
}

bool
Buffer::accumulate(const float* data, size_t size, uint64_t tag)
{
    if (!validateSize(size)) {
        return false;
    }

    int entryIndex = findEntry(tag);
    if (entryIndex < 0) {
        return false;
    }

    BufferOp op;
    op.type = BufferOp::Type::ACCUMULATE;
    op.entryIndex = entryIndex;
    op.tag = tag;
    op.data.assign(data, data + size);

    pendingOps.push(op);
    busy = true;

    DPRINTF(AIAccelerator, "Queued accumulate operation for tag %#x\n", tag);
    return true;
}

bool
Buffer::isBusy() const
{
    return busy;
}

bool
Buffer::hasSpace() const
{
    return findFreeEntry() >= 0;
}

bool
Buffer::hasData(uint64_t tag) const
{
    return findEntry(tag) >= 0;
}

void
Buffer::setNumEntries(size_t num)
{
    if (!busy) {
        numEntries = num;
        initializeBuffer();
        DPRINTF(AIAccelerator, "Number of entries set to %d\n", num);
    }
}

void
Buffer::setEntrySize(size_t size)
{
    if (!busy) {
        entrySize = size;
        initializeBuffer();
        DPRINTF(AIAccelerator, "Entry size set to %d\n", size);
    }
}

void
Buffer::initializeBuffer()
{
    entries.resize(numEntries);
    for (auto& entry : entries) {
        entry.data.resize(entrySize);
        entry.valid = false;
        entry.tag = 0;
    }
}

void
Buffer::clearBuffer()
{
    for (auto& entry : entries) {
        std::fill(entry.data.begin(), entry.data.end(), 0.0f);
        entry.valid = false;
        entry.tag = 0;
    }
}

bool
Buffer::validateSize(size_t size) const
{
    return size > 0 && size <= entrySize;
}

int
Buffer::findFreeEntry() const
{
    for (size_t i = 0; i < entries.size(); i++) {
        if (!entries[i].valid) {
            return i;
        }
    }
    return -1;
}

int
Buffer::findEntry(uint64_t tag) const
{
    for (size_t i = 0; i < entries.size(); i++) {
        if (entries[i].valid && entries[i].tag == tag) {
            return i;
        }
    }
    return -1;
}

void
Buffer::releaseEntry(size_t index)
{
    if (index < entries.size()) {
        entries[index].valid = false;
        entries[index].tag = 0;
        DPRINTF(AIAccelerator, "Released buffer entry %d\n", index);
    }
}

void
Buffer::processPendingOperations()
{
    if (busy && !pendingOps.empty()) {
        auto& op = pendingOps.front();
        
        switch (op.type) {
            case BufferOp::Type::WRITE:
                writeToEntry(op.entryIndex, op.data.data(), op.data.size());
                break;
            case BufferOp::Type::ACCUMULATE:
                accumulateToEntry(op.entryIndex, op.data.data(), op.data.size());
                break;
            default:
                break;
        }
    }
}

void
Buffer::completeOperation(const BufferOp& op)
{
    switch (op.type) {
        case BufferOp::Type::WRITE:
            entries[op.entryIndex].valid = true;
            entries[op.entryIndex].tag = op.tag;
            break;
        case BufferOp::Type::ACCUMULATE:
            // Accumulation already completed in processPendingOperations
            break;
        default:
            break;
    }

    busy = false;
    DPRINTF(AIAccelerator, "Completed operation for tag %#x\n", op.tag);
}

bool
Buffer::writeToEntry(size_t index, const float* data, size_t size)
{
    if (index >= entries.size() || size > entrySize) {
        return false;
    }

    std::copy(data, data + size, entries[index].data.begin());
    DPRINTF(AIAccelerator, "Wrote %d elements to entry %d\n", size, index);
    return true;
}

bool
Buffer::readFromEntry(size_t index, float* data, size_t size) const
{
    if (index >= entries.size() || size > entrySize || !entries[index].valid) {
        return false;
    }

    std::copy(entries[index].data.begin(),
              entries[index].data.begin() + size,
              data);
    
    DPRINTF(AIAccelerator, "Read %d elements from entry %d\n", size, index);
    return true;
}

bool
Buffer::accumulateToEntry(size_t index, const float* data, size_t size)
{
    if (index >= entries.size() || size > entrySize || !entries[index].valid) {
        return false;
    }

    for (size_t i = 0; i < size; i++) {
        entries[index].data[i] += data[i];
    }

    DPRINTF(AIAccelerator, "Accumulated %d elements to entry %d\n", size, index);
    return true;
}

void
Buffer::reset()
{
    clearBuffer();
    busy = false;
    currentEntry = 0;
    
    while (!pendingOps.empty()) {
        pendingOps.pop();
    }

    DPRINTF(AIAccelerator, "Buffer reset completed\n");
}

void
Buffer::processNextRequest()
{
    BufferRequest &req = requestQueue.front();
    
    if (req.isRead) {
        // 读取数据
        uint8_t *data = new uint8_t[req.size];
        readData(data, req.size);
        req.pkt->setData(data);
        req.pkt->makeResponse();
        
        // 调度响应，传递port ID
        scheduleResponse(req.pkt, accessLatency, req.portId);
    } else {
        // 写入数据
        writeData(req.pkt->getConstPtr<uint8_t>(), req.size);
        req.pkt->makeResponse();
        
        // 调度响应，传递port ID
        scheduleResponse(req.pkt, accessLatency, req.portId);
    }
    
    requestQueue.pop();
    updateBufferState();
}

void
Buffer::scheduleResponse(PacketPtr pkt, Tick delay, int portId)
{
    auto event = new EventFunctionWrapper(
        [this, pkt, portId]() {
            switch (portId) {
                case 0:
                    tensorPort.sendTimingResp(pkt);
                    break;
                case 1:
                    tcPort.sendTimingResp(pkt);
                    break;
                case 2:
                    castPort.sendTimingResp(pkt);
                    break;
                default:
                    // 默认使用第一个端口
                    tensorPort.sendTimingResp(pkt);
                    break;
            }
        },
        name());
    schedule(event, curTick() + delay);
}

void
Buffer::updateBufferState()
{
    // 更新缓冲区状态标志
    isFull = false;  // 在实际实现中需要根据使用情况更新
    isEmpty = false; // 在实际实现中需要根据使用情况更新
}

void
Buffer::writeData(const uint8_t* srcData, size_t size)
{
    if (size <= data.size()) {
        memcpy(data.data(), srcData, size);
        isEmpty = false;
        isFull = (size == data.size());
        DPRINTF(AIAccelerator, "Wrote %zu bytes to buffer\n", size);
    }
}

void
Buffer::readData(uint8_t* destData, size_t size) const
{
    if (size <= data.size() && !isEmpty) {
        memcpy(destData, data.data(), size);
        DPRINTF(AIAccelerator, "Read %zu bytes from buffer\n", size);
    }
}

void
Buffer::addPartialSum(float value, size_t index)
{
    if (index < partialSums.size()) {
        partialSums[index] += value;
        DPRINTF(AIAccelerator, "Added partial sum %f at index %zu\n",
                value, index);
    }
}

float
Buffer::getPartialSum(size_t index) const
{
    if (index < partialSums.size()) {
        return partialSums[index];
    }
    return 0.0f;
}

void
Buffer::clearPartialSums()
{
    std::fill(partialSums.begin(), partialSums.end(), 0.0f);
    DPRINTF(AIAccelerator, "Cleared all partial sums\n");
}

Port &
Buffer::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "tensor_port") {
        return tensorPort;
    } else if (if_name == "tc_port") {
        return tcPort;
    } else if (if_name == "cast_port") {
        return castPort;
    } else {
        return ClockedObject::getPort(if_name, idx);
    }
}

bool
Buffer::BufferPort::recvTimingReq(PacketPtr pkt)
{
    // 创建新的缓冲区请求
    Buffer::BufferRequest req;
    req.isRead = pkt->isRead();
    req.addr = pkt->getAddr();
    req.size = pkt->getSize();
    req.pkt = pkt;
    
    // 根据端口名称设置portId
    if (name() == "tensor_port") {
        req.portId = 0;
    } else if (name() == "tc_port") {
        req.portId = 1;
    } else if (name() == "cast_port") {
        req.portId = 2;
    } else {
        req.portId = 0; // 默认使用第一个端口
    }
    
    // 将请求添加到队列
    owner->requestQueue.push(req);
    return true;
}

void
Buffer::BufferPort::recvRespRetry()
{
    // 重试响应
}

Tick
Buffer::BufferPort::recvAtomic(PacketPtr pkt)
{
    // 原子访问实现
    return owner->accessLatency;
}

void
Buffer::BufferPort::recvFunctional(PacketPtr pkt)
{
    // 功能访问实现
}

AddrRangeList
Buffer::BufferPort::getAddrRanges() const
{
    AddrRangeList ranges;
    ranges.push_back(AddrRange(0, BUFFER_SIZE / 8 - 1));
    return ranges;
}

} // namespace gem5 