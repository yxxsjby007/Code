#ifndef __AI_ACCELERATOR_ISA_HH__
#define __AI_ACCELERATOR_ISA_HH__

#include "base/types.hh"

namespace gem5
{

// 指令格式定义
struct AcceleratorInstruction {
    enum class Opcode : uint8_t {
        // 数据移动指令
        LOAD_MATRIX,     // 加载矩阵数据
        STORE_MATRIX,    // 存储矩阵数据
        MOVE_DATA,       // 数据移动
        
        // 计算指令
        MATRIX_MULTIPLY, // 矩阵乘法
        VECTOR_ADD,      // 向量加法
        VECTOR_MUL,      // 向量乘法
        
        // 控制指令
        SYNC,           // 同步操作
        CONFIG,         // 配置操作
        NOP            // 空操作
    };
    
    struct {
        Opcode opcode : 8;      // 操作码
        uint16_t dst : 16;      // 目标地址/寄存器
        uint16_t src1 : 16;     // 源操作数1
        uint16_t src2 : 16;     // 源操作数2
        uint8_t flags : 8;      // 标志位
    } fields;
    
    // 指令编码/解码函数
    static AcceleratorInstruction decode(uint64_t raw);
    uint64_t encode() const;
    
    // 指令信息获取
    bool isCompute() const;
    bool isMemory() const;
    bool isControl() const;
    
    // 打印指令信息
    void print(std::ostream &os) const;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_ISA_HH__ 