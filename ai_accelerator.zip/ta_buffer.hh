#ifndef __AI_ACCELERATOR_TA_BUFFER_HH__
#define __AI_ACCELERATOR_TA_BUFFER_HH__

#include "params/TABuffer.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include <array>
#include <queue>
#include <vector>
#include <deque>

namespace gem5
{

class TABuffer : public ClockedObject
{
  private:
    // Buffer配置
    static const int NUM_BUFFERS = 32;
    static const int BUFFER_WIDTH = 8;  // 8 bits
    static const int BUFFER_DEPTH = 32;
    
    // 每个buffer的数据结构
    struct Buffer {
        uint8_t* data;
        size_t head;
        size_t tail;
        bool busy;
    };
    
    // 每个buffer的数据存储
    std::array<Buffer, NUM_BUFFERS> buffers;
    
    // Buffer状态
    struct BufferStatus {
        bool busy;
        size_t usedSpace;
    };
    std::array<BufferStatus, NUM_BUFFERS> bufferStatus;
    
    // 输入多路复用器状态
    struct MuxState {
        bool busy;
        int selectedInput;
        Tick readyTime;
    } muxIn;
    
    // 输出多路复用器状态
    struct MuxOutState {
        bool busy;
        int selectedBuffer;
        Tick readyTime;
    } muxOut;
    
    // 数据传输请求
    struct DataRequest {
        bool isRead;
        int bufferId;
        uint64_t addr;
        size_t size;
        PacketPtr pkt;
    };
    std::queue<DataRequest> requestQueue;
    
    // 传输结构
    struct Transfer {
        bool isRead;
        int bufferId;
        size_t size;
        std::vector<int> bufferIndices;
    };
    std::deque<Transfer> pendingTransfers;
    
    // 状态变量
    bool isReading;
    bool isWriting;
    size_t currentReadBandwidth;
    size_t currentWriteBandwidth;
    size_t writeBandwidth;
    
    // 内部处理函数
    void processNextRequest();
    void processTransfers();
    void scheduleResponse(PacketPtr pkt, Tick delay);
    void completeTransfer(const Transfer& transfer);
    bool isBufferBusy(int bufferId) const;
    
    // 辅助函数
    bool validateTransfer(size_t size) const;
    bool writeToBuffer(int bufferId, const uint8_t* data, size_t size);
    bool readFromBuffer(int bufferId, uint8_t* data, size_t size);
    bool checkReadBandwidth(size_t size) const;
    bool checkWriteBandwidth(size_t size) const;
    void updateBandwidthUsage(size_t size, bool isRead);
    void initializeBuffers();
    void clearBuffers();

  public:
    TABuffer(const TABufferParams &params);
    ~TABuffer();

    // 主要接口函数
    void tick();
    void reset();
    
    // 数据访问接口
    bool write(const uint8_t* data, size_t size);
    bool read(uint8_t* data, size_t size);
    
    // Buffer管理
    int requestBuffer();
    void releaseBuffer(int bufferId);
    bool isBufferAvailable() const;
    
    // 带宽设置
    void setReadBandwidth(size_t bitsPerCycle);
    void setWriteBandwidth(size_t bitsPerCycle);
    
    // 多路复用器控制
    void selectInputSource(int source);
    void selectOutputBuffer(int bufferId);
    
    // 端口访问接口
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);
    
    // 状态查询
    bool isBusy() const;
    size_t getAvailableSpace() const;
    size_t getStoredDataSize() const;

  protected:
    // 端口定义
    class BufferPort : public ResponsePort
    {
      public:
        BufferPort(const std::string &name, TABuffer *owner) :
            ResponsePort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingReq(PacketPtr pkt);
        void recvRespRetry();
        
        Tick recvAtomic(PacketPtr pkt);
        void recvFunctional(PacketPtr pkt);
        
        AddrRangeList getAddrRanges() const;
        
      private:
        TABuffer *owner;
    };

    // 输入端口
    BufferPort fifoPort;
    BufferPort rrPort;
    
    // 输出端口
    BufferPort tensorPort;
    
    // 配置参数
    const Tick accessLatency;
    const size_t readBandwidth;  // 32*32*8 bit/clockcycle
};

} // namespace gem5

#endif // __AI_ACCELERATOR_TA_BUFFER_HH__ 