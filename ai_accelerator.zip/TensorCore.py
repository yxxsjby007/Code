from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class TensorCore(ClockedObject):
    type = 'TensorCore'
    cxx_header = "ai_accelerator/tensor_core.hh"
    cxx_class = "gem5::TensorCore"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    num_units = Param.Unsigned(4, "Number of tensor units")
    precision = Param.String("FP16", "Precision")
    latency = Param.Latency("10ns", "Computation latency")
    
    # 添加必要的参数
    compute_latency = Param.Cycles(10, "Computation latency in cycles")
    compute_bandwidth = Param.UInt64(1024, "Computation bandwidth in operations per cycle")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    width = Param.UInt32(8, "Tensor unit width")
    height = Param.UInt32(8, "Tensor unit height")
    support_fp16 = Param.Bool(True, "Support for FP16 operations")
    support_int8 = Param.Bool(True, "Support for INT8 operations")
    support_sparse = Param.Bool(True, "Support for sparse tensor operations") 