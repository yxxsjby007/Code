#ifndef __AI_ACCELERATOR_ON_CHIP_MEMORY_HH__
#define __AI_ACCELERATOR_ON_CHIP_MEMORY_HH__

#include "params/OnChipMemory.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include <array>
#include <queue>
#include <vector>

namespace gem5
{

class OnChipMemory : public ClockedObject
{
  private:
    // 内存bank配置
    static const int NUM_BANKS = 8;
    static const int BANK_SIZE = 32 * 1024; // 32KB per bank
    
    // 每个bank的数据存储
    std::array<std::vector<uint8_t>, NUM_BANKS> banks;
    
    // Bank状态
    struct BankStatus {
        bool busy;
        std::queue<uint64_t> readQueue;
        std::queue<uint64_t> writeQueue;
    };
    std::array<BankStatus, NUM_BANKS> bankStatus;
    
    // 端口状态跟踪
    struct PortStatus {
        bool busy;
        int bankAccessing;
        Tick readyTime;
    };
    
    // 读写端口状态
    static const int NUM_READ_PORTS = 8;
    static const int NUM_WRITE_PORTS = 5;
    std::array<PortStatus, NUM_READ_PORTS> readPorts;
    std::array<PortStatus, NUM_WRITE_PORTS> writePorts;
    
    // 访问请求队列
    struct MemRequest {
        bool isRead;
        int portId;
        uint64_t addr;
        size_t size;
        PacketPtr pkt;
    };
    std::queue<MemRequest> requestQueue;
    
    // Bank访问记录
    struct BankAccess {
        int bankId;
        bool isRead;
        uint64_t addr;
    };
    
    // Bank冲突检查
    bool isBankBusy(int bankId) const;
    int getBankId(uint64_t addr) const;
    bool isPortBusy(int portId, bool isRead) const;
    bool hasAvailableReadPort() const;
    bool hasAvailableWritePort() const;
    
    // 内部处理函数
    void processNextRequest();
    void processPendingAccesses();
    void scheduleResponse(PacketPtr pkt, Tick delay);
    void completeBankAccess(const BankAccess& access);
    
    // 初始化函数
    void initializeBanks();
    void clearBanks();
    
    // 直接访问接口
    bool readFromBank(int bankId, uint64_t addr, uint8_t* data, size_t size);
    bool writeToBank(int bankId, uint64_t addr, const uint8_t* data, size_t size);
    bool validateAccess(uint64_t addr, size_t size) const;

  public:
    OnChipMemory(const OnChipMemoryParams &params);
    ~OnChipMemory();

    // 主要接口函数
    void tick();
    void reset();
    
    // 配置函数
    void setBankSize(size_t size);
    void configureBandwidth(size_t bitsPerCycle);
    
    // 内存访问接口
    bool read(int portId, uint64_t addr, uint8_t* data, size_t size);
    bool write(int portId, uint64_t addr, const uint8_t* data, size_t size);
    
    // 端口管理
    int requestReadPort();
    int requestWritePort();
    void releasePort(int portId, bool isRead);
    
    // 端口访问接口
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);
    
    // 状态查询
    bool hasReadPort() const;
    bool hasWritePort() const;

  protected:
    // 端口定义
    class MemoryPort : public ResponsePort
    {
      public:
        MemoryPort(const std::string &name, OnChipMemory *owner, bool isRead) :
            ResponsePort(name, owner), owner(owner), isRead(isRead) {}
      
      protected:
        bool recvTimingReq(PacketPtr pkt);
        void recvRespRetry();
        
        Tick recvAtomic(PacketPtr pkt);
        void recvFunctional(PacketPtr pkt);
        
        AddrRangeList getAddrRanges() const;
        
      private:
        OnChipMemory *owner;
        bool isRead;
        
      public:
        // 端口状态
        bool busy = false;
        int bankAccessing = -1;
        Tick readyTime = 0;
    };

    // 读写端口
    std::vector<MemoryPort> readPortVec;
    std::vector<MemoryPort> writePortVec;
    
    // 配置参数
    const Tick accessLatency;
    const size_t portWidth;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_ON_CHIP_MEMORY_HH__ 