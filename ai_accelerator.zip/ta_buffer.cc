#include "ai_accelerator/ta_buffer.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include <cstring>
#include "mem/packet_access.hh"
#include "sim/system.hh"

namespace gem5
{

TABuffer::TABuffer(const TABufferParams &params) :
    ClockedObject(params),
    muxIn{false, -1, 0},
    muxOut{false, -1, 0},
    isReading(false),
    isWriting(false),
    currentReadBandwidth(0),
    currentWriteBandwidth(0),
    writeBandwidth(params.read_bandwidth / 2), // 默认写带宽是读带宽的一半
    fifoPort("fifo_port", this),
    rrPort("rr_port", this),
    tensorPort("tensor_port", this),
    accessLatency(params.access_latency),
    readBandwidth(params.read_bandwidth)
{
    // 初始化缓冲区
    initializeBuffers();

    // 初始化状态
    isReading = false;
    isWriting = false;
    currentReadBandwidth = 0;
    currentWriteBandwidth = 0;
    
    DPRINTF(AIAccelerator, "TA Buffer initialized with %d buffers\n", NUM_BUFFERS);
}

TABuffer::~TABuffer()
{
    for (auto& buffer : buffers) {
        delete[] buffer.data;
    }
}

void
TABuffer::tick()
{
    processTransfers();

    // Reset bandwidth counters each cycle
    currentReadBandwidth = 0;
    currentWriteBandwidth = 0;

    DPRINTF(AIAccelerator, "TA Buffer tick completed\n");
}

bool
TABuffer::write(const uint8_t* data, size_t size)
{
    if (!validateTransfer(size) || !checkWriteBandwidth(size)) {
        return false;
    }

    Transfer transfer;
    transfer.size = size;
    transfer.isRead = false;

    // Find available buffers
    size_t remainingSize = size;
    size_t offset = 0;

    while (remainingSize > 0) {
        int bufferId = requestBuffer();
        if (bufferId < 0) {
            // Not enough buffers available
            return false;
        }

        transfer.bufferIndices.push_back(bufferId);
        size_t writeSize = std::min(remainingSize, 
                                  static_cast<size_t>(BUFFER_DEPTH * BUFFER_WIDTH / 8));
        
        if (!writeToBuffer(bufferId, data + offset, writeSize)) {
            // Write failed
            return false;
        }

        remainingSize -= writeSize;
        offset += writeSize;
    }

    pendingTransfers.push_back(transfer);
    isWriting = true;

    DPRINTF(AIAccelerator, "Queued write transfer of %d bytes\n", size);
    return true;
}

bool
TABuffer::read(uint8_t* data, size_t size)
{
    if (!validateTransfer(size) || !checkReadBandwidth(size)) {
        return false;
    }

    Transfer transfer;
    transfer.size = size;
    transfer.isRead = true;

    // Find buffers with data
    size_t remainingSize = size;
    size_t offset = 0;

    for (int i = 0; i < NUM_BUFFERS && remainingSize > 0; i++) {
        if (!buffers[i].busy) {
            continue;
        }

        transfer.bufferIndices.push_back(i);
        size_t readSize = std::min(remainingSize,
                                 static_cast<size_t>(BUFFER_DEPTH * BUFFER_WIDTH / 8));
        
        if (!readFromBuffer(i, data + offset, readSize)) {
            // Read failed
            return false;
        }

        remainingSize -= readSize;
        offset += readSize;
    }

    if (remainingSize > 0) {
        // Not enough data available
        return false;
    }

    pendingTransfers.push_back(transfer);
    isReading = true;

    DPRINTF(AIAccelerator, "Queued read transfer of %d bytes\n", size);
    return true;
}

int
TABuffer::requestBuffer()
{
    for (int i = 0; i < NUM_BUFFERS; i++) {
        if (!buffers[i].busy) {
            buffers[i].busy = true;
            buffers[i].head = 0;
            buffers[i].tail = 0;
            DPRINTF(AIAccelerator, "Allocated buffer %d\n", i);
            return i;
        }
    }
    return -1;
}

void
TABuffer::releaseBuffer(int bufferId)
{
    if (bufferId >= 0 && bufferId < NUM_BUFFERS) {
        buffers[bufferId].busy = false;
        buffers[bufferId].head = 0;
        buffers[bufferId].tail = 0;
        DPRINTF(AIAccelerator, "Released buffer %d\n", bufferId);
    }
}

bool
TABuffer::isBufferAvailable() const
{
    for (const auto& buffer : buffers) {
        if (!buffer.busy) {
            return true;
        }
    }
    return false;
}

bool
TABuffer::isBusy() const
{
    return isReading || isWriting;
}

bool
TABuffer::isBufferBusy(int bufferId) const
{
    return (bufferId >= 0 && bufferId < NUM_BUFFERS) ? 
           buffers[bufferId].busy : true;
}

size_t
TABuffer::getAvailableSpace() const
{
    size_t space = 0;
    for (const auto& buffer : buffers) {
        if (!buffer.busy) {
            space += BUFFER_DEPTH * BUFFER_WIDTH / 8;
        }
    }
    return space;
}

size_t
TABuffer::getStoredDataSize() const
{
    size_t size = 0;
    for (const auto& buffer : buffers) {
        if (buffer.busy) {
            size += (buffer.tail - buffer.head) * BUFFER_WIDTH / 8;
        }
    }
    return size;
}

void
TABuffer::setReadBandwidth(size_t bitsPerCycle)
{
    // 只能在初始化时设置，这里为了接口完整性
    DPRINTF(AIAccelerator, "Attempted to set read bandwidth to %d bits/cycle\n", bitsPerCycle);
}

void
TABuffer::setWriteBandwidth(size_t bitsPerCycle)
{
    writeBandwidth = bitsPerCycle;
    DPRINTF(AIAccelerator, "Set write bandwidth to %d bits/cycle\n", bitsPerCycle);
}

void
TABuffer::selectInputSource(int source)
{
    muxIn.selectedInput = source;
    DPRINTF(AIAccelerator, "Selected input source %d\n", source);
}

void
TABuffer::selectOutputBuffer(int bufferId)
{
    muxOut.selectedBuffer = bufferId;
    DPRINTF(AIAccelerator, "Selected output buffer %d\n", bufferId);
}

void
TABuffer::initializeBuffers()
{
    for (auto& buffer : buffers) {
        buffer.data = new uint8_t[BUFFER_DEPTH * BUFFER_WIDTH / 8];
        buffer.head = 0;
        buffer.tail = 0;
        buffer.busy = false;
    }
}

void
TABuffer::clearBuffers()
{
    for (auto& buffer : buffers) {
        buffer.head = 0;
        buffer.tail = 0;
        buffer.busy = false;
        memset(buffer.data, 0, BUFFER_DEPTH * BUFFER_WIDTH / 8);
    }
}

void
TABuffer::processTransfers()
{
    if (pendingTransfers.empty()) {
        return;
    }
    
    // 处理队列中的第一个传输
    Transfer& transfer = pendingTransfers.front();
    completeTransfer(transfer);
    
    // 移除已处理的传输
    pendingTransfers.pop_front();
    
    DPRINTF(AIAccelerator, "Processed transfer of %d bytes\n", transfer.size);
}

void
TABuffer::completeTransfer(const Transfer& transfer)
{
    // 释放或更新传输中使用的所有缓冲区
    for (int bufferId : transfer.bufferIndices) {
        if (transfer.isRead) {
            // 读取完成后释放缓冲区
            releaseBuffer(bufferId);
        }
    }
    
    // 更新状态
    if (transfer.isRead && pendingTransfers.size() <= 1) {
        isReading = false;
    } else if (!transfer.isRead && pendingTransfers.size() <= 1) {
        isWriting = false;
    }
}

bool
TABuffer::writeToBuffer(int bufferId, const uint8_t* data, size_t size)
{
    if (bufferId < 0 || bufferId >= NUM_BUFFERS || !buffers[bufferId].busy) {
        return false;
    }
    
    memcpy(buffers[bufferId].data, data, size);
    buffers[bufferId].tail = size * 8 / BUFFER_WIDTH;
    
    updateBandwidthUsage(size, false);
    
    DPRINTF(AIAccelerator, "Wrote %d bytes to buffer %d\n", size, bufferId);
    return true;
}

bool
TABuffer::readFromBuffer(int bufferId, uint8_t* data, size_t size)
{
    if (bufferId < 0 || bufferId >= NUM_BUFFERS || !buffers[bufferId].busy) {
        return false;
    }
    
    memcpy(data, buffers[bufferId].data, size);
    
    updateBandwidthUsage(size, true);
    
    DPRINTF(AIAccelerator, "Read %d bytes from buffer %d\n", size, bufferId);
    return true;
}

bool
TABuffer::validateTransfer(size_t size) const
{
    return size > 0 && size <= NUM_BUFFERS * BUFFER_DEPTH * BUFFER_WIDTH / 8;
}

bool
TABuffer::checkReadBandwidth(size_t size) const
{
    return (currentReadBandwidth + size * 8) <= readBandwidth;
}

bool
TABuffer::checkWriteBandwidth(size_t size) const
{
    return (currentWriteBandwidth + size * 8) <= writeBandwidth;
}

void
TABuffer::updateBandwidthUsage(size_t size, bool isRead)
{
    if (isRead) {
        currentReadBandwidth += size * 8;
    } else {
        currentWriteBandwidth += size * 8;
    }
}

void
TABuffer::reset()
{
    clearBuffers();
    pendingTransfers.clear();
    isReading = false;
    isWriting = false;
    currentReadBandwidth = 0;
    currentWriteBandwidth = 0;
    
    DPRINTF(AIAccelerator, "TA Buffer reset\n");
}

Port &
TABuffer::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "fifo_port") {
        return fifoPort;
    } else if (if_name == "rr_port") {
        return rrPort;
    } else if (if_name == "tensor_port") {
        return tensorPort;
    } else {
        return ClockedObject::getPort(if_name, idx);
    }
}

bool
TABuffer::BufferPort::recvTimingReq(PacketPtr pkt)
{
    // 实现接收请求的逻辑
    return true;
}

void
TABuffer::BufferPort::recvRespRetry()
{
    // 实现响应重试的逻辑
}

Tick
TABuffer::BufferPort::recvAtomic(PacketPtr pkt)
{
    // 实现原子访问的逻辑
    return 0;
}

void
TABuffer::BufferPort::recvFunctional(PacketPtr pkt)
{
    // 实现功能访问的逻辑
}

AddrRangeList
TABuffer::BufferPort::getAddrRanges() const
{
    // 返回端口的地址范围
    return AddrRangeList();
}

void
TABuffer::scheduleResponse(PacketPtr pkt, Tick delay)
{
    // 调度响应的发送
}

} // namespace gem5 