#ifndef __AI_ACCELERATOR_BUFFER_HH__
#define __AI_ACCELERATOR_BUFFER_HH__

#include "params/Buffer.hh"
#include "sim/clocked_object.hh"
#include "mem/port.hh"
#include <queue>
#include <vector>

namespace gem5
{

class Buffer : public ClockedObject
{
  private:
    // Buffer配置
    static const size_t BUFFER_SIZE = 1024;  // 1024位宽度
    
    // 缓冲区条目
    struct BufferEntry {
        std::vector<float> data;
        uint64_t tag;
        bool valid;
    };
    std::vector<BufferEntry> entries;
    
    // 操作类型
    struct BufferOp {
        enum class Type {
            WRITE,
            READ,
            ACCUMULATE
        };
        
        Type type;
        size_t entryIndex;
        uint64_t tag;
        std::vector<float> data;
    };
    std::queue<BufferOp> pendingOps;
    
    // 数据存储
    std::vector<uint8_t> data;
    
    // 部分和存储
    std::vector<float> partialSums;
    
    // 缓冲区状态
    bool isFull;
    bool isEmpty;
    bool busy;
    size_t currentEntry;
    size_t numEntries;
    size_t entrySize;
    
    // 数据请求队列
    struct BufferRequest {
        bool isRead;
        uint64_t addr;
        size_t size;
        PacketPtr pkt;
        int portId;  // 添加portId来标识哪个端口发送的请求
    };
    std::queue<BufferRequest> requestQueue;
    
    // 内部处理函数
    void processNextRequest();
    void scheduleResponse(PacketPtr pkt, Tick delay, int portId);
    void updateBufferState();
    void processPendingOperations();
    void completeOperation(const BufferOp& op);
    void initializeBuffer();
    void clearBuffer();
    bool validateSize(size_t size) const;
    int findFreeEntry() const;
    int findEntry(uint64_t tag) const;
    void releaseEntry(size_t index);
    bool writeToEntry(size_t index, const float* data, size_t size);
    bool readFromEntry(size_t index, float* data, size_t size) const;
    bool accumulateToEntry(size_t index, const float* data, size_t size);

  public:
    Buffer(const BufferParams &params);
    ~Buffer();

    // 主要接口函数
    void tick();
    void reset();
    
    // 数据访问接口
    void writeData(const uint8_t* data, size_t size);
    void readData(uint8_t* data, size_t size) const;
    bool write(const float* data, size_t size, uint64_t tag);
    bool read(float* data, size_t size, uint64_t tag) const;
    bool accumulate(const float* data, size_t size, uint64_t tag);
    
    // 部分和操作
    void addPartialSum(float value, size_t index);
    float getPartialSum(size_t index) const;
    void clearPartialSums();
    
    // 端口访问接口
    Port &getPort(const std::string &if_name, PortID idx = InvalidPortID);
    
    // 配置接口
    void setNumEntries(size_t num);
    void setEntrySize(size_t size);
    
    // 状态查询
    bool isBusy() const;
    bool hasSpace() const;
    bool hasData() const { return !isEmpty; }
    bool hasData(uint64_t tag) const;

  protected:
    // 端口定义
    class BufferPort : public ResponsePort
    {
      public:
        BufferPort(const std::string &name, Buffer *owner) :
            ResponsePort(name, owner), owner(owner) {}
      
      protected:
        bool recvTimingReq(PacketPtr pkt);
        void recvRespRetry();
        
        Tick recvAtomic(PacketPtr pkt);
        void recvFunctional(PacketPtr pkt);
        
        AddrRangeList getAddrRanges() const;
        
      private:
        Buffer *owner;
    };

    // 输入端口
    BufferPort tensorPort;  // 从Tensor Core接收数据
    
    // 输出端口
    BufferPort tcPort;     // 输出到TC MUXin
    BufferPort castPort;   // 输出到Cast单元
    
    // 配置参数
    const Tick accessLatency;
    const size_t bufferWidth;
};

} // namespace gem5

#endif // __AI_ACCELERATOR_BUFFER_HH__ 