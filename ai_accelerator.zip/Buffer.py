from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class Buffer(ClockedObject):
    type = 'Buffer'
    cxx_header = "ai_accelerator/buffer.hh"
    cxx_class = "gem5::Buffer"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    size = Param.MemorySize("1MB", "Size")
    bandwidth = Param.MemoryBandwidth("1GB/s", "Bandwidth")
    latency = Param.Latency("10ns", "Latency")
    read_ports = Param.Unsigned(1, "Read ports")
    write_ports = Param.Unsigned(1, "Write ports")

    # 添加缺失的参数
    accessLatency = Param.Cycles(10, "Access latency in cycles")
    bufferWidth = Param.UInt32(1024, "Buffer width in bits")

    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Memory interface
    port = RequestPort("Port to the memory system")
    
    # Configuration parameters
    read_latency = Param.Tick(1, "Read latency")
    write_latency = Param.Tick(1, "Write latency")
    read_bandwidth = Param.UInt32(64, "Read bandwidth in bytes per cycle")
    write_bandwidth = Param.UInt32(64, "Write bandwidth in bytes per cycle")
    fifo_mode = Param.Bool(True, "Enable FIFO mode") 