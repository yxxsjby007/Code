#include "ai_accelerator/tensor_core.hh"
#include "debug/AIAccelerator.hh"
#include "base/trace.hh"
#include <cstring>
#include <algorithm>
#include "mem/packet_access.hh"
#include "sim/system.hh"

namespace gem5
{

TensorCore::TensorCore(const TensorCoreParams &params)
    : ClockedObject(params),
      state(IDLE),
      mode(DENSE),
      taPort("ta_port", this),
      tbPort("tb_port", this),
      tcPort("tc_port", this),
      trPort("tr_port", this),
      computeLatency(params.compute_latency),
      computeBandwidth(params.compute_bandwidth)
{
    // Initialize matrices
    initializeMatrices();

    // Initialize status
    computing = false;
    accumulating = false;
    currentMode = ComputeMode::DENSE;

    DPRINTF(AIAccelerator, "Tensor Core initialized\n");
}

TensorCore::~TensorCore()
{
}

void
TensorCore::tick()
{
    switch (state) {
        case IDLE:
            if (!requestQueue.empty()) {
                processNextRequest();
            }
            break;
            
        case LOADING_A:
        case LOADING_B:
        case LOADING_C:
            // 等待加载完成
            if (!requestQueue.empty()) {
                processNextRequest();
            }
            break;
            
        case COMPUTING:
            performComputation();
            break;
            
        case STORING_R:
            // 等待存储完成
            if (requestQueue.empty()) {
                state = IDLE;
            }
            break;
    }
}

void
TensorCore::processNextRequest()
{
    ComputeRequest &req = requestQueue.front();
    
    if (req.isLoad) {
        // 处理加载请求
        switch (req.matrixId) {
            case 0: // Matrix A
                memcpy(matrixA.data() + req.addr,
                       req.pkt->getConstPtr<float>(),
                       req.size);
                state = LOADING_A;
                break;
                
            case 1: // Matrix B
                memcpy(matrixB.data() + req.addr,
                       req.pkt->getConstPtr<float>(),
                       req.size);
                state = LOADING_B;
                break;
                
            case 2: // Matrix C
                memcpy(matrixC.data() + req.addr,
                       req.pkt->getConstPtr<float>(),
                       req.size);
                state = LOADING_C;
                break;
        }
    } else {
        // 处理存储请求
        if (req.matrixId == 3) { // Matrix R
            memcpy(req.pkt->getPtr<float>(),
                   matrixR.data() + req.addr,
                   req.size);
            state = STORING_R;
        }
    }
    
    // 创建响应
    req.pkt->makeResponse();
    scheduleResponse(req.pkt, computeLatency);
    
    requestQueue.pop();
}

void
TensorCore::performComputation()
{
    switch (mode) {
        case DENSE:
            denseMatrixMultiply();
            break;
            
        case STRUCTURED_SPARSE:
            structuredSparseMultiply();
            break;
            
        case UNSTRUCTURED_SPARSE:
            unstructuredSparseMultiply();
            break;
    }
    
    state = STORING_R;
    DPRINTF(AIAccelerator, "Computation completed in %s mode\n",
            mode == DENSE ? "dense" :
            mode == STRUCTURED_SPARSE ? "structured sparse" :
            "unstructured sparse");
}

void
TensorCore::denseMatrixMultiply()
{
    // TR = TA × TB + TC
    for (int i = 0; i < MATRIX_DIM; i++) {
        float sum = 0.0f;
        for (int j = 0; j < MATRIX_DIM; j++) {
            sum += matrixA[i * MATRIX_DIM + j] * matrixB[j];
        }
        matrixR[i] = sum + matrixC[i];
    }
}

void
TensorCore::structuredSparseMultiply()
{
    // 实现结构化稀疏矩阵乘法
    // 这里使用简单的块稀疏模式
    const int BLOCK_SIZE = 4;
    
    std::fill(matrixR.begin(), matrixR.end(), 0.0f);
    
    for (int i = 0; i < MATRIX_DIM; i += BLOCK_SIZE) {
        for (int j = 0; j < MATRIX_DIM; j += BLOCK_SIZE) {
            // 检查块是否为非零
            bool isNonZeroBlock = false;
            for (int bi = 0; bi < BLOCK_SIZE && !isNonZeroBlock; bi++) {
                for (int bj = 0; bj < BLOCK_SIZE; bj++) {
                    if (matrixA[(i + bi) * MATRIX_DIM + (j + bj)] != 0.0f) {
                        isNonZeroBlock = true;
                        break;
                    }
                }
            }
            
            // 如果块非零，执行计算
            if (isNonZeroBlock) {
                for (int bi = 0; bi < BLOCK_SIZE; bi++) {
                    for (int bj = 0; bj < BLOCK_SIZE; bj++) {
                        matrixR[i + bi] +=
                            matrixA[(i + bi) * MATRIX_DIM + (j + bj)] *
                            matrixB[j + bj];
                    }
                }
            }
        }
    }
    
    // 添加TC
    for (int i = 0; i < MATRIX_DIM; i++) {
        matrixR[i] += matrixC[i];
    }
}

void
TensorCore::unstructuredSparseMultiply()
{
    // 实现非结构化稀疏矩阵乘法
    // 使用简单的CSR格式
    std::vector<float> values;
    std::vector<int> columnIndices;
    std::vector<int> rowPointers(MATRIX_DIM + 1);
    
    // 转换为CSR格式
    int nnz = 0;
    rowPointers[0] = 0;
    for (int i = 0; i < MATRIX_DIM; i++) {
        for (int j = 0; j < MATRIX_DIM; j++) {
            float val = matrixA[i * MATRIX_DIM + j];
            if (val != 0.0f) {
                values.push_back(val);
                columnIndices.push_back(j);
                nnz++;
            }
        }
        rowPointers[i + 1] = nnz;
    }
    
    // 执行稀疏矩阵-向量乘法
    std::fill(matrixR.begin(), matrixR.end(), 0.0f);
    for (int i = 0; i < MATRIX_DIM; i++) {
        for (int j = rowPointers[i]; j < rowPointers[i + 1]; j++) {
            matrixR[i] += values[j] * matrixB[columnIndices[j]];
        }
        matrixR[i] += matrixC[i];
    }
}

void
TensorCore::scheduleResponse(PacketPtr pkt, Tick delay)
{
    auto event = new EventFunctionWrapper(
        [this, pkt]() {
            switch (pkt->getPortId()) {
                case 0:
                    taPort.sendTimingResp(pkt);
                    break;
                case 1:
                    tbPort.sendTimingResp(pkt);
                    break;
                case 2:
                    tcPort.sendTimingResp(pkt);
                    break;
                case 3:
                    trPort.sendTimingResp(pkt);
                    break;
            }
        },
        name());
    schedule(event, curTick() + delay);
}

void
TensorCore::setComputeMode(ComputeMode newMode)
{
    mode = newMode;
    DPRINTF(AIAccelerator, "Set compute mode to %s\n",
            mode == DENSE ? "dense" :
            mode == STRUCTURED_SPARSE ? "structured sparse" :
            "unstructured sparse");
}

void
TensorCore::startComputation()
{
    if (state == IDLE || state == LOADING_C) {
        state = COMPUTING;
        DPRINTF(AIAccelerator, "Starting computation\n");
    }
}

bool
TensorCore::isComputationDone() const
{
    return state == IDLE;
}

void
TensorCore::loadMatrixA(const float* data, size_t size)
{
    if (size <= matrixA.size() * sizeof(float)) {
        memcpy(matrixA.data(), data, size);
        DPRINTF(AIAccelerator, "Loaded matrix A (%zu bytes)\n", size);
    }
}

void
TensorCore::loadMatrixB(const float* data, size_t size)
{
    if (size <= matrixB.size() * sizeof(float)) {
        memcpy(matrixB.data(), data, size);
        DPRINTF(AIAccelerator, "Loaded matrix B (%zu bytes)\n", size);
    }
}

void
TensorCore::loadMatrixC(const float* data, size_t size)
{
    if (size <= matrixC.size() * sizeof(float)) {
        memcpy(matrixC.data(), data, size);
        DPRINTF(AIAccelerator, "Loaded matrix C (%zu bytes)\n", size);
    }
}

void
TensorCore::getResult(float* data, size_t size) const
{
    if (size <= matrixR.size() * sizeof(float)) {
        memcpy(data, matrixR.data(), size);
        DPRINTF(AIAccelerator, "Retrieved result (%zu bytes)\n", size);
    }
}

Port &
TensorCore::getPort(const std::string &if_name, PortID idx)
{
    if (if_name == "ta_port") {
        return taPort;
    } else if (if_name == "tb_port") {
        return tbPort;
    } else if (if_name == "tc_port") {
        return tcPort;
    } else if (if_name == "tr_port") {
        return trPort;
    } else {
        return ClockedObject::getPort(if_name, idx);
    }
}

bool
TensorCore::ComputePort::recvTimingReq(PacketPtr pkt)
{
    // 创建新的计算请求
    TensorCore::ComputeRequest req;
    req.isLoad = pkt->isRead();
    req.matrixId = pkt->getPortId();
    req.addr = pkt->getAddr();
    req.size = pkt->getSize();
    req.pkt = pkt;
    
    // 将请求添加到队列
    owner->requestQueue.push(req);
    return true;
}

void
TensorCore::ComputePort::recvRespRetry()
{
    // 重试响应
}

Tick
TensorCore::ComputePort::recvAtomic(PacketPtr pkt)
{
    // 原子访问实现
    return owner->computeLatency;
}

void
TensorCore::ComputePort::recvFunctional(PacketPtr pkt)
{
    // 功能访问实现
}

AddrRangeList
TensorCore::ComputePort::getAddrRanges() const
{
    AddrRangeList ranges;
    ranges.push_back(AddrRange(0, MATRIX_DIM * MATRIX_DIM * sizeof(float) - 1));
    return ranges;
}

void
TensorCore::initializeMatrices()
{
    // Initialize matrix A (32x32)
    matrixA.resize(MATRIX_DIM * MATRIX_DIM);
    matrixA.valid = false;

    // Initialize matrix B (32x1)
    matrixB.resize(MATRIX_DIM);
    matrixB.valid = false;

    // Initialize matrix C (32x1)
    matrixC.resize(MATRIX_DIM);
    matrixC.valid = false;

    // Initialize result matrix R (32x1)
    matrixR.resize(MATRIX_DIM);
    matrixR.valid = false;
}

void
TensorCore::clearMatrices()
{
    std::fill(matrixA.begin(), matrixA.end(), 0.0f);
    std::fill(matrixB.begin(), matrixB.end(), 0.0f);
    std::fill(matrixC.begin(), matrixC.end(), 0.0f);
    std::fill(matrixR.begin(), matrixR.end(), 0.0f);

    matrixA.valid = false;
    matrixB.valid = false;
    matrixC.valid = false;
    matrixR.valid = false;
}

bool
TensorCore::validateDimensions(size_t len) const
{
    return len > 0 && len <= MATRIX_DIM * MATRIX_DIM;
}

void
TensorCore::processPendingOperations()
{
    if (computing || accumulating) {
        // Complete current operation
        if (!pendingOps.empty()) {
            completeOperation(pendingOps.front());
        }
        computing = false;
        accumulating = false;
    }
}

void
TensorCore::completeOperation(const ComputeOperation& op)
{
    if (op.isAccumulate) {
        // Update result with accumulation
        matrixR.valid = true;
    } else {
        // Update result with matrix multiply
        matrixR.valid = true;
    }
}

bool
TensorCore::performDenseMultiply()
{
    // Perform dense matrix multiplication: R = A × B
    std::fill(matrixR.begin(), matrixR.end(), 0.0f);
    
    for (int i = 0; i < MATRIX_DIM; i++) {
        for (int j = 0; j < MATRIX_DIM; j++) {
            matrixR[i] += matrixA[i * MATRIX_DIM + j] * matrixB[j];
        }
    }

    if (matrixC.valid) {
        // Add bias/accumulator: R = A × B + C
        for (int i = 0; i < MATRIX_DIM; i++) {
            matrixR[i] += matrixC[i];
        }
    }

    matrixR.valid = true;
    computing = false;

    DPRINTF(AIAccelerator, "Completed dense matrix multiply\n");
    return true;
}

bool
TensorCore::performStructuredSparseMultiply()
{
    if (structuredPattern.indices.empty()) {
        return false;
    }

    // Perform structured sparse matrix multiplication
    std::fill(matrixR.begin(), matrixR.end(), 0.0f);
    
    for (uint32_t idx : structuredPattern.indices) {
        int row = idx / MATRIX_DIM;
        int col = idx % MATRIX_DIM;
        matrixR[row] += matrixA[row * MATRIX_DIM + col] * matrixB[col];
    }

    if (matrixC.valid) {
        for (int i = 0; i < MATRIX_DIM; i++) {
            matrixR[i] += matrixC[i];
        }
    }

    matrixR.valid = true;
    computing = false;

    DPRINTF(AIAccelerator, "Completed structured sparse matrix multiply\n");
    return true;
}

bool
TensorCore::performUnstructuredSparseMultiply()
{
    if (unstructuredPattern.indices.empty()) {
        return false;
    }

    // Perform unstructured sparse matrix multiplication
    std::fill(matrixR.begin(), matrixR.end(), 0.0f);
    
    for (uint32_t idx : unstructuredPattern.indices) {
        int row = idx / MATRIX_DIM;
        int col = idx % MATRIX_DIM;
        matrixR[row] += matrixA[row * MATRIX_DIM + col] * matrixB[col];
    }

    if (matrixC.valid) {
        for (int i = 0; i < MATRIX_DIM; i++) {
            matrixR[i] += matrixC[i];
        }
    }

    matrixR.valid = true;
    computing = false;

    DPRINTF(AIAccelerator, "Completed unstructured sparse matrix multiply\n");
    return true;
}

bool
TensorCore::validateSparsityPattern(const std::vector<uint32_t>& pattern) const
{
    if (pattern.empty()) {
        return false;
    }

    // Validate that all indices are within bounds
    for (uint32_t idx : pattern) {
        if (idx >= MATRIX_DIM * MATRIX_DIM) {
            return false;
        }
    }

    return true;
}

void
TensorCore::applySparsityPattern(const SparsityPattern& pattern)
{
    // Apply sparsity pattern to matrices
    std::vector<float> sparseA(MATRIX_DIM * MATRIX_DIM, 0.0f);
    
    for (size_t i = 0; i < pattern.indices.size(); i++) {
        uint32_t idx = pattern.indices[i];
        sparseA[idx] = pattern.values[i];
    }

    matrixA = sparseA;
    matrixA.valid = true;
}

void
TensorCore::reset()
{
    clearMatrices();
    computing = false;
    accumulating = false;
    currentMode = ComputeMode::DENSE;
    
    while (!pendingOps.empty()) {
        pendingOps.pop();
    }

    structuredPattern.indices.clear();
    structuredPattern.values.clear();
    unstructuredPattern.indices.clear();
    unstructuredPattern.values.clear();

    DPRINTF(AIAccelerator, "Tensor Core reset completed\n");
}

} // namespace gem5 