from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class AcceleratorStats(ClockedObject):
    type = 'AcceleratorStats'
    cxx_header = "ai_accelerator/stats.hh"
    cxx_class = "gem5::AcceleratorStats"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    enable_detailed_stats = Param.Bool(True, "Enable detailed statistics")
    sampling_period = Param.Cycles(1000, "Sampling period in cycles")
    output_file = Param.String("acc_stats.txt", "Output file for statistics") 