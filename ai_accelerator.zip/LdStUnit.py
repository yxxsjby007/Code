from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class LdStUnit(ClockedObject):
    type = 'LdStUnit'
    cxx_header = "ai_accelerator/ld_st_unit.hh"
    cxx_class = "gem5::LdStUnit"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    data_port = RequestPort("Data port")
    size = Param.MemorySize("1MB", "Size")
    bandwidth = Param.MemoryBandwidth("1GB/s", "Bandwidth")
    latency = Param.Latency("10ns", "Latency")
    ld_bulk = Param.Unsigned(1, "Load bulk")

    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    max_outstanding_requests = Param.UInt32(16, "Maximum number of outstanding requests")
    cache_line_size = Param.UInt32(64, "Cache line size in bytes")
    prefetch_enabled = Param.Bool(True, "Enable prefetching")
    prefetch_distance = Param.UInt32(2, "Prefetch distance in cache lines") 