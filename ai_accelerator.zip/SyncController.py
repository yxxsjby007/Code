from m5.params import *
from m5.proxy import *
from m5.objects.ClockedObject import ClockedObject

class SyncController(ClockedObject):
    type = 'SyncController'
    cxx_header = "ai_accelerator/sync_controller.hh"
    cxx_class = "gem5::SyncController"

    system = Param.System(Parent.any, "System this acc belongs to")
    
    # Clock domain
    clk_domain = Param.ClockDomain(Parent.any, "Clock domain")
    
    # Configuration parameters
    num_units = Param.UInt32(4, "Number of units to synchronize")
    sync_mode = Param.String("barrier", "Synchronization mode: barrier, token, etc.")
    timeout = Param.Cycles(1000, "Synchronization timeout in cycles") 